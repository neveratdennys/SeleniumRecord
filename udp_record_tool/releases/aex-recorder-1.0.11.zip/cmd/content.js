console.log("AEX Recorder ---- Content script successfully loaded!");

let pageLoadCounter = 0;
let datePickerCounter = 0;
let tempDocName;
let tempDocID;
const nextBtnKeyword = ["next", "start", "continue", "finish", "agree", "submit"];
const prevBtnKeyword = ["previous", "back"];
const pageWaitTime = 50;
const totalWaitTime = 10000;
const pageLoadedDelay = 500;

/**
 * It reads all the datePicker value in the current Page,
 * and store them to the ison array.
 */
function readDate() {
    getDocument().querySelectorAll('input.aexDatePicker').forEach(dp => {
        if (isVisible(dp) && dp.value !== '') {
            saveFieldToPageEntry(dp);
        }
    })
}

/**
 * Adds recording purpose click listeners to All buttons on the page,
 */
function addClickListenerToFields() {

    document.addEventListener('click', handleElementsFromEvents);
    var iframeButtons = getDocument().querySelectorAll('a,rect');
    var datefields = getDocument().getElementsByClassName('aexDatePicker');
    for (var i = 0; i < iframeButtons.length; i++) {
        if (isVisible(iframeButtons[i])) {
            if (isNextBtn(iframeButtons[i]) || isPrevBtn(iframeButtons[i])) {
                iframeButtons[i].addEventListener('mouseover', handleElementsFromEvents);
            } else {
                iframeButtons[i].addEventListener('click', handleElementsFromEvents);
            }
        }
    }

    for (var i = 0; i < datefields.length; i++) {
        if (isVisible(datefields[i])) {
            datefields[i].addEventListener('click', handleElementsFromEvents);
        }
    }
}

function addOnChangeListenerToInputFields() {
    var fields = getDocument().querySelectorAll('textarea,input,select');
    for (var i = 0; i < fields.length; i++) {

        if (fields[i].type === "select") {
            if (isVisible(fields[i]) && fields[i].selectedIndex !== "-1") {
                handleElementsFromEvents(fields[i], true);
            }
        } else if (fields[i].type === "checkbox" || fields[i].type === "radio") {
            if (isVisible(fields[i]) && fields[i].checked) {
                handleElementsFromEvents(fields[i], true);
            }
        } else {
            if (isVisible(fields[i]) && !isEmpty(fields[i].value)) {
                handleElementsFromEvents(fields[i], true);
            }
        }

        fields[i].addEventListener('change', handleElementsFromEvents);
    }
}

function removeAllListeners() {
    var fields = getDocument().querySelectorAll('a,textarea,input,select');

    for (var i = 0; i < fields.length; i++) {
        if (fields[i].tagName === 'A') {
            fields[i].removeEventListener('click', handleElementsFromEvents);
        } else {
            fields[i].removeEventListener('change', handleElementsFromEvents);
        }
    }
    document.removeEventListener('click', handleElementsFromEvents);
}

function handleElementsFromEvents(e, isAssert) {
    var target = e.target;
    var element = target ? e.target : e;

    if (isNavBtnForSwitchSDs(element)) {
        PageNavigationInSD();
    } else if (isNavBtnForSwitchSDsubpages(element)) {
        pageSubNavigationInSD();
    } else {
        if (isVisible(element)) {
            if (isDatePicker(element)) {
                datePickerCounter = 0;
                trackChangesForDatePicker(element, element.value);
            } else if (isPrevBtn(element) || isNextBtn(element)) {
                if (lastClick >= (Date.now() - delay)) {
                    return;
                }
                lastClick = Date.now();
                transactionNextHandler();
            } else if (isSignatureElement(element)) {
                saveFieldToPageEntry(element.parentElement, false);
                setTimeout(() => {
                    handleSignatureClick();
                }, 1000);
            } else if (!isUselessElement(element)) {
                setTimeout(() => {                    
                    saveFieldToPageEntry(element, isAssert);
                }, 100);                
            }
        }
    }

}

function saveFieldToPageEntry(element, prefill) {

    var entry = {
        tagName: element.tagName,
        name: element.name,
        options: ext_getValueByName(element.name),
        type: element.getAttribute("type"),
        id: element.id,
        isAssert: prefill ? prefill : false,
        isRequired: element.classList.contains("required")
    };

    if (isPageSD()) {
        entry.subPageNo = getAgreementInterface().currentDoc.currentPage;
    }
       
    addEntryToArray(entry);
}

function addEntryToArray(entry) {
    var dupEntry = false;

    for (var i = 0; i < pageEntryArray.length; i++) {
        if (isDupEntry(pageEntryArray[i], entry)) {
            dupEntry = true;
            if(entry.tagName !== "svg" && pageEntryArray[i].options !== entry.options){
                console.log("pop");
                pageEntryArray.splice(i, 1);
                entry.isAssert = false;
            } else {
                console.log("skip");
                return;
            }  
        }
    }

    if(entry.tagName !== "svg" && !dupEntry && isEmpty(entry.options)){
        console.log("skip empty");
        return;
    }

    pageEntryArray.push(entry);
    pageEntryArray = pageEntryArray.filter(function (n) {
        return n != undefined
    });

    console.log(pageEntryArray);

    if (!entry.isAssert) {
        msgBox.print(pageEntryArray.length + " inputs are recored in current page");
    }
}

function isDupEntry(oldEntry, newEntry) {
    return (newEntry.tagName === "svg" && oldEntry.id === newEntry.id) 
        || (oldEntry.name === newEntry.name && oldEntry.id === newEntry.id);
}

function handleSignatureClick() {
    var signPanel = document.querySelector("ae-dialog-sign");
    if (signPanel) {
        var signBtn = signPanel.querySelector('paper-button#sign');
        if (signBtn) {
            signBtn.addEventListener("click", () => {
                var sigData = {
                    user: signPanel.user,
                    password: signPanel.password,
                    sigId: signPanel.sigId
                }

                for (var i = 0; i < seleniumJson.sigData.length; i++) {
                    if (seleniumJson.sigData[i].user === sigData.user) {
                        seleniumJson.sigData.splice(i, 1);
                    }
                }
                seleniumJson.sigData.push(sigData);
                setTimeout(() => {
                    addListenerToSignatureElements();
                    startCheckingSigingCompleteDialog();
                }, 200);
            })
        }
    }
}

function startCheckingSigingCompleteDialog() {

    //check if signing complete dialog pop up

    if (detectSigningCompleteDialog()) {
        cfmBox.print(4);
    } else {
        setTimeout(() => {
            startCheckingSigingCompleteDialog();
        }, 1000);
    }
}

function addListenerToSignatureElements() {
    getDocument().querySelectorAll('rect').forEach(rect => {
        rect.addEventListener("click", handleElementsFromEvents);
    })
}

function trackChangesForDatePicker(element, oldValue) {
    var curValue = element.value;
    //var date_regex = /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/;
    if (curValue != oldValue) {
        saveFieldToPageEntry(element);
    } else {
        if (hasExceedWaitTime(datePickerCounter)) {
            return;
        }
        datePickerCounter++;
        setTimeout(() => {
            trackChangesForDatePicker(element, oldValue);
        }, pageWaitTime);
    }

}

function isNavBtnForSwitchSDs(element) {
    return (element.tagName === "DIV" && element.className.includes("ae-bubble") && element.parentElement.className.includes("ae-bubble-item"))
        || (element.onclick != null && String(element.onclick).includes("agreementInterface.switchDoc"))
        || (element.tagName === "IRON-ICON" && element.className.includes("docIcon"));
}

function isNavBtnForSwitchSDsubpages(element) {
    return (element.tagName === "AE-FNB" && (element.icon === "chevron-right" || element.icon === "chevron-left"))
        || (element.tagName === "IRON-ICON" && element.id === "icon" && element.classList.contains("ae-fnb"))
        || (element.tagName === "DIV" && (element.parentElement.id === "nav_left" || element.parentElement.id === "nav_right" || element.classList.contains("ae-page-selector")))
        || (element.tagName === "IMG" && element.classList.contains("ae-page-selector"));
}

function isUselessElement(element) {
    const uFieldRegex = /^uField_(\d+|\d+\_\d+)$/;

    return element.disabled || (element.name === "" && element.tagName !== "A" && element.tagName !== "svg")
        || ((element.tagName === "DIV" || element.tagName === "PAPER-BUTTON" || element.tagName === "BUTTON"
        || element.tagName === "SPAN" || element.tagName === "IRON-ICON" || element.type === "password")
        && !element.id.match(uFieldRegex));
}

function isDatePicker(element) {
    const datePickerRegex = /^aexDatePicker.*$/;
    return typeof element.className.match === "function" && element.className.match(datePickerRegex);
}

function isSignatureElement(element) {
    return element.tagName === "rect";
}

function isNextBtn(element) {
    return element.name === "IvariNextButton" || element.name === "AEXTransactionNext" || checkNextBtnText(element.text);
}

function checkNextBtnText(text) {
    for (var i = 0; i < nextBtnKeyword.length; i++) {
        if (String(text).toLowerCase().includes(nextBtnKeyword[i])) {
            return true;
        }
    }
    return false;
}

function isPrevBtn(element) {
    return element.name === "IvariPreviousButton" || element.name === "AEXTransactionPrevious" || checkPrevBtnText(element.text);
}

function checkPrevBtnText(text) {
    for (var i = 0; i < prevBtnKeyword.length; i++) {
        if (String(text).toLowerCase().includes(prevBtnKeyword[i])) {
            return true;
        }
    }
    return false;
}

function PageNavigationInSD() {
    console.log("Page Navigation in SD");
    saveEntriesToJson();
    setTimeout(() => {
        spinner(true, "Wait for Recorder to be ready");
    }, 500);
    setTimeout(() => {
        spinner(true, "Wait for Recorder to be ready");
    }, 1000);
    setTimeout(() => {
        recordNewPage();
        spinner(false);
    }, 2000);    //wait SD page switch to load
}

function pageSubNavigationInSD() {
    console.log("Sub Page Navigation in SD");
    setTimeout(() => {
        spinner(true, "Wait for Recorder to be ready");
    }, 500);
    setTimeout(() => {
        spinner(true, "Wait for Recorder to be ready");
    }, 1000);
    setTimeout(() => {
        addClickListenerToFields();
        addOnChangeListenerToInputFields();
        spinner(false);
    }, 2000);
}

function dataEntryClickedSDs() {

    for (var i = 0; i < getSeleniumJsonClickedSDs().length; i++) {
        if (getSeleniumJsonClickedSDs()[i].docName === LocateCurDocName()) {
            getSeleniumJsonClickedSDs().splice(i, 1);
        }
    }

    var data = {
        docName: LocateCurDocName(),
        docID: LocateCurDocId()
    };

    getSeleniumJsonClickedSDs().push(data);
}

/**
 * if the current page is already existing in JSON, copy the previous entries and continue
 */
function pageChangeAnalysis() {
    var docName = LocateCurDocName();

    for (var i = 0; i < getSeleniumJsonPages().length; i++) {
        if (getSeleniumJsonPages()[i].docName === docName) {
            pageEntryArray = getSeleniumJsonPages()[i].entries;
            console.log("Dup page found, continue recording - " + getSeleniumJsonPages()[i].docName);
            getSeleniumJsonPages().splice(i, 1);
            rearragePageNo();
        }
    }

}

//Only check if last two entries are the same by comparing the docName
function removeDupEntryFromJSON() {

    var length = getSeleniumJsonPages().length;
    if (length >= 2 && getSeleniumJsonPages()[length - 1].docName == getSeleniumJsonPages()[length - 2].docName) {
        getSeleniumJsonPages().splice(length - 2, 1);
        rearragePageNo();
        removeDupEntryFromJSON();
    }

}

function rearragePageNo() {
    for (var i = 0; i < getSeleniumJsonPages().length; i++) {
        getSeleniumJsonPages()[i].pageNumber = i + 1;
    }
}

function transactionNextHandler() {
    msgBox.print("Going to next page...");
    saveEntriesToJson();
    waitforPageChange();
}

function saveEntriesToJson() {
    readDate();
    var page = {
        pageNumber: getSeleniumJsonPages().length + 1,
        docName: tempDocName,
        docID: tempDocID,
        isSD: isPageSD(),
        entries: pageEntryArray
    };

    getSeleniumJsonPages().push(page);
    removeDupEntryFromJSON();
    writeToConsoleJson();
    sendMsgforRecord();
}

function updateTempDocNameID() {
    tempDocName = LocateCurDocName();
    tempDocID = LocateCurDocId();
}

function locateNextBtn() {
    var fields = getDocument().querySelectorAll('a');

    for (var i = 0; i < fields.length; i++) {
        if (String(fields[i].id).includes("uField") && isNextBtn(fields[i])) {
            return fields[i];
        }
    }

    return null;
}

function LocateCurDocName() {
    return getAgreementInterface().currentDoc.docName;
}

function LocateCurDocId() {
    return getAgreementInterface().currentDoc.docID;
}

function waitforPageChange() {
    var docName = LocateCurDocName();
    if (docName !== tempDocName) {
        if (!playback) {
            waitForElementToDisplayToRecord(docName);
        } else {
            waitForElementToDisplayForPlayBack(docName);
        }
        pageChangeCounter = 0;
    } else {
        if (hasExceedWaitTime(pageChangeCounter)) {
            pageChangeCounter = 0;
            if (playback) {
                msgBox.showResumeBtn(true);
            }
            return;
        } else {
            if (playback) {
                if (detectErrorDialog()) {
                    msgBox.showResumeBtn(true);
                    pageChangeCounter = 0;
                    return;
                }

                pageChangeCounter += 2;
            } else {
                if (detectSaveAndSendPanel()) {
                    handleSaveAndSend();
                    return;
                }

                pageChangeCounter++;
            }

            setTimeout(function () {
                waitforPageChange();
            }, pageWaitTime);
        }
    }
}

function handleSaveAndSend() {
    msgBox.print("Send draft to recipients");
    var sendPanel = hasCompoundController() ? document.querySelector("ae-dialog-save-send") : document.querySelector("div#sendMail");
    if (!sendPanel) {
        return;
    }

    if (hasCompoundController()) {
        var sendButton = sendPanel.$.createAgreement;
        sendButton.addEventListener("click", function () {
            seleniumJson.sendPanelInfo = {
                recipientList: sendPanel.recipientList,
                ccList: sendPanel.ccList,
                message: sendPanel.message,
                subiect: sendPanel.subiect
            };
            sendMsgforRecord();
        });
    } else {
        var sendButton = sendPanel.querySelector("button#createAgreementBtn");
        sendButton.addEventListener("click", function () {
            var recipientList = [];
            var ccList = [];
            sendPanel.querySelectorAll("input[type=email]").forEach(input => {
                if (isVisible(input)) {
                    if (input.id.includes("linksigid")) {
                        recipientList.push(input.placeholder);
                    } else {
                        ccList.push(input.placeholder);
                    }
                }
            })

            seleniumJson.sendPanelInfo = {
                recipientList,
                ccList,
                message: sendPanel.querySelector("#agreementExpressEmailSendingSubiect").value,
                subiect: sendPanel.querySelector("#agreementExpressEmailSendingMessageBody").value
            };
            sendMsgforRecord();
        });
    }

}

function waitForElementToDisplayToRecord(pageName) {
    if (stop == true) {
        console.log("Stop called in WFED_Record");
        removeAllListeners();
        spinner(false);
        return;
    }

    if (checkPageLoadedByDom(pageName)) {
        setTimeout(() => {
            msgBox.print("Recording page " + pageName);
            recordNewPage();
            spinner(false);
            pageLoadCounter = 0;
        }, pageLoadedDelay);
    } else {
        if (hasExceedWaitTime(pageLoadCounter)) {
            spinner(false);
            pageLoadCounter = 0;
            return;
        } else {
            console.log("Still waiting for " + pageName);
            pageLoadCounter++;
            spinner(true, "Wait for Recorder to be ready");
            setTimeout(function () {
                waitForElementToDisplayToRecord(pageName);
            }, pageWaitTime);
        }
    }
}

function recordNewPage() {
    console.log("New Page ...");
    if (isPageSD()) {
        dataEntryClickedSDs();
        addListenerForSendButton();
    }
    pageEntryArray = [];
    removeDupEntryFromJSON();
    pageChangeAnalysis();
    updateTempDocNameID();
    addClickListenerToFields();
    addOnChangeListenerToInputFields();
    msgBox.show();
}

function addListenerForSendButton() {

    var sendButton = hasCompoundController() ? document.querySelector("#agreementSaveAndSendBtn") : document.querySelector("#sendBtn");
    if (sendButton) {
        sendButton.addEventListener("click", () => {
            setTimeout(() => {
                saveEntriesToJson();
                handleSaveAndSend();
            }, 1000);
        });
    }
}

function checkAllValidationFullfilled() {
    var docName = LocateCurDocName();
    var agreements = getAgreementInterface().agreements;
    var pageNo = -1;

    for (var i = 0; i < agreements.length; i++) {
        if (agreements[i].docName == docName) {
            pageNo = i;
            break;
        }
    }

    if (pageNo == -1) {
        console.log("No matched document");
    } else if (agreements[pageNo].getRequiredFieldCount() != 0) {
        return false;
    }

    return true;
}

function buildJsonMetaAndStart() {
    // build ison
    var meta;
    meta = {
        companyName: getAgreementInterface().companyName,
        companyId: getAgreementInterface().companyId,
        transactionName: getAgreementInterface().transactionName,
        transactionFolderName: hasCompoundController() ? compoundController.transactions[0].transFolder.folderName : aexTransactionHandler.transactionFolder.folderName,
        transactionFolderId: hasCompoundController() ? compoundController.transactions[0].transFolder.id : aexTransactionHandler.transactionFolder.id
    };
    seleniumJson.meta = meta;
    seleniumJson.pages = [];
    seleniumJson.pages_recipient = [];
    seleniumJson.clickedSDs = [];
    seleniumJson.clickedSDs_recipient = [];
    seleniumJson.attachmentList = [];
    seleniumJson.sigData = [];
    sendMsgforRecord();
    recordNewPage();
}

// Below is script for playback

function runJS(element) {

    if (element != null) {
        try {
            if (typeof element.runOnChangeJS == "function") {
                element.runOnChangeJS();
            }

            if (typeof element.runOnBlurJS == "function") {
                element.runOnBlurJS();
            }
        } catch (err) {
            console.log("Encounter runJS error: " + err);
        }
    }
}

function transposeValue(id) {
    getAgreementInterface().transpose(id);
}

function changeFieldValue(field) {
    var name = field.name;
    var id = field.id;
    var text = field.options;
    var iframeElement = ext_getFieldByName(name);

    if (iframeElement) {
        console.log("Entering Data...");
        ext_setValueByName(name, text);
        runJS(iframeElement);
        transposeValue(id);
        numberFormatField(iframeElement);
        console.log("Field '" + name + "' value: " + iframeElement.value);
    } else {
        console.log("Field '" + name + "' is not found, skipped!");
    }
}

function clickElementById(id) {
    var iframeElement = getDocument().getElementById(id);
    var field = ext_getFieldById(id);

    if (iframeElement) {
        console.log("Entering Data...");
        runJS(field);
        iframeElement.click();
        console.log("Click Element: " + iframeElement.name);
    } else {
        console.log("Field '" + id + "' is not found, skipped!");
    }
}

function enterSignatureBySigId(sigId) {
    console.log("Entering Signatures: " + sigId);
    getAgreementInterface().signatureClicked(sigId.substring(0, sigId.length - 5));

    if (hasCompoundController()) {
        var signDialog = document.querySelector("ae-dialog-sign#signDialog");
        if (signDialog && signDialog.opened) {
            var sigInfo = getSignatureInfoFromUploadedJson(sigId);
            if (sigInfo.password) {
                signDialog.password = sigInfo.password;
                signDialog.sign();
            } else {
                signDialog.close();
            }
        }
    } else {
        var signDialog = document.querySelector("#dialogIT-popup");
        if (signDialog && isVisible(signDialog)) {
            var sigInfo = getSignatureInfoFromUploadedJson(sigId);
            if (sigInfo.password) {
                signDialog.querySelector("input#password").value = sigInfo.password;
                var signButton = signDialog.querySelector("a#acceptbutton");
                if(signButton){
                    signButton.click();
                }
            } else {
                var cancelButton = signDialog.querySelector("a[data-rel=back]");
                if(cancelButton){
                    cancelButton.click();
                }
            }
        }
    }

}

function getSignatureInfoFromUploadedJson(sigId) {
    var sigInfo = {};

    if (hasCompoundController()) {
        var svg = getDocument().getElementById(sigId);
        var user = svg ? svg.querySelectorAll("tspan")[svg.querySelectorAll("tspan").length - 1].innerHTML : "";
    } else {
        var user = document.querySelector("#dialogIT-popup input#signer").value;
    }


    if (uploadedJson.sigData.length) {
        uploadedJson.sigData.forEach(sig => {
            if (sigId.includes(sig.sigId) || user === sig.user) {
                sigInfo = sig;
            }
        });

    } else {
        //to do - no sig info
    }

    return sigInfo;
}

function pageFill(pageIndex) {
    updateTempDocNameID();
    console.log("---Start Page #" + (pageIndex + 1));
    msgBox.show();
    msgBox.print("Start filling page #" + (pageIndex + 1));

    if (getUploadedJsonPages().length !== 0 && getUploadedJsonPages()[pageIndex].entries.length !== 0) {
        enterFieldEntryByPage(pageIndex, 0);
    } else {
        preparePlaybackNextPage(pageIndex);
    }
}

function enterFieldEntryByPage(pageIndex, entryIndex) {
    if (!playback) {
        return;
    }

    const uFieldRegex = /^uField_(\d+|\d+\_\d+)$/;
    var pageEntry = getUploadedJsonPages()[pageIndex].entries;
    var field = pageEntry[entryIndex];
    var fieldElement = field.id ? getDocument().getElementById(field.id) : getDocument().getElementsByName(field.name)[0];

    if (!field.isAssert) {
        if (isPageSD() && field.subPageNo && getAgreementInterface().currentDoc.currentPage !== field.subPageNo) {
            switchSubPageAndContinueEnterField(pageIndex, entryIndex, field.subPageNo);
            return;
        } 

        if (demoMode) {
            scrollPageToCenterField(fieldElement);
        }

        if (field.tagName === "INPUT" || field.tagName === "SELECT" || field.tagName === "TEXTAREA") {
            changeFieldValue(field);
        } else if (field.tagName === "A" && field.id.match(uFieldRegex)) {
            if (!isNextBtn(getDocument().getElementById(field.id))) {
                clickElementById(field.id);
            }
        } else if (field.tagName === "svg") {
            enterSignatureBySigId(field.id);
        }
    }

    goingToNextEntry(pageIndex, entryIndex + 1, field.isAssert);  
    
}

function switchSubPageAndContinueEnterField(pageIndex, entryIndex, subPageNo) {
    if(hasCompoundController()) {
        compoundController.clickedToPage(subPageNo);
    }
    
    setTimeout(() => {            
        enterFieldEntryByPage(pageIndex, entryIndex);
    }, 1000);
}

function goingToNextEntry(pageIndex, entryIndex, isAssert) {

    var pageEntry = getUploadedJsonPages()[pageIndex].entries;

    if (entryIndex < pageEntry.length) {
        if (demoMode && !isAssert) {
            setTimeout(() => {
                enterFieldEntryByPage(pageIndex, entryIndex);
            }, 1000);
        } else {
            enterFieldEntryByPage(pageIndex, entryIndex);
        }

    } else {
        preparePlaybackNextPage(pageIndex);
    }
}

function preparePlaybackNextPage(pageIndex) {
    if (isPageSD()) {
        var SDIndex = checkCurSDIndexInClickedSDs();
        if (SDIndex !== -1) {
            fillClickedSDPages(SDIndex + 1);
        }
    } else {
        if (pauseMode) {
            msgBox.showResumeBtn();
        } else {
            if (pageIndex == (getUploadedJsonPages().length - 1)) { //this is the last page of LPs when there is no SDs
                sendCompleteMessageIfNoRecipientMode();
            } else {
                continuePlaybackIfNoErrors();
            }
        }
    }
}

function sendCompleteMessageIfNoRecipientMode() {
    if (curDocInfo.status < 15 && uploadedJson.sendPanelInfo) {
        if (curDocInfo.viewer == "mv2") {
            enterRecipientEmails();
            attemptOpenSendPanel();
        } else {
            sendToRecipientFromSimq();
        }

    } else {
        sendCompleteMessage();
    }
}

function attemptOpenSendPanel(prevDocId) {
    if (isPageSD()) {
        compoundController.launchCorrectPanel()
    } else {
        getAgreementInterface().navigationNext();
    }

    setTimeout(() => {
        if (detectSaveAndSendPanel()) {
            sendAgreementToRecipient();
        } else {
            var curDocId = LocateCurDocId();
            if (isPageSD() || (prevDocId && prevDocId === curDocId)) {
                sendErrorMessage(7);
            } else {
                if (curDocId !== getAgreementInterface().agreements[getAgreementInterface().agreements.length - 1].docId) {
                    attemptOpenSendPanel(curDocId);
                } else {
                    sendErrorMessage(7);
                }
            }
        }
    }, 1000);
}

function sendToRecipientFromSimq() {
    getAgreementInterface().saveAndSend();
    setTimeout(() => {
        console.log(document.querySelector("#publishedAgreement-popup") && isVisible(document.querySelector("#publishedAgreement-popup")));
        if (document.querySelector("#publishedAgreement-popup") && isVisible(document.querySelector("#publishedAgreement-popup"))) {
            sendMsgToContentScript("FROM_PAGE_START_PLAYBACK_RECIPIENT");
            msgBox.print("Open transaction in recipient mode in 5s...")
            setTimeout(() => {
                window.close();
            }, 3000);            
        }
    }, 4000);
}

function sendAgreementToRecipient() {
    var sendPanel = document.querySelector("ae-dialog-save-send");

    if (sendPanel) {
        removeEmptyUserBlock();
        sendPanel.ccList = uploadedJson.sendPanelInfo.ccList;
        sendPanel.subiect = uploadedJson.sendPanelInfo.subiect;
        sendPanel.message = uploadedJson.sendPanelInfo.message;
        sendPanel.createAgreement();
        sendMsgToContentScript("FROM_PAGE_START_PLAYBACK_RECIPIENT");
        detectPublishedDialogAndClosePage();
    } else {
        sendErrorMessage(7);
    }
}

function detectPublishedDialogAndClosePage() {
    var publishedDialog = document.querySelector("ae-dialog-published-agreement");
    if (publishedDialog) {
        window.close();
    } else {
        setTimeout(() => {
            detectPublishedDialogAndClosePage();
        }, pageWaitTime);
    }
}

function enterRecipientEmails() {
    var recipientList = uploadedJson.sendPanelInfo.recipientList;
    recipientList.forEach(recipient => {
        getAgreementInterface().swapSigEmails(recipient.originalLabel, replaceEmailHostName(recipient.email));
    });
}

function removeEmptyUserBlock() {
    var sendPanel = document.querySelector("ae-dialog-save-send");

    if (sendPanel) {
        sendPanel.querySelectorAll("ae-user-block").forEach(userBlock => {
            if (!userBlock.email.includes("@qa.aexclienttest.net")) {
                sendPanel.removeEmail = userBlock.email;
                sendPanel.doRemoveRecipient();
            }
        })
    } else {
        sendErrorMessage(7);
    }

}

function replaceEmailHostName(email) {
    return email.split("@")[0] + "@qa.aexclienttest.net";
}

function continuePlaybackIfNoErrors() {
    setTimeout(() => {
        //check if current Page has errors
        if (detectErrorDialog()) {
            msgBox.showResumeBtn(true);
        } else {
            continueToNextPage();
        }
    }, 500);
}

function continueToNextPage() {

    var nextBtn = locateNextBtn();
    if (nextBtn) {
        msgBox.print("Going to next page...");
        nextBtn.click();
        waitforPageChange();
    } else {
        sendErrorMessage(3);
    }
}

function resumePlayback() {

    msgBox.hideResumeBtn();

    if (isPageSD()) {
        autoCloseSwitchDocDialog();
        sendCompleteMessageIfNoRecipientMode();
    } else {
        if (LocateCurDocName() === getUploadedJsonPages()[getUploadedJsonPages().length - 1].docName) {
            sendCompleteMessageIfNoRecipientMode();
        } else {
            var nextBtn = locateNextBtn();
            if (nextBtn != null) {
                nextBtn.click();
                waitforPageChange();
            } else {
                sendErrorMessage(3);
            }
        }
    }
}

function waitForElementToDisplayForPlayBack(pageName) {
    if (!playback) {
        console.log("Stop called in WFED");
        removeAllListeners();

    } else if (checkPageLoadedByDom(pageName)) {
        setTimeout(() => {
            pageLoadCounter = 0;
            FindPageEntryInJSON();
            console.log("Page load complete");
            msgBox.print("Playback --" + pageName);
        }, pageLoadedDelay);
    } else {
        if (hasExceedWaitTime(pageLoadCounter)) {
            console.log("Stop waiting page load.");
            pageLoadCounter = 0;
        } else {
            pageLoadCounter++;
            setTimeout(function () {
                waitForElementToDisplayForPlayBack(pageName);
            }, pageWaitTime);
        }
    }
}

function FindPageEntryInJSON() {
    var docName = LocateCurDocName();

    for (var i = 0; i < getUploadedJsonPages().length; i++) {
        if (getUploadedJsonPages()[i].docName === docName) {
            try {
                pageFill(i);
            } catch (err) {
                console.log(err);
                sendErrorMessage(2);
            }
            return;
        }
    }

    if(playback){
        sendErrorMessage(4);
    } else {
        msgBox.print("Playback stopped!");
    }
    
}

function isPageSD() {
    var nextBtn = locateNextBtn();
    var symbol = false;
    if (hasCompoundController()) {
        var fields = document.querySelectorAll('ae-bubble-item');
        for (var i = 0; i < fields.length; i++) {
            if (fields[i].className.includes("ae-bubble")) {
                symbol = true;
                break;
            }
        }
    } else {
        var fields = document.querySelectorAll('div#documentsListHolder');
        symbol = (fields.length > 0);
    }

    return !nextBtn && symbol;
}

function startFillingPages() {

    if (isPageSD()) {
        autoCloseSwitchDocDialog();
        fillClickedSDPages(0);
    } else {
        FindPageEntryInJSON();
    }
}

function fillClickedSDPages(index) {
    if (index >= getUploadedJsonClickedSDs().length) { // last page of all clicked SDs
        autoCloseSwitchDocDialog();
        if (pauseMode) {
            msgBox.showResumeBtn(false);
        } else {
            sendCompleteMessageIfNoRecipientMode();
        }

    } else {
        switchedDocForSD(getUploadedJsonClickedSDs()[index].docName);
        autoCloseSwitchDocDialog();

        setTimeout(() => {
            FindPageEntryInJSON();
        }, 1000);
    }
}

function switchedDocForSD(docName) {
    for (var i = 0; i < getAgreementInterface().agreements.length; i++) {
        if (getAgreementInterface().agreements[i].docName === docName) {
            getAgreementInterface().switchDoc(getAgreementInterface().agreements[i].docID);
        }
    }
}

function checkCurSDIndexInClickedSDs() {
    var curDocName = LocateCurDocName();
    for (var i = 0; i < getUploadedJsonClickedSDs().length; i++) {
        if (getUploadedJsonClickedSDs()[i].docName === curDocName) {
            return i;
        }
    }
    return -1;
}

function detectErrorDialog() {
    var errorDialog = hasCompoundController() ? document.querySelector("ae-dialog-error-message") : document.getElementById("errorMsgPopup");
    return errorDialog && isVisible(errorDialog);
}

function detectSaveAndSendPanel() {
    var sendPanel = hasCompoundController() ? document.querySelector("ae-dialog-save-send") : document.querySelector("div#sendMail");
    return sendPanel && isVisible(sendPanel);
}

function autoCloseSwitchDocDialog() {
    if (hasCompoundController()) {  //for MV2
        var dialog = document.querySelectorAll("p");
        for (var i = 0; i < dialog.length; i++) {
            if (dialog[i].className.includes("ae-dialog-switch-document") && isVisible(dialog[i])) {
                document.getElementById("no").click();
                break;
            }
        }
    } else {  //for SIMQ
        if (typeof document.getElementById("systemMessage") !== "undefined" && isVisible(document.getElementById("systemMessage"))) {
            $('#systemMessage').popup('close');
        }
    }
}

function spinner(condition, msg) {
    condition = condition ? "show" : "hide";
    if (hasCompoundController()) {
        compoundController.currentTransaction.showSpinner(condition, {
            text: msg,
            theme: "a",
            textVisible: true
        });
    } else {
        $.mobile.loading(condition, {
            text: msg,
            theme: "a",
            textVisible: true
        });
    }
}

function hasExceedWaitTime(counter) {
    return counter >= (totalWaitTime / pageWaitTime);
}

function checkPageLoadedByDom(pageName) {
    return hasCompoundController() ?
        getHTMLWidget(getLastLoadedWidget(pageName).id) && LocateCurDocName() === pageName :
        getAgreementInterface().seleniumQueue.length === getPageNumberByName(pageName);
}

function checkPageLoadedByBtn(previousBtn) {
    const nextBtn = locateNextBtn();
    const docName = LocateCurDocName();
    return typeof nextBtn !== "undefined" && nextBtn !== previousBtn && docName !== tempDocName;
}

function checkPageInitialLoad() {
    return getCurrentTransaction() && getCurrentTransaction().$ ?
        getCurrentTransaction().$('#fieldContainer').children().length !== 0 :
        false;
}

function getLastLoadedWidget(pageName) {
    const page = getAgreementPageByName(pageName).PAGE[0];
    return getLastValidWidget(page.AbsFields) || getLastValidWidget(page.DivFields) || getLastValidWidget(page.RelFields);
}

function getLastValidWidget(widgetArr) {
    if (widgetArr.length <= 0)
        return null;
    let widget;

    for (var i = widgetArr.length - 1; i >= 0; i--) {
        if (widgetArr[i].type <= 15) {
            widget = widgetArr[i];
            break;
        }
    }

    return typeof widget !== "undefined" ? widget : null;
}

function getAgreementPageByName(pageName) {
    const pages = getAgreementInterface().agreements;
    for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        if (page.docName == pageName)
            return page;
    }
    return null;
}

function getPageNumberByName(pageName) {
    const pages = getAgreementInterface().agreements;
    for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        if (page.docName == pageName)
            return i + 1;
    }
    return null;
}

function getHTMLWidget(id) {
    return getDocument().querySelector('[data-uid=' + id + ']');
}

function numberFormatField(widget) {
    const formattedValue = getAgreementInterface().formatNumberFormatField(widget.getId(), widget, widget.getValue());
    widget.setValue(formattedValue);
}

function hasCompoundController() {
    return typeof compoundController !== "undefined";
}

function getAgreementInterface() {
    return hasCompoundController() ? compoundController.currentTransaction.agreementInterface :
        (typeof agreementInterface !== "undefined" ? agreementInterface : null);
}

function getCurrentTransaction() {
    return hasCompoundController() ? compoundController.currentTransaction : this;
}

function getDocument() {
    return hasCompoundController() ? compoundController.currentTransaction.document : document;
}

function ext_setValueByName(name, value) {
    if (hasCompoundController()) {
        compoundController.currentTransaction.setFieldValueByName(name, value);
    } else {
        setFieldValueByName(name, value);
    }
}

function ext_getValueByName(name) {
    return hasCompoundController() ? compoundController.currentTransaction.getFieldValueByName(name) : getFieldValueByName(name);
}

function ext_getFieldByName(name) {
    return hasCompoundController() ? compoundController.currentTransaction.getFieldByName(name) : getFieldByName(name);
}

function ext_getFieldById(id) {
    return hasCompoundController() ? compoundController.currentTransaction.getFieldById(id) : getFieldById(id);
}

function continueRecordAfterPageUpdate(data) {
    console.log("Recevied message from extension - continue recording");
    msgBox.print("Continue recording");
    seleniumJson = data.json;
    stop = false;
    recordNewPage();
}

function getSeleniumJsonClickedSDs() {
    return (curDocInfo.status) < 15 ? seleniumJson.clickedSDs : seleniumJson.clickedSDs_recipient;
}

function getUploadedJsonClickedSDs() {
    return (curDocInfo.status) < 15 ? uploadedJson.clickedSDs : uploadedJson.clickedSDs_recipient;
}

//==============old code===================


function pageFill_old(pageIndex) {
    updateTempDocNameID();
    msgBox.show();
    console.log("---Start Page #" + (pageIndex + 1));
    var uFieldRegex = /^uField_(\d+|\d+\_\d+)$/;
    var pageEntry = getUploadedJsonPages()[pageIndex].entries;

    for (var i = 0; i < pageEntry.length; i++) {
        if (!playback) {
            return;
        }
        var field = pageEntry[i];

        if ((!field.isDisabled && !field.isAssert) || (field.isRequired && field.isAssert)) {
            if (field.name === "No name") {
                continue;
            }

            if (field.tagName === "INPUT" && field.type === 'text' || field.tagName === "TEXTAREA") {
                changeFieldValue(field.name, field.options);
            } else if (field.tagName === "INPUT" && field.type === 'radio') {
                clickRadioButton(field.name, field.options);
            } else if (field.tagName === "INPUT" && field.type === 'checkbox') {
                clickCheckBox(field.name, field.options);
            } else if (field.tagName === "SELECT") {
                selectElement(field.name, field.options)
            } else if (field.tagName === "A" && field.id.match(uFieldRegex)) {
                if (!isNextBtn(getDocument().getElementById(field.id))) {
                    clickElementById(field.id);
                }
            } else if (field.tagName === "svg") {
                enterSignatureBySigId(field.id);
            }
        } //end of entering data for each entry                                  
    }// end of for loop for page entries

    console.log("---Completed Page #" + (pageIndex + 1));
    msgBox.print("Finished filling page #" + (pageIndex + 1));

    preparePlaybackNextPage(pageIndex);
}

function saveFieldToPageEntry_old(element, prefill) {

    const datePickerRegex = /^aexDatePicker.*$/;
    var className = element.className;
    var value = element.value;
    var fieldName = element.name;
    var isDatePicker = false;
    var selectOptions = "";

    if (element.disabled) {
        return;
    }

    if (fieldName === "" && element.tagName !== "A" && element.tagName !== "svg") {
        return;
    }

    //record textarea
    if (element.tagName === "TEXTAREA") {
        if (isEmpty(value)) {
            return;
        } else {
            selectOptions = value;
        }
    }

    //record dropdownlist
    if (element.tagName === "SELECT") {
        if (getSelectedOptionValue(element) === "") {
            return;
        } else {
            selectOptions = getSelectedOptionValue(element);
        }
    }

    //record text box
    if (element.tagName === "INPUT" && element.getAttribute("type") === "text") {
        if (isEmpty(value)) {
            return;
        } else {
            selectOptions = value;
        }
    }

    //record checkbox
    if (element.tagName === "INPUT" && element.getAttribute("type") === "checkbox") {
        selectOptions = element.checked;
    }

    //record radio button
    if (element.getAttribute("type") === "radio") {
        selectOptions = getCheckedRadioButton(fieldName);
    }

    var entry = {
        tagName: element.tagName,
        name: fieldName,
        options: selectOptions,
        isDate: isDatePicker,
        type: element.getAttribute("type"),
        id: element.id,
        isAssert: prefill ? prefill : false,
        isRequired: (element.classList.contains("required"))
    };

    if (isPageSD()) {
        entry.subPageNo = getAgreementInterface().currentDoc.currentPage;
    }

    addEntryToArray(entry);
}

function getSelectOptions(select) {
    let arr = [];
    for (var i = 0; i < select.length; i++) {
        arr.push(select[i].value);
    }
    return arr;
}

function getSelectedOptionValue(select) {
    if (select.selectedIndex == -1) {
        return getSelectOptions(select)
    }
    return select.options[select.selectedIndex].value;
}


function getCheckedRadioButton(radio) {
    var radioOptions = getDocument().getElementsByName(radio);
    for (var i = 0; i < radioOptions.length; i++) {
        if (radioOptions[i].checked) {
            // +1 as we do -1 in the iavamethod
            return i + 1;
        }
    }
}


function clickRadioButton(name, option) {
    var iframeElements = getDocument().getElementsByName(name);
    var field = ext_getFieldByName(name);

    if (typeof iframeElements !== "undefined" && iframeElements.length >= option) {
        console.log("Entering Data...");
        iframeElements[option - 1].click();
        runJS(field);
        console.log("Click Element: " + name);
    } else {
        console.log("Field '" + name + "' is not found, skipped!");
    }
}

function clickCheckBox(name, value) {
    var iframeElements = getDocument().getElementsByName(name);
    var field = ext_getFieldByName(name);

    if (iframeElements && iframeElements.length !== 0) {
        for (var i = 0; i < iframeElements.length; i++) {
            if (iframeElements[i].checked != value) {
                console.log("Entering Data...");
                iframeElements[i].click();
                runJS(field);
                console.log("Click Element: " + name);
            }
        }
    } else {
        console.log("Field '" + name + "' is not found, skipped!");
    }

}

function selectElement(name, valueToSelect) {
    var field = ext_getFieldByName(name);

    if (field) {
        console.log("Entering Data...");
        ext_setValueByName(name, valueToSelect);
        runJS(field);
        field.runOnChangeJS();
        console.log("Field '" + name + "' value: " + valueToSelect);
    }
}