/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"options": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/options.js","vendor"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/css-loader/index.js!./src/App.css":
/*!***********************************************!*\
  !*** ./node_modules/css-loader!./src/App.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".App {\n  text-align: center;\n}\n\n.App-logo {\n  animation: App-logo-spin infinite 20s linear;\n  height: 5vmin;\n  margin: 15px 20px 0 20px;\n}\n\n.App-header {\n  min-height: 15vh;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center; \n  text-align: center;\n  font-size: calc(15px + 2vmin);\n  color: white;\n  margin: 20px 40px 10px 40px;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n.ant-upload-list-item {\n  border-left: 2px solid #999;\n  background: #ffe0b2;\n}\n\n.ant-layout-header {\n  background-color: rgb(40, 44, 52) !important;\n}\n\n.ant-card-head {\n  background-color: #ffb74d !important;\n}\n\n.instructionDiv {\n  min-height: 200px;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js!./src/index.css":
/*!*************************************************!*\
  !*** ./node_modules/css-loader!./src/index.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "body {\n  margin: 0;\n  padding: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", \"Roboto\", \"Oxygen\",\n    \"Ubuntu\", \"Cantarell\", \"Fira Sans\", \"Droid Sans\", \"Helvetica Neue\",\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, \"Courier New\",\n    monospace;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/App.css":
/*!*********************!*\
  !*** ./src/App.css ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-loader!./App.css */ "./node_modules/css-loader/index.js!./src/App.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_SiderPanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/SiderPanel */ "./src/components/SiderPanel.js");
/* harmony import */ var _components_FooterPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/FooterPanel */ "./src/components/FooterPanel.js");
/* harmony import */ var _components_PageRouter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/PageRouter */ "./src/components/PageRouter.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








var App =
/*#__PURE__*/
function (_Component) {
  _inherits(App, _Component);

  function App(props) {
    var _this;

    _classCallCheck(this, App);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(App).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "changePage", function (_ref) {
      var key = _ref.key;

      _this.setState(function () {
        return {
          page: key
        };
      });
    });

    _this.state = {
      page: "editor"
    };
    return _this;
  }

  _createClass(App, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_5__["Layout"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_SiderPanel__WEBPACK_IMPORTED_MODULE_2__["default"], {
        changePage: this.changePage
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_5__["Layout"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_PageRouter__WEBPACK_IMPORTED_MODULE_4__["default"], {
        page: this.state.page
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_FooterPanel__WEBPACK_IMPORTED_MODULE_3__["default"], null)));
    }
  }]);

  return App;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (App);

/***/ }),

/***/ "./src/components/EditorInstruction.js":
/*!*********************************************!*\
  !*** ./src/components/EditorInstruction.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }



var Step = antd__WEBPACK_IMPORTED_MODULE_1__["Steps"].Step;

var EditorInstruction =
/*#__PURE__*/
function (_React$Component) {
  _inherits(EditorInstruction, _React$Component);

  function EditorInstruction() {
    _classCallCheck(this, EditorInstruction);

    return _possibleConstructorReturn(this, _getPrototypeOf(EditorInstruction).apply(this, arguments));
  }

  _createClass(EditorInstruction, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        style: {
          paddingTop: "50px"
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        span: 4
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        span: 16,
        align: "middle"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Steps"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Step, {
        status: "finish",
        title: "Upload",
        icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "upload"
        }),
        description: "Upload your Json file"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Step, {
        status: "finish",
        title: "View",
        icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "solution"
        }),
        description: "View data for each document"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Step, {
        status: "finish",
        title: "Edit",
        icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "edit"
        }),
        description: "Edit, add, remove data entries"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Step, {
        status: "finish",
        title: "Download",
        icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "download"
        }),
        description: "Download your Json file"
      }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        span: 4
      }));
    }
  }]);

  return EditorInstruction;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (EditorInstruction);

/***/ }),

/***/ "./src/components/FileUpload.js":
/*!**************************************!*\
  !*** ./src/components/FileUpload.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _MetaInfoCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MetaInfoCard */ "./src/components/MetaInfoCard.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var Dragger = antd__WEBPACK_IMPORTED_MODULE_1__["Upload"].Dragger;

var FileUpload =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FileUpload, _React$Component);

  function FileUpload() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, FileUpload);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(FileUpload)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "state", {
      fileList: [],
      uploadedJson: {}
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleUpload", function () {
      var fileName = _this.state.fileList[0].name;

      _this.readFile(_this.state.fileList[0]).then(function (json) {
        _this.setState({
          uploadedJson: json
        });

        _this.props.setUploadedJson(json, fileName);
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "readFile", function (file) {
      return new Promise(function (resolve) {
        var fileReader = new FileReader();

        fileReader.onload = function (e) {
          resolve(JSON.parse(e.target.result));
        };

        fileReader.readAsText(file);
      });
    });

    return _this;
  }

  _createClass(FileUpload, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var showCard = this.state.fileList.length !== 0;
      var json = this.state.uploadedJson;
      var metaInfo = json.meta ? json.meta : {};
      var metaInfoVisible = json.meta != null;
      var pageNum = json.meta ? (json.pages ? json.pages.length : 0) + (json.pages_recipient ? json.pages_recipient.length : 0) : 0;
      var props = {
        accept: ".json",
        onRemove: function onRemove(file) {
          _this2.setState(function (_ref) {
            var fileList = _ref.fileList;
            var index = fileList.indexOf(file);
            var newFileList = fileList.slice();
            newFileList.splice(index, 1);
            return {
              fileList: newFileList
            };
          });

          _this2.setState({
            uploadedJson: {}
          });

          _this2.props.setUploadedJson({});
        },
        beforeUpload: function beforeUpload(file) {
          _this2.props.setUploadedJson({});

          _this2.setState({
            fileList: [file]
          });

          setTimeout(function () {
            _this2.handleUpload();
          }, 100);
          return false;
        },
        fileList: this.state.fileList
      };
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Dragger, _extends({}, props, {
        style: {
          background: '#ffb74d'
        }
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
        className: "ant-upload-drag-icon"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        type: "inbox"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
        className: "ant-upload-text"
      }, "Click or drag file to this area to upload"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
        className: "ant-upload-hint"
      }, "Please use JSON file from AEX Reccorder")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_MetaInfoCard__WEBPACK_IMPORTED_MODULE_2__["default"], {
        show: showCard,
        meta: metaInfo,
        numOfPages: pageNum,
        visible: metaInfoVisible
      }));
    }
  }]);

  return FileUpload;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (FileUpload);

/***/ }),

/***/ "./src/components/FooterPanel.js":
/*!***************************************!*\
  !*** ./src/components/FooterPanel.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }



var Footer = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Footer;

var FooterPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FooterPanel, _React$Component);

  function FooterPanel() {
    _classCallCheck(this, FooterPanel);

    return _possibleConstructorReturn(this, _getPrototypeOf(FooterPanel).apply(this, arguments));
  }

  _createClass(FooterPanel, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Footer, {
        style: {
          textAlign: 'center'
        }
      }, "Test \xA92018 AEX Recorder");
    }
  }]);

  return FooterPanel;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (FooterPanel);

/***/ }),

/***/ "./src/components/HeaderPanel.js":
/*!***************************************!*\
  !*** ./src/components/HeaderPanel.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }



var Header = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Header;

var HeaderPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(HeaderPanel, _React$Component);

  function HeaderPanel() {
    _classCallCheck(this, HeaderPanel);

    return _possibleConstructorReturn(this, _getPrototypeOf(HeaderPanel).apply(this, arguments));
  }

  _createClass(HeaderPanel, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Header, {
        className: "App-header"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.props.title));
    }
  }]);

  return HeaderPanel;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (HeaderPanel);

/***/ }),

/***/ "./src/components/JsonEditor.js":
/*!**************************************!*\
  !*** ./src/components/JsonEditor.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _HeaderPanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./HeaderPanel */ "./src/components/HeaderPanel.js");
/* harmony import */ var _FileUpload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FileUpload */ "./src/components/FileUpload.js");
/* harmony import */ var _PagesTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PagesTab */ "./src/components/PagesTab.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! file-saver */ "./node_modules/file-saver/dist/FileSaver.min.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _EditorInstruction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./EditorInstruction */ "./src/components/EditorInstruction.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_modal_locale__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! antd/lib/modal/locale */ "./node_modules/antd/lib/modal/locale.js");
/* harmony import */ var antd_lib_modal_locale__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal_locale__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _util_ChromeUitl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../util/ChromeUitl */ "./src/util/ChromeUitl.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











var Content = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Content;

var JsonEditor =
/*#__PURE__*/
function (_React$Component) {
  _inherits(JsonEditor, _React$Component);

  function JsonEditor(props) {
    var _this;

    _classCallCheck(this, JsonEditor);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(JsonEditor).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setUploadedJson", function (json, fileName) {
      _util_ChromeUitl__WEBPACK_IMPORTED_MODULE_9__["ChromeUtil"].sendMessage("caonima");

      if (json.meta) {
        _this.setState({
          originalJson: json,
          displayPages: true,
          fileName: fileName
        });
      } else {
        _this.setState({
          originalJson: {},
          displayPages: false,
          fileName: ""
        });
      }
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "updateRevisedJson", function (json) {
      if (json.meta) {
        _this.setState({
          revisedJson: json
        });
      }
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "downloadRevisedJson", function () {
      console.log("downloading");
      var json = JSON.stringify(_this.state.revisedJson, null, 2);
      var blob = new Blob([json], {
        type: "application/json"
      });
      file_saver__WEBPACK_IMPORTED_MODULE_5___default()(blob, _this.state.fileName.split(".")[0] + "-REVISED.json");
    });

    _this.state = {
      originalJson: {},
      revisedJson: {},
      displayPages: false,
      fileName: ""
    };
    _this.setUploadedJson = _this.setUploadedJson.bind(_assertThisInitialized(_assertThisInitialized(_this)));
    _this.updateRevisedJson = _this.updateRevisedJson.bind(_assertThisInitialized(_assertThisInitialized(_this)));
    _this.downloadRevisedJson = _this.downloadRevisedJson.bind(_assertThisInitialized(_assertThisInitialized(_this)));
    return _this;
  }

  _createClass(JsonEditor, [{
    key: "render",
    value: function render() {
      var downloadBtnDisable = !this.state.revisedJson.meta ? true : false;
      var pageDisplay = this.state.displayPages ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_PagesTab__WEBPACK_IMPORTED_MODULE_4__["default"], {
        json: this.state.originalJson,
        updateRevisedJson: this.updateRevisedJson
      }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EditorInstruction__WEBPACK_IMPORTED_MODULE_6__["default"], null);
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Layout"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HeaderPanel__WEBPACK_IMPORTED_MODULE_2__["default"], {
        title: "AEX Recorder JSON Editor"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Content, {
        style: {
          margin: '0 16px'
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          padding: 24
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        gutter: 16
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        lg: 6,
        span: 24
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          marginRight: '10px'
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FileUpload__WEBPACK_IMPORTED_MODULE_3__["default"], {
        setUploadedJson: this.setUploadedJson
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          margin: '50px 10px 50px 0px'
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        type: "primary",
        icon: "download",
        size: "large",
        onClick: this.downloadRevisedJson,
        block: true,
        disabled: downloadBtnDisable
      }, "Download"))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        lg: 18,
        span: 24
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          marginLeft: '10px',
          minHeight: '68vh',
          background: '#fafafa'
        }
      }, pageDisplay))))));
    }
  }]);

  return JsonEditor;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (JsonEditor);

/***/ }),

/***/ "./src/components/MetaInfoCard.js":
/*!****************************************!*\
  !*** ./src/components/MetaInfoCard.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }




var MetaInfoCard =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MetaInfoCard, _React$Component);

  function MetaInfoCard() {
    _classCallCheck(this, MetaInfoCard);

    return _possibleConstructorReturn(this, _getPrototypeOf(MetaInfoCard).apply(this, arguments));
  }

  _createClass(MetaInfoCard, [{
    key: "render",
    value: function render() {
      var style = this.props.visible ? {
        marginTop: '50px',
        display: 'block'
      } : {
        display: 'none'
      };
      var metaInfo = this.props.meta;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Card"], {
        title: metaInfo.companyName && metaInfo.companyName !== "" ? metaInfo.companyName : "Unkown company",
        style: style,
        hoverable: true
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "Transaction Name: ", metaInfo.transactionName !== "" ? metaInfo.transactionName : "Unkown transaction"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "TransRefId: ", metaInfo.transRefId !== "" ? metaInfo.transRefId : "Unkown transRefId"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "Number of Pages: ", this.props.numOfPages, " "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "Recorder version: ", metaInfo.recorderVersion ? metaInfo.recorderVersion : "Old recorder version"));
    }
  }]);

  return MetaInfoCard;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (MetaInfoCard);

/***/ }),

/***/ "./src/components/PageEntriesTableEditable.js":
/*!****************************************************!*\
  !*** ./src/components/PageEntriesTableEditable.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



var FormItem = antd__WEBPACK_IMPORTED_MODULE_1__["Form"].Item;
var EditableContext = react__WEBPACK_IMPORTED_MODULE_0___default.a.createContext();

var EditableRow = function EditableRow(_ref) {
  var form = _ref.form,
      index = _ref.index,
      props = _objectWithoutProperties(_ref, ["form", "index"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(EditableContext.Provider, {
    value: form
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("tr", props));
};

var EditableFormRow = antd__WEBPACK_IMPORTED_MODULE_1__["Form"].create()(EditableRow);

var EditableCell =
/*#__PURE__*/
function (_React$Component) {
  _inherits(EditableCell, _React$Component);

  function EditableCell() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, EditableCell);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(EditableCell)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "state", {
      editing: false
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "toggleEdit", function () {
      var editing = !_this.state.editing;

      _this.setState({
        editing: editing
      }, function () {
        if (editing) {
          _this.input.focus();
        }
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleClickOutside", function (e) {
      var editing = _this.state.editing;

      if (editing && _this.cell !== e.target && !_this.cell.contains(e.target)) {
        _this.save();
      }
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "save", function () {
      var _this$props = _this.props,
          record = _this$props.record,
          handleSave = _this$props.handleSave;

      _this.form.validateFields(function (error, values) {
        if (error) {
          return;
        }

        _this.toggleEdit();

        handleSave(_objectSpread({}, record, values));
      });
    });

    return _this;
  }

  _createClass(EditableCell, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.props.editable) {
        document.addEventListener('click', this.handleClickOutside, true);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.props.editable) {
        document.removeEventListener('click', this.handleClickOutside, true);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var editing = this.state.editing;

      var _this$props2 = this.props,
          editable = _this$props2.editable,
          dataIndex = _this$props2.dataIndex,
          title = _this$props2.title,
          record = _this$props2.record,
          index = _this$props2.index,
          handleSave = _this$props2.handleSave,
          restProps = _objectWithoutProperties(_this$props2, ["editable", "dataIndex", "title", "record", "index", "handleSave"]);

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("td", _extends({
        ref: function ref(node) {
          return _this2.cell = node;
        }
      }, restProps), editable ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(EditableContext.Consumer, null, function (form) {
        _this2.form = form;
        return editing ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormItem, {
          style: {
            margin: 0
          }
        }, form.getFieldDecorator(dataIndex, {
          rules: [{
            required: true,
            message: "".concat(title, " is required.")
          }],
          initialValue: record[dataIndex]
        })(react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Input"], {
          ref: function ref(node) {
            return _this2.input = node;
          },
          onPressEnter: _this2.save
        }))) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "editable-cell-value-wrap",
          style: {
            paddingRight: 24
          },
          onClick: _this2.toggleEdit
        }, restProps.children);
      }) : restProps.children);
    }
  }]);

  return EditableCell;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

var PageEntriesTableEditable =
/*#__PURE__*/
function (_React$Component2) {
  _inherits(PageEntriesTableEditable, _React$Component2);

  function PageEntriesTableEditable(props) {
    var _this3;

    _classCallCheck(this, PageEntriesTableEditable);

    _this3 = _possibleConstructorReturn(this, _getPrototypeOf(PageEntriesTableEditable).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this3)), "parseData", function (entries) {
      entries.forEach(function (entry, id) {
        entry.key = id;
      });
      return entries;
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this3)), "handleDelete", function (key) {
      var dataSource = _toConsumableArray(_this3.state.dataSource);

      _this3.setState({
        dataSource: dataSource.filter(function (item) {
          return item.key !== key;
        })
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this3)), "handleAdd", function () {
      var dataSource = _this3.state.dataSource;
      var newData = {
        name: 'default',
        id: 'default',
        type: 'text',
        options: 'default',
        tagName: 'INPUT',
        isRequired: false
      };

      _this3.setState({
        dataSource: [newData].concat(_toConsumableArray(dataSource))
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this3)), "handleSave", function (row) {
      var newData = _toConsumableArray(_this3.state.dataSource);

      var index = newData.findIndex(function (item) {
        return row.key === item.key;
      });
      var item = newData[index];
      newData.splice(index, 1, _objectSpread({}, item, row));

      _this3.setState({
        dataSource: newData
      });

      _this3.props.updateRevisedJson(_this3.state);
    });

    _this3.columns = [{
      title: 'FieldName',
      dataIndex: 'name',
      filters: [{
        text: 'business',
        value: 'business'
      }, {
        text: 'company',
        value: 'company'
      }, {
        text: 'owner',
        value: 'owner'
      }],
      onFilter: function onFilter(value, record) {
        return record.name.toLowerCase().indexOf(value) === 0;
      },
      sorter: function sorter(a, b) {
        return a.name.length - b.name.length;
      },
      editable: true
    }, {
      title: 'Field id',
      dataIndex: 'id',
      sorter: function sorter(a, b) {
        return a.id.length - b.id.length;
      },
      editable: true
    }, {
      title: 'Value',
      dataIndex: 'options',
      editable: true
    }, {
      title: 'Delete',
      dataIndex: 'operation',
      render: function render(text, record) {
        return _this3.state.dataSource.length >= 1 ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Popconfirm"], {
          title: "Sure to delete?",
          onConfirm: function onConfirm() {
            return _this3.handleDelete(record.key);
          }
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", null, "Delete")) : null;
      },
      width: 80
    }];
    _this3.state = {
      mode: _this3.props.mode,
      dataSource: _this3.parseData(_this3.props.dataSource),
      pageIndex: _this3.props.pageIndex
    };
    return _this3;
  }

  _createClass(PageEntriesTableEditable, [{
    key: "render",
    value: function render() {
      var _this4 = this;

      var dataSource = this.state.dataSource;
      var components = {
        body: {
          row: EditableFormRow,
          cell: EditableCell
        }
      };
      var columns = this.columns.map(function (col) {
        if (!col.editable) {
          return col;
        }

        return _objectSpread({}, col, {
          onCell: function onCell(record) {
            return {
              record: record,
              editable: col.editable,
              dataIndex: col.dataIndex,
              title: col.title,
              handleSave: _this4.handleSave
            };
          }
        });
      });
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        onClick: this.handleAdd,
        type: "primary",
        style: {
          marginBottom: 16
        }
      }, "Add a new entry"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Table"], {
        components: components,
        rowClassName: function rowClassName() {
          return 'editable-row';
        },
        bordered: true,
        dataSource: dataSource,
        columns: columns,
        rowKey: "key"
      }));
    }
  }]);

  return PageEntriesTableEditable;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (PageEntriesTableEditable);

/***/ }),

/***/ "./src/components/PageRouter.js":
/*!**************************************!*\
  !*** ./src/components/PageRouter.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _JsonEditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JsonEditor */ "./src/components/JsonEditor.js");
/* harmony import */ var _RecorderTools__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./RecorderTools */ "./src/components/RecorderTools.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var PageRouter =
/*#__PURE__*/
function (_React$Component) {
  _inherits(PageRouter, _React$Component);

  function PageRouter() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, PageRouter);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(PageRouter)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "getPage", function () {
      if (_this.props.page === "editor") {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_JsonEditor__WEBPACK_IMPORTED_MODULE_1__["default"], null);
      } else if (_this.props.page === "tools") {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RecorderTools__WEBPACK_IMPORTED_MODULE_2__["default"], null);
      } else {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_JsonEditor__WEBPACK_IMPORTED_MODULE_1__["default"], null);
      }
    });

    return _this;
  }

  _createClass(PageRouter, [{
    key: "render",
    value: function render() {
      return this.getPage();
    }
  }]);

  return PageRouter;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (PageRouter);

/***/ }),

/***/ "./src/components/PagesTab.js":
/*!************************************!*\
  !*** ./src/components/PagesTab.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _PageEntriesTableEditable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PageEntriesTableEditable */ "./src/components/PageEntriesTableEditable.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var TabPane = antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"].TabPane;

var PagesTab =
/*#__PURE__*/
function (_React$Component) {
  _inherits(PagesTab, _React$Component);

  function PagesTab(props) {
    var _this;

    _classCallCheck(this, PagesTab);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(PagesTab).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "generateTable", function (page, index, mode) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TabPane, {
        tab: page.docName,
        key: index
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_PageEntriesTableEditable__WEBPACK_IMPORTED_MODULE_2__["default"], {
        dataSource: page.entries,
        mode: mode,
        pageIndex: index,
        updateRevisedJson: _this.updateRevisedJson
      }));
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "updateRevisedJson", function (newState) {
      _this.setState(function () {
        var index = newState.pageIndex;
        var tempJson = _this.state.uploadedJson;

        if (newState.mode === "publisher") {
          tempJson.pages[index].entries = newState.dataSource;
        } else {
          tempJson.pages_recipient[index].entries = newState.dataSource;
        }

        _this.props.updateRevisedJson(tempJson);

        return {
          uploadedJson: tempJson
        };
      });
    });

    _this.state = {
      uploadedJson: _this.props.json
    };
    _this.updateRevisedJson = _this.updateRevisedJson.bind(_assertThisInitialized(_assertThisInitialized(_this)));
    return _this;
  }

  _createClass(PagesTab, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var pagesLeftTabs_publisher = this.state.uploadedJson.pages.map(function (page, id) {
        return _this2.generateTable(page, id, "publisher");
      });
      var pagesLeftTabs_recipient = this.state.uploadedJson.pages_recipient.map(function (page, id) {
        return _this2.generateTable(page, id, "recipient");
      });
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"], {
        defaultActiveKey: "1"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TabPane, {
        tab: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "smile"
        }), "Publisher Mode"),
        key: "1"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"], {
        defaultActiveKey: "0",
        tabPosition: "left"
      }, pagesLeftTabs_publisher)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TabPane, {
        tab: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          type: "user"
        }), "Recipient Mode"),
        key: "2"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"], {
        defaultActiveKey: "0",
        tabPosition: "left"
      }, pagesLeftTabs_recipient)));
    }
  }]);

  return PagesTab;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (PagesTab);

/***/ }),

/***/ "./src/components/RecorderTools.js":
/*!*****************************************!*\
  !*** ./src/components/RecorderTools.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _HeaderPanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./HeaderPanel */ "./src/components/HeaderPanel.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }




var Content = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Content;

var RecorderTools =
/*#__PURE__*/
function (_React$Component) {
  _inherits(RecorderTools, _React$Component);

  function RecorderTools() {
    _classCallCheck(this, RecorderTools);

    return _possibleConstructorReturn(this, _getPrototypeOf(RecorderTools).apply(this, arguments));
  }

  _createClass(RecorderTools, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Layout"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HeaderPanel__WEBPACK_IMPORTED_MODULE_2__["default"], {
        title: "AEX Recorder JSON Tools"
      }, " "), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Content, {
        style: {
          margin: '0 16px'
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          padding: 24,
          minHeight: 800
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        gutter: 16
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        lg: 12,
        span: 24
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          marginRight: '10px',
          minHeight: 750
        }
      }, "Coming Soon")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
        lg: 12,
        span: 24
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        style: {
          marginLeft: '10px',
          minHeight: 750
        }
      }))))));
    }
  }]);

  return RecorderTools;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (RecorderTools);

/***/ }),

/***/ "./src/components/SiderPanel.js":
/*!**************************************!*\
  !*** ./src/components/SiderPanel.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var Sider = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Sider;

var SiderPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SiderPanel, _React$Component);

  function SiderPanel() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, SiderPanel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(SiderPanel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "state", {
      collapsed: true
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "onCollapse", function (collapsed) {
      _this.setState({
        collapsed: collapsed
      });
    });

    return _this;
  }

  _createClass(SiderPanel, [{
    key: "render",
    value: function render() {
      var LogoDiv = function LogoDiv(props) {
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          style: {
            height: '60px',
            marginLeft: props.collapsed ? '0' : '25%'
          }
        }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
          src: "images/sider-logo.png",
          className: "App-logo",
          alt: "logo"
        }));
      };

      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Sider, {
        collapsible: true,
        collapsed: this.state.collapsed,
        onCollapse: this.onCollapse,
        style: {
          background: '#282c34'
        }
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LogoDiv, {
        collapsed: this.state.collapsed
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"], {
        theme: "dark",
        defaultSelectedKeys: ['editor'],
        mode: "inline",
        style: {
          background: '#282c34'
        },
        onClick: this.props.changePage
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
        key: "editor"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        type: "pie-chart"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "JSON Editor")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
        key: "tools"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        type: "desktop"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Recorder Tools")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
        key: "user"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        type: "user"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "User")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
        key: "setting"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        type: "file"
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Setting"))));
    }
  }]);

  return SiderPanel;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (SiderPanel);

/***/ }),

/***/ "./src/index.css":
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-loader!./index.css */ "./node_modules/css-loader/index.js!./src/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.css */ "./src/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd/dist/antd.css */ "./node_modules/antd/dist/antd.css");
/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./App */ "./src/App.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/es/index.js");






react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render(react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_5__["BrowserRouter"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_App__WEBPACK_IMPORTED_MODULE_4__["default"], null)), document.getElementById('root'));

/***/ }),

/***/ "./src/util/ChromeUitl.js":
/*!********************************!*\
  !*** ./src/util/ChromeUitl.js ***!
  \********************************/
/*! exports provided: ChromeUtil */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChromeUtil", function() { return ChromeUtil; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var ChromeUtil = function ChromeUtil() {
  _classCallCheck(this, ChromeUtil);
};

_defineProperty(ChromeUtil, "sendMessage", function (msg, obj) {
  chrome.runtime.sendMessage({
    message: msg,
    obj: obj
  });
});



/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL0FwcC5jc3MiLCJ3ZWJwYWNrOi8vLy4vc3JjL2luZGV4LmNzcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZSBzeW5jIF5cXC5cXC8uKiQiLCJ3ZWJwYWNrOi8vLy4vc3JjL0FwcC5jc3M/YWQ3YiIsIndlYnBhY2s6Ly8vLi9zcmMvQXBwLmpzIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL0VkaXRvckluc3RydWN0aW9uLmpzIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL0ZpbGVVcGxvYWQuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvRm9vdGVyUGFuZWwuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvSGVhZGVyUGFuZWwuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvSnNvbkVkaXRvci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9NZXRhSW5mb0NhcmQuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvUGFnZUVudHJpZXNUYWJsZUVkaXRhYmxlLmpzIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL1BhZ2VSb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvUGFnZXNUYWIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvUmVjb3JkZXJUb29scy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9TaWRlclBhbmVsLmpzIiwid2VicGFjazovLy8uL3NyYy9pbmRleC5jc3M/ZDhjMyIsIndlYnBhY2s6Ly8vLi9zcmMvb3B0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbC9DaHJvbWVVaXRsLmpzIl0sIm5hbWVzIjpbIkFwcCIsInByb3BzIiwia2V5Iiwic2V0U3RhdGUiLCJwYWdlIiwic3RhdGUiLCJjaGFuZ2VQYWdlIiwiQ29tcG9uZW50IiwiU3RlcCIsIlN0ZXBzIiwiRWRpdG9ySW5zdHJ1Y3Rpb24iLCJwYWRkaW5nVG9wIiwiUmVhY3QiLCJEcmFnZ2VyIiwiVXBsb2FkIiwiRmlsZVVwbG9hZCIsImZpbGVMaXN0IiwidXBsb2FkZWRKc29uIiwiZmlsZU5hbWUiLCJuYW1lIiwicmVhZEZpbGUiLCJ0aGVuIiwianNvbiIsInNldFVwbG9hZGVkSnNvbiIsImZpbGUiLCJQcm9taXNlIiwicmVzb2x2ZSIsImZpbGVSZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiZSIsIkpTT04iLCJwYXJzZSIsInRhcmdldCIsInJlc3VsdCIsInJlYWRBc1RleHQiLCJzaG93Q2FyZCIsImxlbmd0aCIsIm1ldGFJbmZvIiwibWV0YSIsIm1ldGFJbmZvVmlzaWJsZSIsInBhZ2VOdW0iLCJwYWdlcyIsInBhZ2VzX3JlY2lwaWVudCIsImFjY2VwdCIsIm9uUmVtb3ZlIiwiaW5kZXgiLCJpbmRleE9mIiwibmV3RmlsZUxpc3QiLCJzbGljZSIsInNwbGljZSIsImJlZm9yZVVwbG9hZCIsInNldFRpbWVvdXQiLCJoYW5kbGVVcGxvYWQiLCJiYWNrZ3JvdW5kIiwiRm9vdGVyIiwiTGF5b3V0IiwiRm9vdGVyUGFuZWwiLCJ0ZXh0QWxpZ24iLCJIZWFkZXIiLCJIZWFkZXJQYW5lbCIsInRpdGxlIiwiQ29udGVudCIsIkpzb25FZGl0b3IiLCJDaHJvbWVVdGlsIiwic2VuZE1lc3NhZ2UiLCJvcmlnaW5hbEpzb24iLCJkaXNwbGF5UGFnZXMiLCJyZXZpc2VkSnNvbiIsImNvbnNvbGUiLCJsb2ciLCJzdHJpbmdpZnkiLCJibG9iIiwiQmxvYiIsInR5cGUiLCJzYXZlQXMiLCJzcGxpdCIsImJpbmQiLCJ1cGRhdGVSZXZpc2VkSnNvbiIsImRvd25sb2FkUmV2aXNlZEpzb24iLCJkb3dubG9hZEJ0bkRpc2FibGUiLCJwYWdlRGlzcGxheSIsIm1hcmdpbiIsInBhZGRpbmciLCJtYXJnaW5SaWdodCIsIm1hcmdpbkxlZnQiLCJtaW5IZWlnaHQiLCJNZXRhSW5mb0NhcmQiLCJzdHlsZSIsInZpc2libGUiLCJtYXJnaW5Ub3AiLCJkaXNwbGF5IiwiY29tcGFueU5hbWUiLCJ0cmFuc2FjdGlvbk5hbWUiLCJ0cmFuc1JlZklkIiwibnVtT2ZQYWdlcyIsInJlY29yZGVyVmVyc2lvbiIsIkZvcm1JdGVtIiwiRm9ybSIsIkl0ZW0iLCJFZGl0YWJsZUNvbnRleHQiLCJjcmVhdGVDb250ZXh0IiwiRWRpdGFibGVSb3ciLCJmb3JtIiwiRWRpdGFibGVGb3JtUm93IiwiY3JlYXRlIiwiRWRpdGFibGVDZWxsIiwiZWRpdGluZyIsImlucHV0IiwiZm9jdXMiLCJjZWxsIiwiY29udGFpbnMiLCJzYXZlIiwicmVjb3JkIiwiaGFuZGxlU2F2ZSIsInZhbGlkYXRlRmllbGRzIiwiZXJyb3IiLCJ2YWx1ZXMiLCJ0b2dnbGVFZGl0IiwiZWRpdGFibGUiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJoYW5kbGVDbGlja091dHNpZGUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZGF0YUluZGV4IiwicmVzdFByb3BzIiwibm9kZSIsImdldEZpZWxkRGVjb3JhdG9yIiwicnVsZXMiLCJyZXF1aXJlZCIsIm1lc3NhZ2UiLCJpbml0aWFsVmFsdWUiLCJwYWRkaW5nUmlnaHQiLCJjaGlsZHJlbiIsIlBhZ2VFbnRyaWVzVGFibGVFZGl0YWJsZSIsImVudHJpZXMiLCJmb3JFYWNoIiwiZW50cnkiLCJpZCIsImRhdGFTb3VyY2UiLCJmaWx0ZXIiLCJpdGVtIiwibmV3RGF0YSIsIm9wdGlvbnMiLCJ0YWdOYW1lIiwiaXNSZXF1aXJlZCIsInJvdyIsImZpbmRJbmRleCIsImNvbHVtbnMiLCJmaWx0ZXJzIiwidGV4dCIsInZhbHVlIiwib25GaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsInNvcnRlciIsImEiLCJiIiwicmVuZGVyIiwiaGFuZGxlRGVsZXRlIiwid2lkdGgiLCJtb2RlIiwicGFyc2VEYXRhIiwicGFnZUluZGV4IiwiY29tcG9uZW50cyIsImJvZHkiLCJtYXAiLCJjb2wiLCJvbkNlbGwiLCJoYW5kbGVBZGQiLCJtYXJnaW5Cb3R0b20iLCJQYWdlUm91dGVyIiwiZ2V0UGFnZSIsIlRhYlBhbmUiLCJUYWJzIiwiUGFnZXNUYWIiLCJkb2NOYW1lIiwibmV3U3RhdGUiLCJ0ZW1wSnNvbiIsInBhZ2VzTGVmdFRhYnNfcHVibGlzaGVyIiwiZ2VuZXJhdGVUYWJsZSIsInBhZ2VzTGVmdFRhYnNfcmVjaXBpZW50IiwiUmVjb3JkZXJUb29scyIsIlNpZGVyIiwiU2lkZXJQYW5lbCIsImNvbGxhcHNlZCIsIkxvZ29EaXYiLCJoZWlnaHQiLCJvbkNvbGxhcHNlIiwiUmVhY3RET00iLCJnZXRFbGVtZW50QnlJZCIsIm1zZyIsIm9iaiIsImNocm9tZSIsInJ1bnRpbWUiXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdCQUFRLG9CQUFvQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUFpQiw0QkFBNEI7QUFDN0M7QUFDQTtBQUNBLDBCQUFrQiwyQkFBMkI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esa0RBQTBDLGdDQUFnQztBQUMxRTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdFQUF3RCxrQkFBa0I7QUFDMUU7QUFDQSx5REFBaUQsY0FBYztBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQXlDLGlDQUFpQztBQUMxRSx3SEFBZ0gsbUJBQW1CLEVBQUU7QUFDckk7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUFnQix1QkFBdUI7QUFDdkM7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUN0SkEsMkJBQTJCLG1CQUFPLENBQUMsNkZBQTRDO0FBQy9FOzs7QUFHQTtBQUNBLGNBQWMsUUFBUyxTQUFTLHVCQUF1QixHQUFHLGVBQWUsaURBQWlELGtCQUFrQiw2QkFBNkIsR0FBRyxpQkFBaUIscUJBQXFCLGtCQUFrQiwyQkFBMkIsd0JBQXdCLDRCQUE0Qix3QkFBd0Isa0NBQWtDLGlCQUFpQixnQ0FBZ0MsR0FBRyxlQUFlLG1CQUFtQixHQUFHLDhCQUE4QixVQUFVLDhCQUE4QixLQUFLLFFBQVEsZ0NBQWdDLEtBQUssR0FBRywyQkFBMkIsZ0NBQWdDLHdCQUF3QixHQUFHLHdCQUF3QixpREFBaUQsR0FBRyxvQkFBb0IseUNBQXlDLEdBQUcscUJBQXFCLHNCQUFzQixHQUFHOztBQUVqMUI7Ozs7Ozs7Ozs7OztBQ1BBLDJCQUEyQixtQkFBTyxDQUFDLDZGQUE0QztBQUMvRTs7O0FBR0E7QUFDQSxjQUFjLFFBQVMsU0FBUyxjQUFjLGVBQWUsNkxBQTZMLHdDQUF3Qyx1Q0FBdUMsR0FBRyxVQUFVLDJGQUEyRixHQUFHOztBQUVwYjs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2RTs7Ozs7Ozs7Ozs7O0FDM1FBLGNBQWMsbUJBQU8sQ0FBQywrRkFBaUQ7O0FBRXZFLDRDQUE0QyxRQUFTOztBQUVyRDtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBLGFBQWEsbUJBQU8sQ0FBQyxtR0FBZ0Q7O0FBRXJFOztBQUVBLEdBQUcsS0FBVSxFQUFFLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJmO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7SUFFTUEsRzs7Ozs7QUFDSixlQUFZQyxLQUFaLEVBQW1CO0FBQUE7O0FBQUE7O0FBQ2pCLDZFQUFNQSxLQUFOOztBQURpQix5RkFPTixnQkFBYTtBQUFBLFVBQVZDLEdBQVUsUUFBVkEsR0FBVTs7QUFDeEIsWUFBS0MsUUFBTCxDQUFjO0FBQUEsZUFBTztBQUFFQyxjQUFJLEVBQUVGO0FBQVIsU0FBUDtBQUFBLE9BQWQ7QUFDRCxLQVRrQjs7QUFFakIsVUFBS0csS0FBTCxHQUFhO0FBQ1hELFVBQUksRUFBRTtBQURLLEtBQWI7QUFGaUI7QUFLbEI7Ozs7NkJBTVE7QUFDUCxhQUNFLDJEQUFDLDJDQUFELFFBQ0UsMkRBQUMsOERBQUQ7QUFBWSxrQkFBVSxFQUFFLEtBQUtFO0FBQTdCLFFBREYsRUFFRSwyREFBQywyQ0FBRCxRQUNFLDJEQUFDLDhEQUFEO0FBQVksWUFBSSxFQUFFLEtBQUtELEtBQUwsQ0FBV0Q7QUFBN0IsUUFERixFQUVFLDJEQUFDLCtEQUFELE9BRkYsQ0FGRixDQURGO0FBU0Q7Ozs7RUF0QmVHLCtDOztBQXlCSFAsa0VBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDQTtBQUVBO0FBRUEsSUFBTVEsSUFBSSxHQUFHQywwQ0FBSyxDQUFDRCxJQUFuQjs7SUFFTUUsaUI7Ozs7Ozs7Ozs7Ozs7NkJBRU87QUFDTCxhQUNJLDJEQUFDLHdDQUFEO0FBQUssYUFBSyxFQUFFO0FBQUNDLG9CQUFVLEVBQUM7QUFBWjtBQUFaLFNBQ0ksMkRBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUU7QUFBWCxRQURKLEVBRUksMkRBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUUsRUFBWDtBQUFlLGFBQUssRUFBQztBQUFyQixTQUNJLDJEQUFDLDBDQUFELFFBQ0ksMkRBQUMsSUFBRDtBQUFNLGNBQU0sRUFBQyxRQUFiO0FBQXNCLGFBQUssRUFBQyxRQUE1QjtBQUFxQyxZQUFJLEVBQUUsMkRBQUMseUNBQUQ7QUFBTSxjQUFJLEVBQUM7QUFBWCxVQUEzQztBQUFtRSxtQkFBVyxFQUFDO0FBQS9FLFFBREosRUFFSSwyREFBQyxJQUFEO0FBQU0sY0FBTSxFQUFDLFFBQWI7QUFBc0IsYUFBSyxFQUFDLE1BQTVCO0FBQW1DLFlBQUksRUFBRSwyREFBQyx5Q0FBRDtBQUFNLGNBQUksRUFBQztBQUFYLFVBQXpDO0FBQW1FLG1CQUFXLEVBQUM7QUFBL0UsUUFGSixFQUdJLDJEQUFDLElBQUQ7QUFBTSxjQUFNLEVBQUMsUUFBYjtBQUFzQixhQUFLLEVBQUMsTUFBNUI7QUFBbUMsWUFBSSxFQUFFLDJEQUFDLHlDQUFEO0FBQU0sY0FBSSxFQUFDO0FBQVgsVUFBekM7QUFBK0QsbUJBQVcsRUFBQztBQUEzRSxRQUhKLEVBSUksMkRBQUMsSUFBRDtBQUFNLGNBQU0sRUFBQyxRQUFiO0FBQXNCLGFBQUssRUFBQyxVQUE1QjtBQUF1QyxZQUFJLEVBQUUsMkRBQUMseUNBQUQ7QUFBTSxjQUFJLEVBQUM7QUFBWCxVQUE3QztBQUF1RSxtQkFBVyxFQUFDO0FBQW5GLFFBSkosQ0FESixDQUZKLEVBVUksMkRBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUU7QUFBWCxRQVZKLENBREo7QUFjSDs7OztFQWpCMkJDLDRDQUFLLENBQUNMLFM7O0FBb0J2QkcsZ0ZBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJBO0FBRUE7QUFDQTtBQUVBLElBQU1HLE9BQU8sR0FBR0MsMkNBQU0sQ0FBQ0QsT0FBdkI7O0lBRU1FLFU7Ozs7Ozs7Ozs7Ozs7Ozs7OztvRkFDTTtBQUNKQyxjQUFRLEVBQUUsRUFETjtBQUVKQyxrQkFBWSxFQUFFO0FBRlYsSzs7MkZBS08sWUFBTTtBQUNqQixVQUFNQyxRQUFRLEdBQUcsTUFBS2IsS0FBTCxDQUFXVyxRQUFYLENBQW9CLENBQXBCLEVBQXVCRyxJQUF4Qzs7QUFDQSxZQUFLQyxRQUFMLENBQWMsTUFBS2YsS0FBTCxDQUFXVyxRQUFYLENBQW9CLENBQXBCLENBQWQsRUFBc0NLLElBQXRDLENBQTJDLFVBQUFDLElBQUksRUFBSTtBQUMvQyxjQUFLbkIsUUFBTCxDQUFjO0FBQ1ZjLHNCQUFZLEVBQUVLO0FBREosU0FBZDs7QUFHQSxjQUFLckIsS0FBTCxDQUFXc0IsZUFBWCxDQUEyQkQsSUFBM0IsRUFBaUNKLFFBQWpDO0FBQ0gsT0FMRDtBQU1ILEs7O3VGQUVVLFVBQUNNLElBQUQ7QUFBQSxhQUFVLElBQUlDLE9BQUosQ0FBWSxVQUFDQyxPQUFELEVBQWE7QUFDdEMsWUFBTUMsVUFBVSxHQUFHLElBQUlDLFVBQUosRUFBbkI7O0FBQ0FELGtCQUFVLENBQUNFLE1BQVgsR0FBb0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCSixpQkFBTyxDQUFDSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsQ0FBQyxDQUFDRyxNQUFGLENBQVNDLE1BQXBCLENBQUQsQ0FBUDtBQUNILFNBRkQ7O0FBR0FQLGtCQUFVLENBQUNRLFVBQVgsQ0FBc0JYLElBQXRCO0FBQ0gsT0FOZ0IsQ0FBVjtBQUFBLEs7Ozs7Ozs7NkJBU0Y7QUFBQTs7QUFFTCxVQUFNWSxRQUFRLEdBQUcsS0FBSy9CLEtBQUwsQ0FBV1csUUFBWCxDQUFvQnFCLE1BQXBCLEtBQStCLENBQWhEO0FBQ0EsVUFBTWYsSUFBSSxHQUFHLEtBQUtqQixLQUFMLENBQVdZLFlBQXhCO0FBQ0EsVUFBTXFCLFFBQVEsR0FBR2hCLElBQUksQ0FBQ2lCLElBQUwsR0FBV2pCLElBQUksQ0FBQ2lCLElBQWhCLEdBQXVCLEVBQXhDO0FBQ0EsVUFBTUMsZUFBZSxHQUFHbEIsSUFBSSxDQUFDaUIsSUFBTCxJQUFhLElBQXJDO0FBQ0EsVUFBTUUsT0FBTyxHQUFHbkIsSUFBSSxDQUFDaUIsSUFBTCxHQUFZLENBQUNqQixJQUFJLENBQUNvQixLQUFMLEdBQVlwQixJQUFJLENBQUNvQixLQUFMLENBQVdMLE1BQXZCLEdBQWdDLENBQWpDLEtBQXVDZixJQUFJLENBQUNxQixlQUFMLEdBQXNCckIsSUFBSSxDQUFDcUIsZUFBTCxDQUFxQk4sTUFBM0MsR0FBb0QsQ0FBM0YsQ0FBWixHQUE2RyxDQUE3SDtBQUVBLFVBQU1wQyxLQUFLLEdBQUc7QUFDVjJDLGNBQU0sRUFBQyxPQURHO0FBRVZDLGdCQUFRLEVBQUUsa0JBQUNyQixJQUFELEVBQVU7QUFDaEIsZ0JBQUksQ0FBQ3JCLFFBQUwsQ0FBYyxnQkFBa0I7QUFBQSxnQkFBZmEsUUFBZSxRQUFmQSxRQUFlO0FBQzlCLGdCQUFNOEIsS0FBSyxHQUFHOUIsUUFBUSxDQUFDK0IsT0FBVCxDQUFpQnZCLElBQWpCLENBQWQ7QUFDQSxnQkFBTXdCLFdBQVcsR0FBR2hDLFFBQVEsQ0FBQ2lDLEtBQVQsRUFBcEI7QUFDQUQsdUJBQVcsQ0FBQ0UsTUFBWixDQUFtQkosS0FBbkIsRUFBMEIsQ0FBMUI7QUFDQSxtQkFBTztBQUNMOUIsc0JBQVEsRUFBRWdDO0FBREwsYUFBUDtBQUdELFdBUEQ7O0FBUUEsZ0JBQUksQ0FBQzdDLFFBQUwsQ0FBYztBQUNWYyx3QkFBWSxFQUFFO0FBREosV0FBZDs7QUFHQSxnQkFBSSxDQUFDaEIsS0FBTCxDQUFXc0IsZUFBWCxDQUEyQixFQUEzQjtBQUNELFNBZk87QUFnQlY0QixvQkFBWSxFQUFFLHNCQUFDM0IsSUFBRCxFQUFVO0FBQ3BCLGdCQUFJLENBQUN2QixLQUFMLENBQVdzQixlQUFYLENBQTJCLEVBQTNCOztBQUNBLGdCQUFJLENBQUNwQixRQUFMLENBQWM7QUFDVmEsb0JBQVEsRUFBRSxDQUFDUSxJQUFEO0FBREEsV0FBZDs7QUFJQTRCLG9CQUFVLENBQUMsWUFBTTtBQUNiLGtCQUFJLENBQUNDLFlBQUw7QUFDSCxXQUZTLEVBRVAsR0FGTyxDQUFWO0FBSUEsaUJBQU8sS0FBUDtBQUNILFNBM0JTO0FBNEJWckMsZ0JBQVEsRUFBRSxLQUFLWCxLQUFMLENBQVdXO0FBNUJYLE9BQWQ7QUErQkEsYUFDSSx3RUFDSSwyREFBQyxPQUFELGVBQWFmLEtBQWI7QUFBb0IsYUFBSyxFQUFFO0FBQUNxRCxvQkFBVSxFQUFDO0FBQVo7QUFBM0IsVUFDSTtBQUFHLGlCQUFTLEVBQUM7QUFBYixTQUNBLDJEQUFDLHlDQUFEO0FBQU0sWUFBSSxFQUFDO0FBQVgsUUFEQSxDQURKLEVBSUk7QUFBRyxpQkFBUyxFQUFDO0FBQWIscURBSkosRUFLSTtBQUFHLGlCQUFTLEVBQUM7QUFBYixtREFMSixDQURKLEVBU0ksMkRBQUMscURBQUQ7QUFDSSxZQUFJLEVBQUVsQixRQURWO0FBRUksWUFBSSxFQUFFRSxRQUZWO0FBR0ksa0JBQVUsRUFBSUcsT0FIbEI7QUFJSSxlQUFPLEVBQUVEO0FBSmIsUUFUSixDQURKO0FBbUJIOzs7O0VBbkZvQjVCLDRDQUFLLENBQUNMLFM7O0FBdUZoQlEseUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlGQTtBQUVBO0lBRVF3QyxNLEdBQVdDLDJDLENBQVhELE07O0lBRUZFLFc7Ozs7Ozs7Ozs7Ozs7NkJBQ087QUFDTCxhQUNJLDJEQUFDLE1BQUQ7QUFBUSxhQUFLLEVBQUU7QUFBRUMsbUJBQVMsRUFBRTtBQUFiO0FBQWYsc0NBREo7QUFLSDs7OztFQVBxQjlDLDRDQUFLLENBQUNMLFM7O0FBV2pCa0QsMEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUNBO0lBQ1FFLE0sR0FBV0gsMkMsQ0FBWEcsTTs7SUFFRkMsVzs7Ozs7Ozs7Ozs7Ozs2QkFDTztBQUVMLGFBQ0ksMkRBQUMsTUFBRDtBQUFRLGlCQUFTLEVBQUM7QUFBbEIsU0FDSSx5RUFDSyxLQUFLM0QsS0FBTCxDQUFXNEQsS0FEaEIsQ0FESixDQURKO0FBT0g7Ozs7RUFWcUJqRCw0Q0FBSyxDQUFDTCxTOztBQWNqQnFELDBFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBRVFFLE8sR0FBWU4sMkMsQ0FBWk0sTzs7SUFFRkMsVTs7Ozs7QUFDRixzQkFBWTlELEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFDZixvRkFBTUEsS0FBTjs7QUFEZSw4RkFhRCxVQUFDcUIsSUFBRCxFQUFPSixRQUFQLEVBQW9CO0FBQ2xDOEMsaUVBQVUsQ0FBQ0MsV0FBWCxDQUF1QixTQUF2Qjs7QUFDQSxVQUFJM0MsSUFBSSxDQUFDaUIsSUFBVCxFQUFlO0FBQ1gsY0FBS3BDLFFBQUwsQ0FBYztBQUNWK0Qsc0JBQVksRUFBRTVDLElBREo7QUFFVjZDLHNCQUFZLEVBQUUsSUFGSjtBQUdWakQsa0JBQVEsRUFBUkE7QUFIVSxTQUFkO0FBS0gsT0FORCxNQU1PO0FBQ0gsY0FBS2YsUUFBTCxDQUFjO0FBQ1YrRCxzQkFBWSxFQUFFLEVBREo7QUFFVkMsc0JBQVksRUFBRSxLQUZKO0FBR1ZqRCxrQkFBUSxFQUFFO0FBSEEsU0FBZDtBQUtIO0FBRUosS0E3QmtCOztBQUFBLGdHQStCQyxVQUFDSSxJQUFELEVBQVU7QUFDMUIsVUFBSUEsSUFBSSxDQUFDaUIsSUFBVCxFQUFlO0FBQ1gsY0FBS3BDLFFBQUwsQ0FBYztBQUNWaUUscUJBQVcsRUFBRTlDO0FBREgsU0FBZDtBQUdIO0FBQ0osS0FyQ2tCOztBQUFBLGtHQXVDRyxZQUFNO0FBQ3hCK0MsYUFBTyxDQUFDQyxHQUFSLENBQVksYUFBWjtBQUNBLFVBQU1oRCxJQUFJLEdBQUdTLElBQUksQ0FBQ3dDLFNBQUwsQ0FBZSxNQUFLbEUsS0FBTCxDQUFXK0QsV0FBMUIsRUFBdUMsSUFBdkMsRUFBNkMsQ0FBN0MsQ0FBYjtBQUNBLFVBQU1JLElBQUksR0FBRyxJQUFJQyxJQUFKLENBQVMsQ0FBQ25ELElBQUQsQ0FBVCxFQUFpQjtBQUFFb0QsWUFBSSxFQUFFO0FBQVIsT0FBakIsQ0FBYjtBQUNBQyx1REFBTSxDQUFDSCxJQUFELEVBQU8sTUFBS25FLEtBQUwsQ0FBV2EsUUFBWCxDQUFvQjBELEtBQXBCLENBQTBCLEdBQTFCLEVBQStCLENBQS9CLElBQW9DLGVBQTNDLENBQU47QUFDSCxLQTVDa0I7O0FBRWYsVUFBS3ZFLEtBQUwsR0FBYTtBQUNUNkQsa0JBQVksRUFBRSxFQURMO0FBRVRFLGlCQUFXLEVBQUUsRUFGSjtBQUdURCxrQkFBWSxFQUFFLEtBSEw7QUFJVGpELGNBQVEsRUFBRTtBQUpELEtBQWI7QUFNQSxVQUFLSyxlQUFMLEdBQXVCLE1BQUtBLGVBQUwsQ0FBcUJzRCxJQUFyQix1REFBdkI7QUFDQSxVQUFLQyxpQkFBTCxHQUF5QixNQUFLQSxpQkFBTCxDQUF1QkQsSUFBdkIsdURBQXpCO0FBQ0EsVUFBS0UsbUJBQUwsR0FBMkIsTUFBS0EsbUJBQUwsQ0FBeUJGLElBQXpCLHVEQUEzQjtBQVZlO0FBV2xCOzs7OzZCQW1DUTtBQUNMLFVBQU1HLGtCQUFrQixHQUFHLENBQUMsS0FBSzNFLEtBQUwsQ0FBVytELFdBQVgsQ0FBdUI3QixJQUF4QixHQUErQixJQUEvQixHQUFzQyxLQUFqRTtBQUNBLFVBQU0wQyxXQUFXLEdBQUcsS0FBSzVFLEtBQUwsQ0FBVzhELFlBQVgsR0FFWiwyREFBQyxpREFBRDtBQUFVLFlBQUksRUFBRSxLQUFLOUQsS0FBTCxDQUFXNkQsWUFBM0I7QUFBeUMseUJBQWlCLEVBQUUsS0FBS1k7QUFBakUsUUFGWSxHQUtaLDJEQUFDLDBEQUFELE9BTFI7QUFRQSxhQUNJLDJEQUFDLDJDQUFELFFBQ0ksMkRBQUMsb0RBQUQ7QUFBYSxhQUFLLEVBQUM7QUFBbkIsUUFESixFQUVJLDJEQUFDLE9BQUQ7QUFBUyxhQUFLLEVBQUU7QUFBRUksZ0JBQU0sRUFBRTtBQUFWO0FBQWhCLFNBQ0k7QUFBSyxhQUFLLEVBQUU7QUFBRUMsaUJBQU8sRUFBRTtBQUFYO0FBQVosU0FDSSwyREFBQyx3Q0FBRDtBQUFLLGNBQU0sRUFBRTtBQUFiLFNBQ0ksMkRBQUMsd0NBQUQ7QUFBSyxVQUFFLEVBQUUsQ0FBVDtBQUFZLFlBQUksRUFBRTtBQUFsQixTQUNJO0FBQUssYUFBSyxFQUFFO0FBQUVDLHFCQUFXLEVBQUU7QUFBZjtBQUFaLFNBQ0ksMkRBQUMsbURBQUQ7QUFBWSx1QkFBZSxFQUFFLEtBQUs3RDtBQUFsQyxRQURKLENBREosRUFJSTtBQUFLLGFBQUssRUFBRTtBQUFFMkQsZ0JBQU0sRUFBRTtBQUFWO0FBQVosU0FDSSwyREFBQywyQ0FBRDtBQUFRLFlBQUksRUFBQyxTQUFiO0FBQXVCLFlBQUksRUFBQyxVQUE1QjtBQUF1QyxZQUFJLEVBQUMsT0FBNUM7QUFBb0QsZUFBTyxFQUFFLEtBQUtILG1CQUFsRTtBQUF1RixhQUFLLE1BQTVGO0FBQTZGLGdCQUFRLEVBQUVDO0FBQXZHLG9CQURKLENBSkosQ0FESixFQVVJLDJEQUFDLHdDQUFEO0FBQUssVUFBRSxFQUFFLEVBQVQ7QUFBYSxZQUFJLEVBQUU7QUFBbkIsU0FDSTtBQUFLLGFBQUssRUFBRTtBQUFFSyxvQkFBVSxFQUFFLE1BQWQ7QUFBc0JDLG1CQUFTLEVBQUUsTUFBakM7QUFBeUNoQyxvQkFBVSxFQUFFO0FBQXJEO0FBQVosU0FDSzJCLFdBREwsQ0FESixDQVZKLENBREosQ0FESixDQUZKLENBREo7QUEyQkg7Ozs7RUFwRm9CckUsNENBQUssQ0FBQ0wsUzs7QUF1RmhCd0QseUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BHQTtBQUNBOztJQUdNd0IsWTs7Ozs7Ozs7Ozs7Ozs2QkFDTztBQUNMLFVBQU1DLEtBQUssR0FBRyxLQUFLdkYsS0FBTCxDQUFXd0YsT0FBWCxHQUFxQjtBQUFFQyxpQkFBUyxFQUFFLE1BQWI7QUFBcUJDLGVBQU8sRUFBRTtBQUE5QixPQUFyQixHQUErRDtBQUFFQSxlQUFPLEVBQUU7QUFBWCxPQUE3RTtBQUNBLFVBQU1yRCxRQUFRLEdBQUcsS0FBS3JDLEtBQUwsQ0FBV3NDLElBQTVCO0FBQ0EsYUFDSSwyREFBQyx5Q0FBRDtBQUNJLGFBQUssRUFBRUQsUUFBUSxDQUFDc0QsV0FBVCxJQUF3QnRELFFBQVEsQ0FBQ3NELFdBQVQsS0FBeUIsRUFBakQsR0FBc0R0RCxRQUFRLENBQUNzRCxXQUEvRCxHQUE2RSxnQkFEeEY7QUFFSSxhQUFLLEVBQUVKLEtBRlg7QUFHSSxpQkFBUyxFQUFFO0FBSGYsU0FLSSw0RkFBc0JsRCxRQUFRLENBQUN1RCxlQUFULEtBQTZCLEVBQTdCLEdBQWtDdkQsUUFBUSxDQUFDdUQsZUFBM0MsR0FBNkQsb0JBQW5GLENBTEosRUFNSSxzRkFBZ0J2RCxRQUFRLENBQUN3RCxVQUFULEtBQXdCLEVBQXhCLEdBQTZCeEQsUUFBUSxDQUFDd0QsVUFBdEMsR0FBbUQsbUJBQW5FLENBTkosRUFPSSwyRkFBcUIsS0FBSzdGLEtBQUwsQ0FBVzhGLFVBQWhDLE1BUEosRUFRSSw0RkFBc0J6RCxRQUFRLENBQUMwRCxlQUFULEdBQTBCMUQsUUFBUSxDQUFDMEQsZUFBbkMsR0FBcUQsc0JBQTNFLENBUkosQ0FESjtBQVlIOzs7O0VBaEJzQnBGLDRDQUFLLENBQUNMLFM7O0FBb0JsQmdGLDJFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QkE7QUFDQTtBQUVBLElBQU1VLFFBQVEsR0FBR0MseUNBQUksQ0FBQ0MsSUFBdEI7QUFDQSxJQUFNQyxlQUFlLEdBQUd4Riw0Q0FBSyxDQUFDeUYsYUFBTixFQUF4Qjs7QUFFQSxJQUFNQyxXQUFXLEdBQUcsU0FBZEEsV0FBYztBQUFBLE1BQUdDLElBQUgsUUFBR0EsSUFBSDtBQUFBLE1BQVN6RCxLQUFULFFBQVNBLEtBQVQ7QUFBQSxNQUFtQjdDLEtBQW5COztBQUFBLFNBQ2hCLDJEQUFDLGVBQUQsQ0FBaUIsUUFBakI7QUFBMEIsU0FBSyxFQUFFc0c7QUFBakMsS0FDSSxpRUFBUXRHLEtBQVIsQ0FESixDQURnQjtBQUFBLENBQXBCOztBQU1BLElBQU11RyxlQUFlLEdBQUdOLHlDQUFJLENBQUNPLE1BQUwsR0FBY0gsV0FBZCxDQUF4Qjs7SUFFTUksWTs7Ozs7Ozs7Ozs7Ozs7Ozs7O29GQUNNO0FBQ0pDLGFBQU8sRUFBRTtBQURMLEs7O3lGQWdCSyxZQUFNO0FBQ2YsVUFBTUEsT0FBTyxHQUFHLENBQUMsTUFBS3RHLEtBQUwsQ0FBV3NHLE9BQTVCOztBQUNBLFlBQUt4RyxRQUFMLENBQWM7QUFBRXdHLGVBQU8sRUFBUEE7QUFBRixPQUFkLEVBQTJCLFlBQU07QUFDN0IsWUFBSUEsT0FBSixFQUFhO0FBQ1QsZ0JBQUtDLEtBQUwsQ0FBV0MsS0FBWDtBQUNIO0FBQ0osT0FKRDtBQUtILEs7O2lHQUVvQixVQUFDL0UsQ0FBRCxFQUFPO0FBQUEsVUFDaEI2RSxPQURnQixHQUNKLE1BQUt0RyxLQURELENBQ2hCc0csT0FEZ0I7O0FBRXhCLFVBQUlBLE9BQU8sSUFBSSxNQUFLRyxJQUFMLEtBQWNoRixDQUFDLENBQUNHLE1BQTNCLElBQXFDLENBQUMsTUFBSzZFLElBQUwsQ0FBVUMsUUFBVixDQUFtQmpGLENBQUMsQ0FBQ0csTUFBckIsQ0FBMUMsRUFBd0U7QUFDcEUsY0FBSytFLElBQUw7QUFDSDtBQUNKLEs7O21GQUVNLFlBQU07QUFBQSx3QkFDc0IsTUFBSy9HLEtBRDNCO0FBQUEsVUFDRGdILE1BREMsZUFDREEsTUFEQztBQUFBLFVBQ09DLFVBRFAsZUFDT0EsVUFEUDs7QUFFVCxZQUFLWCxJQUFMLENBQVVZLGNBQVYsQ0FBeUIsVUFBQ0MsS0FBRCxFQUFRQyxNQUFSLEVBQW1CO0FBQ3hDLFlBQUlELEtBQUosRUFBVztBQUNQO0FBQ0g7O0FBQ0QsY0FBS0UsVUFBTDs7QUFDQUosa0JBQVUsbUJBQU1ELE1BQU4sRUFBaUJJLE1BQWpCLEVBQVY7QUFDSCxPQU5EO0FBT0gsSzs7Ozs7Ozt3Q0FyQ21CO0FBQ2hCLFVBQUksS0FBS3BILEtBQUwsQ0FBV3NILFFBQWYsRUFBeUI7QUFDckJDLGdCQUFRLENBQUNDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLEtBQUtDLGtCQUF4QyxFQUE0RCxJQUE1RDtBQUNIO0FBQ0o7OzsyQ0FFc0I7QUFDbkIsVUFBSSxLQUFLekgsS0FBTCxDQUFXc0gsUUFBZixFQUF5QjtBQUNyQkMsZ0JBQVEsQ0FBQ0csbUJBQVQsQ0FBNkIsT0FBN0IsRUFBc0MsS0FBS0Qsa0JBQTNDLEVBQStELElBQS9EO0FBQ0g7QUFDSjs7OzZCQTZCUTtBQUFBOztBQUFBLFVBQ0dmLE9BREgsR0FDZSxLQUFLdEcsS0FEcEIsQ0FDR3NHLE9BREg7O0FBQUEseUJBVUQsS0FBSzFHLEtBVko7QUFBQSxVQUdEc0gsUUFIQyxnQkFHREEsUUFIQztBQUFBLFVBSURLLFNBSkMsZ0JBSURBLFNBSkM7QUFBQSxVQUtEL0QsS0FMQyxnQkFLREEsS0FMQztBQUFBLFVBTURvRCxNQU5DLGdCQU1EQSxNQU5DO0FBQUEsVUFPRG5FLEtBUEMsZ0JBT0RBLEtBUEM7QUFBQSxVQVFEb0UsVUFSQyxnQkFRREEsVUFSQztBQUFBLFVBU0VXLFNBVEY7O0FBV0wsYUFDSTtBQUFJLFdBQUcsRUFBRSxhQUFBQyxJQUFJO0FBQUEsaUJBQUssTUFBSSxDQUFDaEIsSUFBTCxHQUFZZ0IsSUFBakI7QUFBQTtBQUFiLFNBQXlDRCxTQUF6QyxHQUNLTixRQUFRLEdBQ0wsMkRBQUMsZUFBRCxDQUFpQixRQUFqQixRQUNLLFVBQUNoQixJQUFELEVBQVU7QUFDUCxjQUFJLENBQUNBLElBQUwsR0FBWUEsSUFBWjtBQUNBLGVBQ0lJLE9BQU8sR0FDSCwyREFBQyxRQUFEO0FBQVUsZUFBSyxFQUFFO0FBQUV6QixrQkFBTSxFQUFFO0FBQVY7QUFBakIsV0FDS3FCLElBQUksQ0FBQ3dCLGlCQUFMLENBQXVCSCxTQUF2QixFQUFrQztBQUMvQkksZUFBSyxFQUFFLENBQUM7QUFDSkMsb0JBQVEsRUFBRSxJQUROO0FBRUpDLG1CQUFPLFlBQUtyRSxLQUFMO0FBRkgsV0FBRCxDQUR3QjtBQUsvQnNFLHNCQUFZLEVBQUVsQixNQUFNLENBQUNXLFNBQUQ7QUFMVyxTQUFsQyxFQU9HLDJEQUFDLDBDQUFEO0FBQ0ksYUFBRyxFQUFFLGFBQUFFLElBQUk7QUFBQSxtQkFBSyxNQUFJLENBQUNsQixLQUFMLEdBQWFrQixJQUFsQjtBQUFBLFdBRGI7QUFFSSxzQkFBWSxFQUFFLE1BQUksQ0FBQ2Q7QUFGdkIsVUFQSCxDQURMLENBREcsR0FnQkM7QUFDSSxtQkFBUyxFQUFDLDBCQURkO0FBRUksZUFBSyxFQUFFO0FBQUVvQix3QkFBWSxFQUFFO0FBQWhCLFdBRlg7QUFHSSxpQkFBTyxFQUFFLE1BQUksQ0FBQ2Q7QUFIbEIsV0FLS08sU0FBUyxDQUFDUSxRQUxmLENBakJaO0FBMEJILE9BN0JMLENBREssR0FnQ0xSLFNBQVMsQ0FBQ1EsUUFqQ2xCLENBREo7QUFxQ0g7Ozs7RUE1RnNCekgsNENBQUssQ0FBQ0wsUzs7SUErRjNCK0gsd0I7Ozs7O0FBQ0Ysb0NBQVlySSxLQUFaLEVBQW1CO0FBQUE7O0FBQUE7O0FBQ2YsbUdBQU1BLEtBQU47O0FBRGUseUZBa0RQLFVBQUNzSSxPQUFELEVBQWE7QUFDckJBLGFBQU8sQ0FBQ0MsT0FBUixDQUFnQixVQUFDQyxLQUFELEVBQVFDLEVBQVIsRUFBZTtBQUMzQkQsYUFBSyxDQUFDdkksR0FBTixHQUFZd0ksRUFBWjtBQUNILE9BRkQ7QUFHQSxhQUFPSCxPQUFQO0FBQ0gsS0F2RGtCOztBQUFBLDRGQXlESixVQUFDckksR0FBRCxFQUFTO0FBQ3BCLFVBQU15SSxVQUFVLHNCQUFPLE9BQUt0SSxLQUFMLENBQVdzSSxVQUFsQixDQUFoQjs7QUFDQSxhQUFLeEksUUFBTCxDQUFjO0FBQUV3SSxrQkFBVSxFQUFFQSxVQUFVLENBQUNDLE1BQVgsQ0FBa0IsVUFBQUMsSUFBSTtBQUFBLGlCQUFJQSxJQUFJLENBQUMzSSxHQUFMLEtBQWFBLEdBQWpCO0FBQUEsU0FBdEI7QUFBZCxPQUFkO0FBQ0gsS0E1RGtCOztBQUFBLHlGQThEUCxZQUFNO0FBQUEsVUFDTnlJLFVBRE0sR0FDUyxPQUFLdEksS0FEZCxDQUNOc0ksVUFETTtBQUVkLFVBQU1HLE9BQU8sR0FBRztBQUNaM0gsWUFBSSxFQUFFLFNBRE07QUFFWnVILFVBQUUsRUFBRSxTQUZRO0FBR1poRSxZQUFJLEVBQUUsTUFITTtBQUlacUUsZUFBTyxFQUFFLFNBSkc7QUFLWkMsZUFBTyxFQUFFLE9BTEc7QUFNWkMsa0JBQVUsRUFBRTtBQU5BLE9BQWhCOztBQVFBLGFBQUs5SSxRQUFMLENBQWM7QUFDVndJLGtCQUFVLEdBQUdHLE9BQUgsNEJBQWNILFVBQWQ7QUFEQSxPQUFkO0FBR0gsS0EzRWtCOztBQUFBLDBGQTZFTixVQUFDTyxHQUFELEVBQVM7QUFDbEIsVUFBTUosT0FBTyxzQkFBTyxPQUFLekksS0FBTCxDQUFXc0ksVUFBbEIsQ0FBYjs7QUFDQSxVQUFNN0YsS0FBSyxHQUFHZ0csT0FBTyxDQUFDSyxTQUFSLENBQWtCLFVBQUFOLElBQUk7QUFBQSxlQUFJSyxHQUFHLENBQUNoSixHQUFKLEtBQVkySSxJQUFJLENBQUMzSSxHQUFyQjtBQUFBLE9BQXRCLENBQWQ7QUFDQSxVQUFNMkksSUFBSSxHQUFHQyxPQUFPLENBQUNoRyxLQUFELENBQXBCO0FBQ0FnRyxhQUFPLENBQUM1RixNQUFSLENBQWVKLEtBQWYsRUFBc0IsQ0FBdEIsb0JBQ08rRixJQURQLEVBRU9LLEdBRlA7O0FBSUEsYUFBSy9JLFFBQUwsQ0FBYztBQUFFd0ksa0JBQVUsRUFBRUc7QUFBZCxPQUFkOztBQUNBLGFBQUs3SSxLQUFMLENBQVc2RSxpQkFBWCxDQUE2QixPQUFLekUsS0FBbEM7QUFDSCxLQXZGa0I7O0FBRWYsV0FBSytJLE9BQUwsR0FBZSxDQUFDO0FBQ1p2RixXQUFLLEVBQUUsV0FESztBQUVaK0QsZUFBUyxFQUFFLE1BRkM7QUFHWnlCLGFBQU8sRUFBRSxDQUFDO0FBQ05DLFlBQUksRUFBRSxVQURBO0FBRU5DLGFBQUssRUFBRTtBQUZELE9BQUQsRUFHTjtBQUNDRCxZQUFJLEVBQUUsU0FEUDtBQUVDQyxhQUFLLEVBQUU7QUFGUixPQUhNLEVBTU47QUFDQ0QsWUFBSSxFQUFFLE9BRFA7QUFFQ0MsYUFBSyxFQUFFO0FBRlIsT0FOTSxDQUhHO0FBYVpDLGNBQVEsRUFBRSxrQkFBQ0QsS0FBRCxFQUFRdEMsTUFBUjtBQUFBLGVBQW1CQSxNQUFNLENBQUM5RixJQUFQLENBQVlzSSxXQUFaLEdBQTBCMUcsT0FBMUIsQ0FBa0N3RyxLQUFsQyxNQUE2QyxDQUFoRTtBQUFBLE9BYkU7QUFjWkcsWUFBTSxFQUFFLGdCQUFDQyxDQUFELEVBQUlDLENBQUo7QUFBQSxlQUFVRCxDQUFDLENBQUN4SSxJQUFGLENBQU9rQixNQUFQLEdBQWdCdUgsQ0FBQyxDQUFDekksSUFBRixDQUFPa0IsTUFBakM7QUFBQSxPQWRJO0FBZVprRixjQUFRLEVBQUU7QUFmRSxLQUFELEVBZ0JaO0FBQ0MxRCxXQUFLLEVBQUUsVUFEUjtBQUVDK0QsZUFBUyxFQUFFLElBRlo7QUFHQzhCLFlBQU0sRUFBRSxnQkFBQ0MsQ0FBRCxFQUFJQyxDQUFKO0FBQUEsZUFBVUQsQ0FBQyxDQUFDakIsRUFBRixDQUFLckcsTUFBTCxHQUFjdUgsQ0FBQyxDQUFDbEIsRUFBRixDQUFLckcsTUFBN0I7QUFBQSxPQUhUO0FBSUNrRixjQUFRLEVBQUU7QUFKWCxLQWhCWSxFQXFCWjtBQUNDMUQsV0FBSyxFQUFFLE9BRFI7QUFFQytELGVBQVMsRUFBRSxTQUZaO0FBR0NMLGNBQVEsRUFBRTtBQUhYLEtBckJZLEVBeUJaO0FBQ0MxRCxXQUFLLEVBQUUsUUFEUjtBQUVDK0QsZUFBUyxFQUFFLFdBRlo7QUFHQ2lDLFlBQU0sRUFBRSxnQkFBQ1AsSUFBRCxFQUFPckMsTUFBUCxFQUFrQjtBQUN0QixlQUNJLE9BQUs1RyxLQUFMLENBQVdzSSxVQUFYLENBQXNCdEcsTUFBdEIsSUFBZ0MsQ0FBaEMsR0FFUSwyREFBQywrQ0FBRDtBQUFZLGVBQUssRUFBQyxpQkFBbEI7QUFBb0MsbUJBQVMsRUFBRTtBQUFBLG1CQUFNLE9BQUt5SCxZQUFMLENBQWtCN0MsTUFBTSxDQUFDL0csR0FBekIsQ0FBTjtBQUFBO0FBQS9DLFdBQ0ksK0VBREosQ0FGUixHQUtRLElBTlo7QUFRQyxPQVpOO0FBYUM2SixXQUFLLEVBQUU7QUFiUixLQXpCWSxDQUFmO0FBeUNBLFdBQUsxSixLQUFMLEdBQWE7QUFDVDJKLFVBQUksRUFBRSxPQUFLL0osS0FBTCxDQUFXK0osSUFEUjtBQUVUckIsZ0JBQVUsRUFBRSxPQUFLc0IsU0FBTCxDQUFlLE9BQUtoSyxLQUFMLENBQVcwSSxVQUExQixDQUZIO0FBR1R1QixlQUFTLEVBQUUsT0FBS2pLLEtBQUwsQ0FBV2lLO0FBSGIsS0FBYjtBQTNDZTtBQWdEbEI7Ozs7NkJBeUNRO0FBQUE7O0FBQUEsVUFDR3ZCLFVBREgsR0FDa0IsS0FBS3RJLEtBRHZCLENBQ0dzSSxVQURIO0FBRUwsVUFBTXdCLFVBQVUsR0FBRztBQUNmQyxZQUFJLEVBQUU7QUFDRmxCLGFBQUcsRUFBRTFDLGVBREg7QUFFRk0sY0FBSSxFQUFFSjtBQUZKO0FBRFMsT0FBbkI7QUFNQSxVQUFNMEMsT0FBTyxHQUFHLEtBQUtBLE9BQUwsQ0FBYWlCLEdBQWIsQ0FBaUIsVUFBQ0MsR0FBRCxFQUFTO0FBQ3RDLFlBQUksQ0FBQ0EsR0FBRyxDQUFDL0MsUUFBVCxFQUFtQjtBQUNmLGlCQUFPK0MsR0FBUDtBQUNIOztBQUNELGlDQUNPQSxHQURQO0FBRUlDLGdCQUFNLEVBQUUsZ0JBQUF0RCxNQUFNO0FBQUEsbUJBQUs7QUFDZkEsb0JBQU0sRUFBTkEsTUFEZTtBQUVmTSxzQkFBUSxFQUFFK0MsR0FBRyxDQUFDL0MsUUFGQztBQUdmSyx1QkFBUyxFQUFFMEMsR0FBRyxDQUFDMUMsU0FIQTtBQUlmL0QsbUJBQUssRUFBRXlHLEdBQUcsQ0FBQ3pHLEtBSkk7QUFLZnFELHdCQUFVLEVBQUUsTUFBSSxDQUFDQTtBQUxGLGFBQUw7QUFBQTtBQUZsQjtBQVVILE9BZGUsQ0FBaEI7QUFlQSxhQUNJLHdFQUNJLDJEQUFDLDJDQUFEO0FBQVEsZUFBTyxFQUFFLEtBQUtzRCxTQUF0QjtBQUFpQyxZQUFJLEVBQUMsU0FBdEM7QUFBZ0QsYUFBSyxFQUFFO0FBQUVDLHNCQUFZLEVBQUU7QUFBaEI7QUFBdkQsMkJBREosRUFJSSwyREFBQywwQ0FBRDtBQUNJLGtCQUFVLEVBQUVOLFVBRGhCO0FBRUksb0JBQVksRUFBRTtBQUFBLGlCQUFNLGNBQU47QUFBQSxTQUZsQjtBQUdJLGdCQUFRLE1BSFo7QUFJSSxrQkFBVSxFQUFFeEIsVUFKaEI7QUFLSSxlQUFPLEVBQUVTLE9BTGI7QUFNSSxjQUFNLEVBQUM7QUFOWCxRQUpKLENBREo7QUFlSDs7OztFQWhJa0N4SSw0Q0FBSyxDQUFDTCxTOztBQW1JOUIrSCx1RkFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaFBBO0FBRUE7QUFDQTs7SUFFTW9DLFU7Ozs7Ozs7Ozs7Ozs7Ozs7OztzRkFFUSxZQUFNO0FBQ1osVUFBSSxNQUFLekssS0FBTCxDQUFXRyxJQUFYLEtBQW9CLFFBQXhCLEVBQWtDO0FBQzlCLGVBQU8sMkRBQUMsbURBQUQsT0FBUDtBQUNILE9BRkQsTUFFTyxJQUFJLE1BQUtILEtBQUwsQ0FBV0csSUFBWCxLQUFvQixPQUF4QixFQUFpQztBQUNwQyxlQUFPLDJEQUFDLHNEQUFELE9BQVA7QUFDSCxPQUZNLE1BRUE7QUFDSCxlQUFPLDJEQUFDLG1EQUFELE9BQVA7QUFDSDtBQUNKLEs7Ozs7Ozs7NkJBRVE7QUFDTCxhQUFPLEtBQUt1SyxPQUFMLEVBQVA7QUFDSDs7OztFQWRvQi9KLDRDQUFLLENBQUNMLFM7O0FBaUJoQm1LLHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QkE7QUFFQTtBQUNBO0FBRUEsSUFBTUUsT0FBTyxHQUFHQyx5Q0FBSSxDQUFDRCxPQUFyQjs7SUFFTUUsUTs7Ozs7QUFDRixvQkFBWTdLLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFDZixrRkFBTUEsS0FBTjs7QUFEZSw0RkFRSCxVQUFDRyxJQUFELEVBQU8wQyxLQUFQLEVBQWNrSCxJQUFkLEVBQXVCO0FBQ25DLGFBQ0ksMkRBQUMsT0FBRDtBQUFTLFdBQUcsRUFBRTVKLElBQUksQ0FBQzJLLE9BQW5CO0FBQTRCLFdBQUcsRUFBRWpJO0FBQWpDLFNBQ0ksMkRBQUMsaUVBQUQ7QUFDSSxrQkFBVSxFQUFFMUMsSUFBSSxDQUFDbUksT0FEckI7QUFFSSxZQUFJLEVBQUV5QixJQUZWO0FBR0ksaUJBQVMsRUFBRWxILEtBSGY7QUFJSSx5QkFBaUIsRUFBSSxNQUFLZ0M7QUFKOUIsUUFESixDQURKO0FBV0gsS0FwQmtCOztBQUFBLGdHQXNCQyxVQUFDa0csUUFBRCxFQUFjO0FBQzlCLFlBQUs3SyxRQUFMLENBQWMsWUFBTTtBQUNoQixZQUFNMkMsS0FBSyxHQUFHa0ksUUFBUSxDQUFDZCxTQUF2QjtBQUNBLFlBQUllLFFBQVEsR0FBRyxNQUFLNUssS0FBTCxDQUFXWSxZQUExQjs7QUFDQSxZQUFHK0osUUFBUSxDQUFDaEIsSUFBVCxLQUFrQixXQUFyQixFQUFpQztBQUM3QmlCLGtCQUFRLENBQUN2SSxLQUFULENBQWVJLEtBQWYsRUFBc0J5RixPQUF0QixHQUFnQ3lDLFFBQVEsQ0FBQ3JDLFVBQXpDO0FBQ0gsU0FGRCxNQUVPO0FBQ0hzQyxrQkFBUSxDQUFDdEksZUFBVCxDQUF5QkcsS0FBekIsRUFBZ0N5RixPQUFoQyxHQUEwQ3lDLFFBQVEsQ0FBQ3JDLFVBQW5EO0FBQ0g7O0FBRUQsY0FBSzFJLEtBQUwsQ0FBVzZFLGlCQUFYLENBQTZCbUcsUUFBN0I7O0FBRUEsZUFBTztBQUNIaEssc0JBQVksRUFBRWdLO0FBRFgsU0FBUDtBQUdELE9BZEg7QUFlSCxLQXRDa0I7O0FBRWYsVUFBSzVLLEtBQUwsR0FBYTtBQUNUWSxrQkFBWSxFQUFFLE1BQUtoQixLQUFMLENBQVdxQjtBQURoQixLQUFiO0FBR0EsVUFBS3dELGlCQUFMLEdBQXlCLE1BQUtBLGlCQUFMLENBQXVCRCxJQUF2Qix1REFBekI7QUFMZTtBQU1sQjs7Ozs2QkFrQ1E7QUFBQTs7QUFFTCxVQUFNcUcsdUJBQXVCLEdBQUcsS0FBSzdLLEtBQUwsQ0FBV1ksWUFBWCxDQUF3QnlCLEtBQXhCLENBQThCMkgsR0FBOUIsQ0FBa0MsVUFBQ2pLLElBQUQsRUFBT3NJLEVBQVA7QUFBQSxlQUFjLE1BQUksQ0FBQ3lDLGFBQUwsQ0FBbUIvSyxJQUFuQixFQUF5QnNJLEVBQXpCLEVBQTZCLFdBQTdCLENBQWQ7QUFBQSxPQUFsQyxDQUFoQztBQUNBLFVBQU0wQyx1QkFBdUIsR0FBRyxLQUFLL0ssS0FBTCxDQUFXWSxZQUFYLENBQXdCMEIsZUFBeEIsQ0FBd0MwSCxHQUF4QyxDQUE0QyxVQUFDakssSUFBRCxFQUFPc0ksRUFBUDtBQUFBLGVBQWMsTUFBSSxDQUFDeUMsYUFBTCxDQUFtQi9LLElBQW5CLEVBQXlCc0ksRUFBekIsRUFBNkIsV0FBN0IsQ0FBZDtBQUFBLE9BQTVDLENBQWhDO0FBRUEsYUFDSSwyREFBQyx5Q0FBRDtBQUFNLHdCQUFnQixFQUFDO0FBQXZCLFNBQ0ksMkRBQUMsT0FBRDtBQUFTLFdBQUcsRUFBRSx5RUFBTSwyREFBQyx5Q0FBRDtBQUFNLGNBQUksRUFBQztBQUFYLFVBQU4sbUJBQWQ7QUFBZ0UsV0FBRyxFQUFDO0FBQXBFLFNBQ0ksMkRBQUMseUNBQUQ7QUFBTSx3QkFBZ0IsRUFBQyxHQUF2QjtBQUEyQixtQkFBVyxFQUFDO0FBQXZDLFNBQ0t3Qyx1QkFETCxDQURKLENBREosRUFNSSwyREFBQyxPQUFEO0FBQVUsV0FBRyxFQUFFLHlFQUFNLDJEQUFDLHlDQUFEO0FBQU0sY0FBSSxFQUFDO0FBQVgsVUFBTixtQkFBZjtBQUFnRSxXQUFHLEVBQUM7QUFBcEUsU0FDSSwyREFBQyx5Q0FBRDtBQUFNLHdCQUFnQixFQUFDLEdBQXZCO0FBQTJCLG1CQUFXLEVBQUM7QUFBdkMsU0FDS0UsdUJBREwsQ0FESixDQU5KLENBREo7QUFjSDs7OztFQTVEa0J4Syw0Q0FBSyxDQUFDTCxTOztBQStEZHVLLHVFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkVBO0FBQ0E7QUFDQTtJQUVRaEgsTyxHQUFZTiwyQyxDQUFaTSxPOztJQUVGdUgsYTs7Ozs7Ozs7Ozs7Ozs2QkFDTztBQUNMLGFBQ0ksMkRBQUMsMkNBQUQsUUFDSSwyREFBQyxvREFBRDtBQUFhLGFBQUssRUFBQztBQUFuQixhQURKLEVBRUksMkRBQUMsT0FBRDtBQUFTLGFBQUssRUFBRTtBQUFFbkcsZ0JBQU0sRUFBRTtBQUFWO0FBQWhCLFNBQ0k7QUFBSyxhQUFLLEVBQUU7QUFBRUMsaUJBQU8sRUFBRSxFQUFYO0FBQWVHLG1CQUFTLEVBQUU7QUFBMUI7QUFBWixTQUNJLDJEQUFDLHdDQUFEO0FBQUssY0FBTSxFQUFFO0FBQWIsU0FDSSwyREFBQyx3Q0FBRDtBQUFLLFVBQUUsRUFBRSxFQUFUO0FBQWEsWUFBSSxFQUFFO0FBQW5CLFNBQ0k7QUFBSyxhQUFLLEVBQUU7QUFBRUYscUJBQVcsRUFBRSxNQUFmO0FBQXVCRSxtQkFBUyxFQUFFO0FBQWxDO0FBQVosdUJBREosQ0FESixFQU1JLDJEQUFDLHdDQUFEO0FBQUssVUFBRSxFQUFFLEVBQVQ7QUFBYSxZQUFJLEVBQUU7QUFBbkIsU0FDSTtBQUFLLGFBQUssRUFBRTtBQUFFRCxvQkFBVSxFQUFFLE1BQWQ7QUFBc0JDLG1CQUFTLEVBQUU7QUFBakM7QUFBWixRQURKLENBTkosQ0FESixDQURKLENBRkosQ0FESjtBQXNCSDs7OztFQXhCdUIxRSw0Q0FBSyxDQUFDTCxTOztBQTJCbkI4Syw0RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQ0E7QUFFQTtJQUNRQyxLLEdBQVU5SCwyQyxDQUFWOEgsSzs7SUFFRkMsVTs7Ozs7Ozs7Ozs7Ozs7Ozs7O29GQUNNO0FBQ0pDLGVBQVMsRUFBRTtBQURQLEs7O3lGQUlLLFVBQUNBLFNBQUQsRUFBZTtBQUN4QixZQUFLckwsUUFBTCxDQUFjO0FBQUVxTCxpQkFBUyxFQUFUQTtBQUFGLE9BQWQ7QUFDSCxLOzs7Ozs7OzZCQUVRO0FBRUwsVUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBQ3hMLEtBQUQsRUFBVztBQUN2QixlQUNJO0FBQUssZUFBSyxFQUFFO0FBQUN5TCxrQkFBTSxFQUFFLE1BQVQ7QUFBaUJyRyxzQkFBVSxFQUFFcEYsS0FBSyxDQUFDdUwsU0FBTixHQUFpQixHQUFqQixHQUF1QjtBQUFwRDtBQUFaLFdBQ0k7QUFBSyxhQUFHLEVBQUMsdUJBQVQ7QUFBaUMsbUJBQVMsRUFBQyxVQUEzQztBQUFzRCxhQUFHLEVBQUM7QUFBMUQsVUFESixDQURKO0FBS0gsT0FORDs7QUFRQSxhQUNJLDJEQUFDLEtBQUQ7QUFDQSxtQkFBVyxNQURYO0FBRUEsaUJBQVMsRUFBRSxLQUFLbkwsS0FBTCxDQUFXbUwsU0FGdEI7QUFHQSxrQkFBVSxFQUFFLEtBQUtHLFVBSGpCO0FBSUEsYUFBSyxFQUFFO0FBQUVySSxvQkFBVSxFQUFFO0FBQWQ7QUFKUCxTQU1JLDJEQUFDLE9BQUQ7QUFBUyxpQkFBUyxFQUFFLEtBQUtqRCxLQUFMLENBQVdtTDtBQUEvQixRQU5KLEVBT0ksMkRBQUMseUNBQUQ7QUFDQSxhQUFLLEVBQUMsTUFETjtBQUVBLDJCQUFtQixFQUFFLENBQUMsUUFBRCxDQUZyQjtBQUdBLFlBQUksRUFBQyxRQUhMO0FBSUEsYUFBSyxFQUFFO0FBQUVsSSxvQkFBVSxFQUFFO0FBQWQsU0FKUDtBQUtBLGVBQU8sRUFBRSxLQUFLckQsS0FBTCxDQUFXSztBQUxwQixTQU9JLDJEQUFDLHlDQUFELENBQU0sSUFBTjtBQUFXLFdBQUcsRUFBQztBQUFmLFNBQ0ksMkRBQUMseUNBQUQ7QUFBTSxZQUFJLEVBQUM7QUFBWCxRQURKLEVBRUksdUZBRkosQ0FQSixFQVlJLDJEQUFDLHlDQUFELENBQU0sSUFBTjtBQUFXLFdBQUcsRUFBQztBQUFmLFNBQ0ksMkRBQUMseUNBQUQ7QUFBTSxZQUFJLEVBQUM7QUFBWCxRQURKLEVBRUksMEZBRkosQ0FaSixFQWlCSSwyREFBQyx5Q0FBRCxDQUFNLElBQU47QUFBVyxXQUFHLEVBQUM7QUFBZixTQUNJLDJEQUFDLHlDQUFEO0FBQU0sWUFBSSxFQUFDO0FBQVgsUUFESixFQUVJLGdGQUZKLENBakJKLEVBc0JJLDJEQUFDLHlDQUFELENBQU0sSUFBTjtBQUFXLFdBQUcsRUFBQztBQUFmLFNBQ0ksMkRBQUMseUNBQUQ7QUFBTSxZQUFJLEVBQUM7QUFBWCxRQURKLEVBRUksbUZBRkosQ0F0QkosQ0FQSixDQURKO0FBcUNIOzs7O0VBeERvQk0sNENBQUssQ0FBQ0wsUzs7QUE0RGhCZ0wseUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDakVBLGNBQWMsbUJBQU8sQ0FBQyxtR0FBbUQ7O0FBRXpFLDRDQUE0QyxRQUFTOztBQUVyRDtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBLGFBQWEsbUJBQU8sQ0FBQyxtR0FBZ0Q7O0FBRXJFOztBQUVBLEdBQUcsS0FBVSxFQUFFLEU7Ozs7Ozs7Ozs7OztBQ25CZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFLLGdEQUFRLENBQUMvQixNQUFULENBQ0ksMkRBQUMsOERBQUQsUUFDRSwyREFBQyw0Q0FBRCxPQURGLENBREosRUFJS3JDLFFBQVEsQ0FBQ3FFLGNBQVQsQ0FBd0IsTUFBeEIsQ0FKTCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNQTTdILFU7Ozs7Z0JBQUFBLFUsaUJBRW1CLFVBQUM4SCxHQUFELEVBQU1DLEdBQU4sRUFBYztBQUMvQkMsUUFBTSxDQUFDQyxPQUFQLENBQWVoSSxXQUFmLENBQTJCO0FBQ3ZCaUUsV0FBTyxFQUFFNEQsR0FEYztBQUV2QkMsT0FBRyxFQUFIQTtBQUZ1QixHQUEzQjtBQUlILEMiLCJmaWxlIjoib3B0aW9ucy5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xuIFx0ZnVuY3Rpb24gd2VicGFja0pzb25wQ2FsbGJhY2soZGF0YSkge1xuIFx0XHR2YXIgY2h1bmtJZHMgPSBkYXRhWzBdO1xuIFx0XHR2YXIgbW9yZU1vZHVsZXMgPSBkYXRhWzFdO1xuIFx0XHR2YXIgZXhlY3V0ZU1vZHVsZXMgPSBkYXRhWzJdO1xuXG4gXHRcdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuIFx0XHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcbiBcdFx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMCwgcmVzb2x2ZXMgPSBbXTtcbiBcdFx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG4gXHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG4gXHRcdFx0XHRyZXNvbHZlcy5wdXNoKGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSk7XG4gXHRcdFx0fVxuIFx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG4gXHRcdH1cbiBcdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG4gXHRcdFx0aWYoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcbiBcdFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHRcdH1cbiBcdFx0fVxuIFx0XHRpZihwYXJlbnRKc29ucEZ1bmN0aW9uKSBwYXJlbnRKc29ucEZ1bmN0aW9uKGRhdGEpO1xuXG4gXHRcdHdoaWxlKHJlc29sdmVzLmxlbmd0aCkge1xuIFx0XHRcdHJlc29sdmVzLnNoaWZ0KCkoKTtcbiBcdFx0fVxuXG4gXHRcdC8vIGFkZCBlbnRyeSBtb2R1bGVzIGZyb20gbG9hZGVkIGNodW5rIHRvIGRlZmVycmVkIGxpc3RcbiBcdFx0ZGVmZXJyZWRNb2R1bGVzLnB1c2guYXBwbHkoZGVmZXJyZWRNb2R1bGVzLCBleGVjdXRlTW9kdWxlcyB8fCBbXSk7XG5cbiBcdFx0Ly8gcnVuIGRlZmVycmVkIG1vZHVsZXMgd2hlbiBhbGwgY2h1bmtzIHJlYWR5XG4gXHRcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIFx0fTtcbiBcdGZ1bmN0aW9uIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCkge1xuIFx0XHR2YXIgcmVzdWx0O1xuIFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWRNb2R1bGVzLmxlbmd0aDsgaSsrKSB7XG4gXHRcdFx0dmFyIGRlZmVycmVkTW9kdWxlID0gZGVmZXJyZWRNb2R1bGVzW2ldO1xuIFx0XHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuIFx0XHRcdGZvcih2YXIgaiA9IDE7IGogPCBkZWZlcnJlZE1vZHVsZS5sZW5ndGg7IGorKykge1xuIFx0XHRcdFx0dmFyIGRlcElkID0gZGVmZXJyZWRNb2R1bGVbal07XG4gXHRcdFx0XHRpZihpbnN0YWxsZWRDaHVua3NbZGVwSWRdICE9PSAwKSBmdWxmaWxsZWQgPSBmYWxzZTtcbiBcdFx0XHR9XG4gXHRcdFx0aWYoZnVsZmlsbGVkKSB7XG4gXHRcdFx0XHRkZWZlcnJlZE1vZHVsZXMuc3BsaWNlKGktLSwgMSk7XG4gXHRcdFx0XHRyZXN1bHQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IGRlZmVycmVkTW9kdWxlWzBdKTtcbiBcdFx0XHR9XG4gXHRcdH1cbiBcdFx0cmV0dXJuIHJlc3VsdDtcbiBcdH1cblxuIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3NcbiBcdC8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuIFx0Ly8gUHJvbWlzZSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbiBcdHZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG4gXHRcdFwib3B0aW9uc1wiOiAwXG4gXHR9O1xuXG4gXHR2YXIgZGVmZXJyZWRNb2R1bGVzID0gW107XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdHZhciBqc29ucEFycmF5ID0gd2luZG93W1wid2VicGFja0pzb25wXCJdID0gd2luZG93W1wid2VicGFja0pzb25wXCJdIHx8IFtdO1xuIFx0dmFyIG9sZEpzb25wRnVuY3Rpb24gPSBqc29ucEFycmF5LnB1c2guYmluZChqc29ucEFycmF5KTtcbiBcdGpzb25wQXJyYXkucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrO1xuIFx0anNvbnBBcnJheSA9IGpzb25wQXJyYXkuc2xpY2UoKTtcbiBcdGZvcih2YXIgaSA9IDA7IGkgPCBqc29ucEFycmF5Lmxlbmd0aDsgaSsrKSB3ZWJwYWNrSnNvbnBDYWxsYmFjayhqc29ucEFycmF5W2ldKTtcbiBcdHZhciBwYXJlbnRKc29ucEZ1bmN0aW9uID0gb2xkSnNvbnBGdW5jdGlvbjtcblxuXG4gXHQvLyBhZGQgZW50cnkgbW9kdWxlIHRvIGRlZmVycmVkIGxpc3RcbiBcdGRlZmVycmVkTW9kdWxlcy5wdXNoKFtcIi4vc3JjL29wdGlvbnMuanNcIixcInZlbmRvclwiXSk7XG4gXHQvLyBydW4gZGVmZXJyZWQgbW9kdWxlcyB3aGVuIHJlYWR5XG4gXHRyZXR1cm4gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKTtcbiIsImV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCIuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9saWIvY3NzLWJhc2UuanNcIikoZmFsc2UpO1xuLy8gaW1wb3J0c1xuXG5cbi8vIG1vZHVsZVxuZXhwb3J0cy5wdXNoKFttb2R1bGUuaWQsIFwiLkFwcCB7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcblxcbi5BcHAtbG9nbyB7XFxuICBhbmltYXRpb246IEFwcC1sb2dvLXNwaW4gaW5maW5pdGUgMjBzIGxpbmVhcjtcXG4gIGhlaWdodDogNXZtaW47XFxuICBtYXJnaW46IDE1cHggMjBweCAwIDIwcHg7XFxufVxcblxcbi5BcHAtaGVhZGVyIHtcXG4gIG1pbi1oZWlnaHQ6IDE1dmg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgXFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBmb250LXNpemU6IGNhbGMoMTVweCArIDJ2bWluKTtcXG4gIGNvbG9yOiB3aGl0ZTtcXG4gIG1hcmdpbjogMjBweCA0MHB4IDEwcHggNDBweDtcXG59XFxuXFxuLkFwcC1saW5rIHtcXG4gIGNvbG9yOiAjNjFkYWZiO1xcbn1cXG5cXG5Aa2V5ZnJhbWVzIEFwcC1sb2dvLXNwaW4ge1xcbiAgZnJvbSB7XFxuICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xcbiAgfVxcbiAgdG8ge1xcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpO1xcbiAgfVxcbn1cXG5cXG4uYW50LXVwbG9hZC1saXN0LWl0ZW0ge1xcbiAgYm9yZGVyLWxlZnQ6IDJweCBzb2xpZCAjOTk5O1xcbiAgYmFja2dyb3VuZDogI2ZmZTBiMjtcXG59XFxuXFxuLmFudC1sYXlvdXQtaGVhZGVyIHtcXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig0MCwgNDQsIDUyKSAhaW1wb3J0YW50O1xcbn1cXG5cXG4uYW50LWNhcmQtaGVhZCB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZiNzRkICFpbXBvcnRhbnQ7XFxufVxcblxcbi5pbnN0cnVjdGlvbkRpdiB7XFxuICBtaW4taGVpZ2h0OiAyMDBweDtcXG59XCIsIFwiXCJdKTtcblxuLy8gZXhwb3J0c1xuIiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2xpYi9jc3MtYmFzZS5qc1wiKShmYWxzZSk7XG4vLyBpbXBvcnRzXG5cblxuLy8gbW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCJib2R5IHtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBcXFwiUm9ib3RvXFxcIiwgXFxcIk94eWdlblxcXCIsXFxuICAgIFxcXCJVYnVudHVcXFwiLCBcXFwiQ2FudGFyZWxsXFxcIiwgXFxcIkZpcmEgU2Fuc1xcXCIsIFxcXCJEcm9pZCBTYW5zXFxcIiwgXFxcIkhlbHZldGljYSBOZXVlXFxcIixcXG4gICAgc2Fucy1zZXJpZjtcXG4gIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xcbiAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcXG59XFxuXFxuY29kZSB7XFxuICBmb250LWZhbWlseTogc291cmNlLWNvZGUtcHJvLCBNZW5sbywgTW9uYWNvLCBDb25zb2xhcywgXFxcIkNvdXJpZXIgTmV3XFxcIixcXG4gICAgbW9ub3NwYWNlO1xcbn1cXG5cIiwgXCJcIl0pO1xuXG4vLyBleHBvcnRzXG4iLCJ2YXIgbWFwID0ge1xuXHRcIi4vYWZcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FmLmpzXCIsXG5cdFwiLi9hZi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYWYuanNcIixcblx0XCIuL2FyXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hci5qc1wiLFxuXHRcIi4vYXItZHpcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FyLWR6LmpzXCIsXG5cdFwiLi9hci1kei5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYXItZHouanNcIixcblx0XCIuL2FyLWt3XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hci1rdy5qc1wiLFxuXHRcIi4vYXIta3cuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FyLWt3LmpzXCIsXG5cdFwiLi9hci1seVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYXItbHkuanNcIixcblx0XCIuL2FyLWx5LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hci1seS5qc1wiLFxuXHRcIi4vYXItbWFcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FyLW1hLmpzXCIsXG5cdFwiLi9hci1tYS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYXItbWEuanNcIixcblx0XCIuL2FyLXNhXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hci1zYS5qc1wiLFxuXHRcIi4vYXItc2EuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FyLXNhLmpzXCIsXG5cdFwiLi9hci10blwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYXItdG4uanNcIixcblx0XCIuL2FyLXRuLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hci10bi5qc1wiLFxuXHRcIi4vYXIuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2FyLmpzXCIsXG5cdFwiLi9helwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYXouanNcIixcblx0XCIuL2F6LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9hei5qc1wiLFxuXHRcIi4vYmVcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2JlLmpzXCIsXG5cdFwiLi9iZS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYmUuanNcIixcblx0XCIuL2JnXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9iZy5qc1wiLFxuXHRcIi4vYmcuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2JnLmpzXCIsXG5cdFwiLi9ibVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYm0uanNcIixcblx0XCIuL2JtLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ibS5qc1wiLFxuXHRcIi4vYm5cIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2JuLmpzXCIsXG5cdFwiLi9ibi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYm4uanNcIixcblx0XCIuL2JvXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9iby5qc1wiLFxuXHRcIi4vYm8uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2JvLmpzXCIsXG5cdFwiLi9iclwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYnIuanNcIixcblx0XCIuL2JyLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ici5qc1wiLFxuXHRcIi4vYnNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2JzLmpzXCIsXG5cdFwiLi9icy5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvYnMuanNcIixcblx0XCIuL2NhXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9jYS5qc1wiLFxuXHRcIi4vY2EuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2NhLmpzXCIsXG5cdFwiLi9jc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvY3MuanNcIixcblx0XCIuL2NzLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9jcy5qc1wiLFxuXHRcIi4vY3ZcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2N2LmpzXCIsXG5cdFwiLi9jdi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvY3YuanNcIixcblx0XCIuL2N5XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9jeS5qc1wiLFxuXHRcIi4vY3kuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2N5LmpzXCIsXG5cdFwiLi9kYVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZGEuanNcIixcblx0XCIuL2RhLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9kYS5qc1wiLFxuXHRcIi4vZGVcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2RlLmpzXCIsXG5cdFwiLi9kZS1hdFwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZGUtYXQuanNcIixcblx0XCIuL2RlLWF0LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9kZS1hdC5qc1wiLFxuXHRcIi4vZGUtY2hcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2RlLWNoLmpzXCIsXG5cdFwiLi9kZS1jaC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZGUtY2guanNcIixcblx0XCIuL2RlLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9kZS5qc1wiLFxuXHRcIi4vZHZcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2R2LmpzXCIsXG5cdFwiLi9kdi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZHYuanNcIixcblx0XCIuL2VsXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lbC5qc1wiLFxuXHRcIi4vZWwuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VsLmpzXCIsXG5cdFwiLi9lbi1hdVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZW4tYXUuanNcIixcblx0XCIuL2VuLWF1LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lbi1hdS5qc1wiLFxuXHRcIi4vZW4tY2FcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VuLWNhLmpzXCIsXG5cdFwiLi9lbi1jYS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZW4tY2EuanNcIixcblx0XCIuL2VuLWdiXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lbi1nYi5qc1wiLFxuXHRcIi4vZW4tZ2IuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VuLWdiLmpzXCIsXG5cdFwiLi9lbi1pZVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZW4taWUuanNcIixcblx0XCIuL2VuLWllLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lbi1pZS5qc1wiLFxuXHRcIi4vZW4taWxcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VuLWlsLmpzXCIsXG5cdFwiLi9lbi1pbC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZW4taWwuanNcIixcblx0XCIuL2VuLW56XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lbi1uei5qc1wiLFxuXHRcIi4vZW4tbnouanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VuLW56LmpzXCIsXG5cdFwiLi9lb1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZW8uanNcIixcblx0XCIuL2VvLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lby5qc1wiLFxuXHRcIi4vZXNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VzLmpzXCIsXG5cdFwiLi9lcy1kb1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZXMtZG8uanNcIixcblx0XCIuL2VzLWRvLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lcy1kby5qc1wiLFxuXHRcIi4vZXMtdXNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2VzLXVzLmpzXCIsXG5cdFwiLi9lcy11cy5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZXMtdXMuanNcIixcblx0XCIuL2VzLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9lcy5qc1wiLFxuXHRcIi4vZXRcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2V0LmpzXCIsXG5cdFwiLi9ldC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZXQuanNcIixcblx0XCIuL2V1XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ldS5qc1wiLFxuXHRcIi4vZXUuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2V1LmpzXCIsXG5cdFwiLi9mYVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZmEuanNcIixcblx0XCIuL2ZhLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9mYS5qc1wiLFxuXHRcIi4vZmlcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2ZpLmpzXCIsXG5cdFwiLi9maS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZmkuanNcIixcblx0XCIuL2ZvXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9mby5qc1wiLFxuXHRcIi4vZm8uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2ZvLmpzXCIsXG5cdFwiLi9mclwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZnIuanNcIixcblx0XCIuL2ZyLWNhXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9mci1jYS5qc1wiLFxuXHRcIi4vZnItY2EuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2ZyLWNhLmpzXCIsXG5cdFwiLi9mci1jaFwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZnItY2guanNcIixcblx0XCIuL2ZyLWNoLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9mci1jaC5qc1wiLFxuXHRcIi4vZnIuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2ZyLmpzXCIsXG5cdFwiLi9meVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZnkuanNcIixcblx0XCIuL2Z5LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9meS5qc1wiLFxuXHRcIi4vZ2RcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2dkLmpzXCIsXG5cdFwiLi9nZC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZ2QuanNcIixcblx0XCIuL2dsXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9nbC5qc1wiLFxuXHRcIi4vZ2wuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2dsLmpzXCIsXG5cdFwiLi9nb20tbGF0blwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZ29tLWxhdG4uanNcIixcblx0XCIuL2dvbS1sYXRuLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9nb20tbGF0bi5qc1wiLFxuXHRcIi4vZ3VcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2d1LmpzXCIsXG5cdFwiLi9ndS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvZ3UuanNcIixcblx0XCIuL2hlXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9oZS5qc1wiLFxuXHRcIi4vaGUuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2hlLmpzXCIsXG5cdFwiLi9oaVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvaGkuanNcIixcblx0XCIuL2hpLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9oaS5qc1wiLFxuXHRcIi4vaHJcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2hyLmpzXCIsXG5cdFwiLi9oci5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvaHIuanNcIixcblx0XCIuL2h1XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9odS5qc1wiLFxuXHRcIi4vaHUuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2h1LmpzXCIsXG5cdFwiLi9oeS1hbVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvaHktYW0uanNcIixcblx0XCIuL2h5LWFtLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9oeS1hbS5qc1wiLFxuXHRcIi4vaWRcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2lkLmpzXCIsXG5cdFwiLi9pZC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvaWQuanNcIixcblx0XCIuL2lzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9pcy5qc1wiLFxuXHRcIi4vaXMuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2lzLmpzXCIsXG5cdFwiLi9pdFwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvaXQuanNcIixcblx0XCIuL2l0LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9pdC5qc1wiLFxuXHRcIi4vamFcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2phLmpzXCIsXG5cdFwiLi9qYS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvamEuanNcIixcblx0XCIuL2p2XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9qdi5qc1wiLFxuXHRcIi4vanYuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2p2LmpzXCIsXG5cdFwiLi9rYVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUva2EuanNcIixcblx0XCIuL2thLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9rYS5qc1wiLFxuXHRcIi4va2tcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2trLmpzXCIsXG5cdFwiLi9ray5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUva2suanNcIixcblx0XCIuL2ttXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9rbS5qc1wiLFxuXHRcIi4va20uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2ttLmpzXCIsXG5cdFwiLi9rblwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUva24uanNcIixcblx0XCIuL2tuLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9rbi5qc1wiLFxuXHRcIi4va29cIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2tvLmpzXCIsXG5cdFwiLi9rby5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUva28uanNcIixcblx0XCIuL2t5XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9reS5qc1wiLFxuXHRcIi4va3kuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2t5LmpzXCIsXG5cdFwiLi9sYlwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbGIuanNcIixcblx0XCIuL2xiLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9sYi5qc1wiLFxuXHRcIi4vbG9cIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2xvLmpzXCIsXG5cdFwiLi9sby5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbG8uanNcIixcblx0XCIuL2x0XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9sdC5qc1wiLFxuXHRcIi4vbHQuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL2x0LmpzXCIsXG5cdFwiLi9sdlwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbHYuanNcIixcblx0XCIuL2x2LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9sdi5qc1wiLFxuXHRcIi4vbWVcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21lLmpzXCIsXG5cdFwiLi9tZS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbWUuanNcIixcblx0XCIuL21pXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9taS5qc1wiLFxuXHRcIi4vbWkuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21pLmpzXCIsXG5cdFwiLi9ta1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbWsuanNcIixcblx0XCIuL21rLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9tay5qc1wiLFxuXHRcIi4vbWxcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21sLmpzXCIsXG5cdFwiLi9tbC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbWwuanNcIixcblx0XCIuL21uXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9tbi5qc1wiLFxuXHRcIi4vbW4uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21uLmpzXCIsXG5cdFwiLi9tclwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbXIuanNcIixcblx0XCIuL21yLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9tci5qc1wiLFxuXHRcIi4vbXNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21zLmpzXCIsXG5cdFwiLi9tcy1teVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbXMtbXkuanNcIixcblx0XCIuL21zLW15LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9tcy1teS5qc1wiLFxuXHRcIi4vbXMuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL21zLmpzXCIsXG5cdFwiLi9tdFwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbXQuanNcIixcblx0XCIuL210LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9tdC5qc1wiLFxuXHRcIi4vbXlcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL215LmpzXCIsXG5cdFwiLi9teS5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbXkuanNcIixcblx0XCIuL25iXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9uYi5qc1wiLFxuXHRcIi4vbmIuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL25iLmpzXCIsXG5cdFwiLi9uZVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbmUuanNcIixcblx0XCIuL25lLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9uZS5qc1wiLFxuXHRcIi4vbmxcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL25sLmpzXCIsXG5cdFwiLi9ubC1iZVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbmwtYmUuanNcIixcblx0XCIuL25sLWJlLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ubC1iZS5qc1wiLFxuXHRcIi4vbmwuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL25sLmpzXCIsXG5cdFwiLi9ublwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvbm4uanNcIixcblx0XCIuL25uLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ubi5qc1wiLFxuXHRcIi4vcGEtaW5cIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3BhLWluLmpzXCIsXG5cdFwiLi9wYS1pbi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvcGEtaW4uanNcIixcblx0XCIuL3BsXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9wbC5qc1wiLFxuXHRcIi4vcGwuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3BsLmpzXCIsXG5cdFwiLi9wdFwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvcHQuanNcIixcblx0XCIuL3B0LWJyXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9wdC1ici5qc1wiLFxuXHRcIi4vcHQtYnIuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3B0LWJyLmpzXCIsXG5cdFwiLi9wdC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvcHQuanNcIixcblx0XCIuL3JvXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9yby5qc1wiLFxuXHRcIi4vcm8uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3JvLmpzXCIsXG5cdFwiLi9ydVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvcnUuanNcIixcblx0XCIuL3J1LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9ydS5qc1wiLFxuXHRcIi4vc2RcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NkLmpzXCIsXG5cdFwiLi9zZC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc2QuanNcIixcblx0XCIuL3NlXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zZS5qc1wiLFxuXHRcIi4vc2UuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NlLmpzXCIsXG5cdFwiLi9zaVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc2kuanNcIixcblx0XCIuL3NpLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zaS5qc1wiLFxuXHRcIi4vc2tcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NrLmpzXCIsXG5cdFwiLi9zay5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc2suanNcIixcblx0XCIuL3NsXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zbC5qc1wiLFxuXHRcIi4vc2wuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NsLmpzXCIsXG5cdFwiLi9zcVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc3EuanNcIixcblx0XCIuL3NxLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zcS5qc1wiLFxuXHRcIi4vc3JcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NyLmpzXCIsXG5cdFwiLi9zci1jeXJsXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zci1jeXJsLmpzXCIsXG5cdFwiLi9zci1jeXJsLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zci1jeXJsLmpzXCIsXG5cdFwiLi9zci5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc3IuanNcIixcblx0XCIuL3NzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zcy5qc1wiLFxuXHRcIi4vc3MuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3NzLmpzXCIsXG5cdFwiLi9zdlwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc3YuanNcIixcblx0XCIuL3N2LmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS9zdi5qc1wiLFxuXHRcIi4vc3dcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3N3LmpzXCIsXG5cdFwiLi9zdy5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvc3cuanNcIixcblx0XCIuL3RhXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90YS5qc1wiLFxuXHRcIi4vdGEuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3RhLmpzXCIsXG5cdFwiLi90ZVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdGUuanNcIixcblx0XCIuL3RlLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90ZS5qc1wiLFxuXHRcIi4vdGV0XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90ZXQuanNcIixcblx0XCIuL3RldC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdGV0LmpzXCIsXG5cdFwiLi90Z1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdGcuanNcIixcblx0XCIuL3RnLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90Zy5qc1wiLFxuXHRcIi4vdGhcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3RoLmpzXCIsXG5cdFwiLi90aC5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdGguanNcIixcblx0XCIuL3RsLXBoXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90bC1waC5qc1wiLFxuXHRcIi4vdGwtcGguanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3RsLXBoLmpzXCIsXG5cdFwiLi90bGhcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3RsaC5qc1wiLFxuXHRcIi4vdGxoLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90bGguanNcIixcblx0XCIuL3RyXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90ci5qc1wiLFxuXHRcIi4vdHIuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3RyLmpzXCIsXG5cdFwiLi90emxcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3R6bC5qc1wiLFxuXHRcIi4vdHpsLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90emwuanNcIixcblx0XCIuL3R6bVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdHptLmpzXCIsXG5cdFwiLi90em0tbGF0blwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdHptLWxhdG4uanNcIixcblx0XCIuL3R6bS1sYXRuLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90em0tbGF0bi5qc1wiLFxuXHRcIi4vdHptLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS90em0uanNcIixcblx0XCIuL3VnLWNuXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS91Zy1jbi5qc1wiLFxuXHRcIi4vdWctY24uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3VnLWNuLmpzXCIsXG5cdFwiLi91a1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdWsuanNcIixcblx0XCIuL3VrLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS91ay5qc1wiLFxuXHRcIi4vdXJcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3VyLmpzXCIsXG5cdFwiLi91ci5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdXIuanNcIixcblx0XCIuL3V6XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS91ei5qc1wiLFxuXHRcIi4vdXotbGF0blwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdXotbGF0bi5qc1wiLFxuXHRcIi4vdXotbGF0bi5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdXotbGF0bi5qc1wiLFxuXHRcIi4vdXouanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3V6LmpzXCIsXG5cdFwiLi92aVwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvdmkuanNcIixcblx0XCIuL3ZpLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS92aS5qc1wiLFxuXHRcIi4veC1wc2V1ZG9cIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3gtcHNldWRvLmpzXCIsXG5cdFwiLi94LXBzZXVkby5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUveC1wc2V1ZG8uanNcIixcblx0XCIuL3lvXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS95by5qc1wiLFxuXHRcIi4veW8uanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3lvLmpzXCIsXG5cdFwiLi96aC1jblwiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvemgtY24uanNcIixcblx0XCIuL3poLWNuLmpzXCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS96aC1jbi5qc1wiLFxuXHRcIi4vemgtaGtcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3poLWhrLmpzXCIsXG5cdFwiLi96aC1oay5qc1wiOiBcIi4vbm9kZV9tb2R1bGVzL21vbWVudC9sb2NhbGUvemgtaGsuanNcIixcblx0XCIuL3poLXR3XCI6IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZS96aC10dy5qc1wiLFxuXHRcIi4vemgtdHcuanNcIjogXCIuL25vZGVfbW9kdWxlcy9tb21lbnQvbG9jYWxlL3poLXR3LmpzXCJcbn07XG5cblxuZnVuY3Rpb24gd2VicGFja0NvbnRleHQocmVxKSB7XG5cdHZhciBpZCA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZShyZXEpO1xuXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhpZCk7XG59XG5mdW5jdGlvbiB3ZWJwYWNrQ29udGV4dFJlc29sdmUocmVxKSB7XG5cdHZhciBpZCA9IG1hcFtyZXFdO1xuXHRpZighKGlkICsgMSkpIHsgLy8gY2hlY2sgZm9yIG51bWJlciBvciBzdHJpbmdcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0cmV0dXJuIGlkO1xufVxud2VicGFja0NvbnRleHQua2V5cyA9IGZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0S2V5cygpIHtcblx0cmV0dXJuIE9iamVjdC5rZXlzKG1hcCk7XG59O1xud2VicGFja0NvbnRleHQucmVzb2x2ZSA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZTtcbm1vZHVsZS5leHBvcnRzID0gd2VicGFja0NvbnRleHQ7XG53ZWJwYWNrQ29udGV4dC5pZCA9IFwiLi9ub2RlX21vZHVsZXMvbW9tZW50L2xvY2FsZSBzeW5jIHJlY3Vyc2l2ZSBeXFxcXC5cXFxcLy4qJFwiOyIsIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9pbmRleC5qcyEuL0FwcC5jc3NcIik7XG5cbmlmKHR5cGVvZiBjb250ZW50ID09PSAnc3RyaW5nJykgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuXG52YXIgdHJhbnNmb3JtO1xudmFyIGluc2VydEludG87XG5cblxuXG52YXIgb3B0aW9ucyA9IHtcImhtclwiOnRydWV9XG5cbm9wdGlvbnMudHJhbnNmb3JtID0gdHJhbnNmb3JtXG5vcHRpb25zLmluc2VydEludG8gPSB1bmRlZmluZWQ7XG5cbnZhciB1cGRhdGUgPSByZXF1aXJlKFwiIS4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qc1wiKShjb250ZW50LCBvcHRpb25zKTtcblxuaWYoY29udGVudC5sb2NhbHMpIG1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHM7XG5cbmlmKG1vZHVsZS5ob3QpIHtcblx0bW9kdWxlLmhvdC5hY2NlcHQoXCIhIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2luZGV4LmpzIS4vQXBwLmNzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2luZGV4LmpzIS4vQXBwLmNzc1wiKTtcblxuXHRcdGlmKHR5cGVvZiBuZXdDb250ZW50ID09PSAnc3RyaW5nJykgbmV3Q29udGVudCA9IFtbbW9kdWxlLmlkLCBuZXdDb250ZW50LCAnJ11dO1xuXG5cdFx0dmFyIGxvY2FscyA9IChmdW5jdGlvbihhLCBiKSB7XG5cdFx0XHR2YXIga2V5LCBpZHggPSAwO1xuXG5cdFx0XHRmb3Ioa2V5IGluIGEpIHtcblx0XHRcdFx0aWYoIWIgfHwgYVtrZXldICE9PSBiW2tleV0pIHJldHVybiBmYWxzZTtcblx0XHRcdFx0aWR4Kys7XG5cdFx0XHR9XG5cblx0XHRcdGZvcihrZXkgaW4gYikgaWR4LS07XG5cblx0XHRcdHJldHVybiBpZHggPT09IDA7XG5cdFx0fShjb250ZW50LmxvY2FscywgbmV3Q29udGVudC5sb2NhbHMpKTtcblxuXHRcdGlmKCFsb2NhbHMpIHRocm93IG5ldyBFcnJvcignQWJvcnRpbmcgQ1NTIEhNUiBkdWUgdG8gY2hhbmdlZCBjc3MtbW9kdWxlcyBsb2NhbHMuJyk7XG5cblx0XHR1cGRhdGUobmV3Q29udGVudCk7XG5cdH0pO1xuXG5cdG1vZHVsZS5ob3QuZGlzcG9zZShmdW5jdGlvbigpIHsgdXBkYXRlKCk7IH0pO1xufSIsImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgJy4vQXBwLmNzcyc7XG5cbmltcG9ydCBTaWRlclBhbmVsIGZyb20gJy4vY29tcG9uZW50cy9TaWRlclBhbmVsJztcbmltcG9ydCBGb290ZXJQYW5lbCBmcm9tICcuL2NvbXBvbmVudHMvRm9vdGVyUGFuZWwnO1xuaW1wb3J0IFBhZ2VSb3V0ZXIgZnJvbSAnLi9jb21wb25lbnRzL1BhZ2VSb3V0ZXInO1xuaW1wb3J0IHsgTGF5b3V0IH0gZnJvbSAnYW50ZCc7XG5cbmNsYXNzIEFwcCBleHRlbmRzIENvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpO1xuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBwYWdlOiBcImVkaXRvclwiXG4gICAgfTtcbiAgfVxuXG4gIGNoYW5nZVBhZ2UgPSAoeyBrZXkgfSkgPT4ge1xuICAgIHRoaXMuc2V0U3RhdGUoKCkgPT4gKHsgcGFnZToga2V5IH0pKTtcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPExheW91dD5cbiAgICAgICAgPFNpZGVyUGFuZWwgY2hhbmdlUGFnZT17dGhpcy5jaGFuZ2VQYWdlfSAvPlxuICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgIDxQYWdlUm91dGVyIHBhZ2U9e3RoaXMuc3RhdGUucGFnZX0gLz5cbiAgICAgICAgICA8Rm9vdGVyUGFuZWwgLz5cbiAgICAgICAgPC9MYXlvdXQ+XG4gICAgICA8L0xheW91dD5cbiAgICApO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDsiLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHsgU3RlcHMsIEljb24sIFJvdywgQ29sIH0gZnJvbSAnYW50ZCc7XHJcblxyXG5jb25zdCBTdGVwID0gU3RlcHMuU3RlcDtcclxuXHJcbmNsYXNzIEVkaXRvckluc3RydWN0aW9uIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcclxuXHJcbiAgICByZW5kZXIoKSB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPFJvdyBzdHlsZT17e3BhZGRpbmdUb3A6XCI1MHB4XCJ9fT5cclxuICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0vPlxyXG4gICAgICAgICAgICAgICAgPENvbCBzcGFuPXsxNn0gYWxpZ249XCJtaWRkbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U3RlcHM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGVwIHN0YXR1cz1cImZpbmlzaFwiIHRpdGxlPVwiVXBsb2FkXCIgaWNvbj17PEljb24gdHlwZT1cInVwbG9hZFwiIC8+fSBkZXNjcmlwdGlvbj1cIlVwbG9hZCB5b3VyIEpzb24gZmlsZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGVwIHN0YXR1cz1cImZpbmlzaFwiIHRpdGxlPVwiVmlld1wiIGljb249ezxJY29uIHR5cGU9XCJzb2x1dGlvblwiIC8+fSBkZXNjcmlwdGlvbj1cIlZpZXcgZGF0YSBmb3IgZWFjaCBkb2N1bWVudFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGVwIHN0YXR1cz1cImZpbmlzaFwiIHRpdGxlPVwiRWRpdFwiIGljb249ezxJY29uIHR5cGU9XCJlZGl0XCIgLz59IGRlc2NyaXB0aW9uPVwiRWRpdCwgYWRkLCByZW1vdmUgZGF0YSBlbnRyaWVzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0ZXAgc3RhdHVzPVwiZmluaXNoXCIgdGl0bGU9XCJEb3dubG9hZFwiIGljb249ezxJY29uIHR5cGU9XCJkb3dubG9hZFwiIC8+fSBkZXNjcmlwdGlvbj1cIkRvd25sb2FkIHlvdXIgSnNvbiBmaWxlXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU3RlcHM+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0vPlxyXG4gICAgICAgICAgICA8L1Jvdz4gICAgICBcclxuICAgICAgICApXHJcbiAgICB9XHJcbn0gXHJcblxyXG5leHBvcnQgZGVmYXVsdCBFZGl0b3JJbnN0cnVjdGlvbjsiLCJcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IFVwbG9hZCwgSWNvbiB9IGZyb20gJ2FudGQnO1xyXG5pbXBvcnQgTWV0YUluZm9DYXJkIGZyb20gJy4vTWV0YUluZm9DYXJkJztcclxuXHJcbmNvbnN0IERyYWdnZXIgPSBVcGxvYWQuRHJhZ2dlcjtcclxuXHJcbmNsYXNzIEZpbGVVcGxvYWQgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgc3RhdGUgPSB7XHJcbiAgICAgICAgZmlsZUxpc3Q6IFtdLFxyXG4gICAgICAgIHVwbG9hZGVkSnNvbjoge31cclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVVcGxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSB0aGlzLnN0YXRlLmZpbGVMaXN0WzBdLm5hbWU7XHJcbiAgICAgICAgdGhpcy5yZWFkRmlsZSh0aGlzLnN0YXRlLmZpbGVMaXN0WzBdKS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgICAgIHVwbG9hZGVkSnNvbjoganNvblxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB0aGlzLnByb3BzLnNldFVwbG9hZGVkSnNvbihqc29uLCBmaWxlTmFtZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmVhZEZpbGUgPSAoZmlsZSkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZVJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgICAgICAgIGZpbGVSZWFkZXIub25sb2FkID0gKGUpID0+IHtcclxuICAgICAgICAgICAgICAgIHJlc29sdmUoSlNPTi5wYXJzZShlLnRhcmdldC5yZXN1bHQpKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgZmlsZVJlYWRlci5yZWFkQXNUZXh0KGZpbGUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgXHJcblxyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHNob3dDYXJkID0gdGhpcy5zdGF0ZS5maWxlTGlzdC5sZW5ndGggIT09IDA7XHJcbiAgICAgICAgY29uc3QganNvbiA9IHRoaXMuc3RhdGUudXBsb2FkZWRKc29uO1xyXG4gICAgICAgIGNvbnN0IG1ldGFJbmZvID0ganNvbi5tZXRhPyBqc29uLm1ldGEgOiB7fTtcclxuICAgICAgICBjb25zdCBtZXRhSW5mb1Zpc2libGUgPSBqc29uLm1ldGEgIT0gbnVsbDtcclxuICAgICAgICBjb25zdCBwYWdlTnVtID0ganNvbi5tZXRhPyAoKGpzb24ucGFnZXM/IGpzb24ucGFnZXMubGVuZ3RoIDogMCkgKyAoanNvbi5wYWdlc19yZWNpcGllbnQ/IGpzb24ucGFnZXNfcmVjaXBpZW50Lmxlbmd0aCA6IDApKSA6IDA7XHJcblxyXG4gICAgICAgIGNvbnN0IHByb3BzID0ge1xyXG4gICAgICAgICAgICBhY2NlcHQ6XCIuanNvblwiLFxyXG4gICAgICAgICAgICBvblJlbW92ZTogKGZpbGUpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoKHsgZmlsZUxpc3QgfSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpbmRleCA9IGZpbGVMaXN0LmluZGV4T2YoZmlsZSk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0ZpbGVMaXN0ID0gZmlsZUxpc3Quc2xpY2UoKTtcclxuICAgICAgICAgICAgICAgICAgbmV3RmlsZUxpc3Quc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlTGlzdDogbmV3RmlsZUxpc3QsXHJcbiAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgIHVwbG9hZGVkSnNvbjoge31cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wcm9wcy5zZXRVcGxvYWRlZEpzb24oe30pO1xyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJlZm9yZVVwbG9hZDogKGZpbGUpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvcHMuc2V0VXBsb2FkZWRKc29uKHt9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVMaXN0OiBbZmlsZV0sXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZVVwbG9hZCgpO1xyXG4gICAgICAgICAgICAgICAgfSwgMTAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGZpbGVMaXN0OiB0aGlzLnN0YXRlLmZpbGVMaXN0LFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxEcmFnZ2VyIHsuLi5wcm9wc30gc3R5bGU9e3tiYWNrZ3JvdW5kOicjZmZiNzRkJ319PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImFudC11cGxvYWQtZHJhZy1pY29uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gdHlwZT1cImluYm94XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYW50LXVwbG9hZC10ZXh0XCI+Q2xpY2sgb3IgZHJhZyBmaWxlIHRvIHRoaXMgYXJlYSB0byB1cGxvYWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYW50LXVwbG9hZC1oaW50XCI+UGxlYXNlIHVzZSBKU09OIGZpbGUgZnJvbSBBRVggUmVjY29yZGVyPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9EcmFnZ2VyPlxyXG5cclxuICAgICAgICAgICAgICAgIDxNZXRhSW5mb0NhcmQgXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvdz17c2hvd0NhcmR9IFxyXG4gICAgICAgICAgICAgICAgICAgIG1ldGE9e21ldGFJbmZvfSBcclxuICAgICAgICAgICAgICAgICAgICBudW1PZlBhZ2VzID0ge3BhZ2VOdW19XHJcbiAgICAgICAgICAgICAgICAgICAgdmlzaWJsZT17bWV0YUluZm9WaXNpYmxlfSAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDwvTWV0YUluZm9DYXJkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApXHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGaWxlVXBsb2FkOyIsIlxyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHsgTGF5b3V0IH0gZnJvbSAnYW50ZCc7XHJcblxyXG5jb25zdCB7IEZvb3RlciB9ID0gTGF5b3V0O1xyXG5cclxuY2xhc3MgRm9vdGVyUGFuZWwgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxGb290ZXIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgICAgICAgIFRlc3QgwqkyMDE4IEFFWCBSZWNvcmRlclxyXG4gICAgICAgICAgICA8L0Zvb3Rlcj5cclxuICAgICAgICApXHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb290ZXJQYW5lbDsiLCJcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGF5b3V0IH0gZnJvbSAnYW50ZCc7XHJcbmNvbnN0IHsgSGVhZGVyIH0gPSBMYXlvdXQ7XHJcblxyXG5jbGFzcyBIZWFkZXJQYW5lbCBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcbiAgICByZW5kZXIoKSB7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxIZWFkZXIgY2xhc3NOYW1lPVwiQXBwLWhlYWRlclwiPiAgXHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7dGhpcy5wcm9wcy50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9IZWFkZXI+XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyUGFuZWw7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGF5b3V0LCBSb3csIENvbCwgQnV0dG9uIH0gZnJvbSAnYW50ZCc7XHJcbmltcG9ydCBIZWFkZXJQYW5lbCBmcm9tICcuL0hlYWRlclBhbmVsJztcclxuaW1wb3J0IEZpbGVVcGxvYWQgZnJvbSAnLi9GaWxlVXBsb2FkJztcclxuaW1wb3J0IFBhZ2VzVGFiIGZyb20gJy4vUGFnZXNUYWInO1xyXG5pbXBvcnQgc2F2ZUFzIGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5pbXBvcnQgRWRpdG9ySW5zdHJ1Y3Rpb24gZnJvbSAnLi9FZGl0b3JJbnN0cnVjdGlvbic7XHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50JztcclxuaW1wb3J0IHsgY2hhbmdlQ29uZmlybUxvY2FsZSB9IGZyb20gJ2FudGQvbGliL21vZGFsL2xvY2FsZSc7XHJcbmltcG9ydCB7IENocm9tZVV0aWwgfSBmcm9tIFwiLi4vdXRpbC9DaHJvbWVVaXRsXCI7XHJcblxyXG5jb25zdCB7IENvbnRlbnQgfSA9IExheW91dDtcclxuXHJcbmNsYXNzIEpzb25FZGl0b3IgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJvcHMpIHtcclxuICAgICAgICBzdXBlcihwcm9wcyk7XHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgICAgICAgb3JpZ2luYWxKc29uOiB7fSxcclxuICAgICAgICAgICAgcmV2aXNlZEpzb246IHt9LFxyXG4gICAgICAgICAgICBkaXNwbGF5UGFnZXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBmaWxlTmFtZTogXCJcIlxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNldFVwbG9hZGVkSnNvbiA9IHRoaXMuc2V0VXBsb2FkZWRKc29uLmJpbmQodGhpcyk7XHJcbiAgICAgICAgdGhpcy51cGRhdGVSZXZpc2VkSnNvbiA9IHRoaXMudXBkYXRlUmV2aXNlZEpzb24uYmluZCh0aGlzKTtcclxuICAgICAgICB0aGlzLmRvd25sb2FkUmV2aXNlZEpzb24gPSB0aGlzLmRvd25sb2FkUmV2aXNlZEpzb24uYmluZCh0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRVcGxvYWRlZEpzb24gPSAoanNvbiwgZmlsZU5hbWUpID0+IHtcclxuICAgICAgICBDaHJvbWVVdGlsLnNlbmRNZXNzYWdlKFwiY2FvbmltYVwiKTtcclxuICAgICAgICBpZiAoanNvbi5tZXRhKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgb3JpZ2luYWxKc29uOiBqc29uLFxyXG4gICAgICAgICAgICAgICAgZGlzcGxheVBhZ2VzOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgZmlsZU5hbWVcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgICAgIG9yaWdpbmFsSnNvbjoge30sXHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5UGFnZXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZmlsZU5hbWU6IFwiXCJcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZVJldmlzZWRKc29uID0gKGpzb24pID0+IHtcclxuICAgICAgICBpZiAoanNvbi5tZXRhKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgcmV2aXNlZEpzb246IGpzb25cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZG93bmxvYWRSZXZpc2VkSnNvbiA9ICgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImRvd25sb2FkaW5nXCIpO1xyXG4gICAgICAgIGNvbnN0IGpzb24gPSBKU09OLnN0cmluZ2lmeSh0aGlzLnN0YXRlLnJldmlzZWRKc29uLCBudWxsLCAyKTtcclxuICAgICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2pzb25dLCB7IHR5cGU6IFwiYXBwbGljYXRpb24vanNvblwiIH0pO1xyXG4gICAgICAgIHNhdmVBcyhibG9iLCB0aGlzLnN0YXRlLmZpbGVOYW1lLnNwbGl0KFwiLlwiKVswXSArIFwiLVJFVklTRUQuanNvblwiKTtcclxuICAgIH1cclxuXHJcbiAgICByZW5kZXIoKSB7XHJcbiAgICAgICAgY29uc3QgZG93bmxvYWRCdG5EaXNhYmxlID0gIXRoaXMuc3RhdGUucmV2aXNlZEpzb24ubWV0YSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICBjb25zdCBwYWdlRGlzcGxheSA9IHRoaXMuc3RhdGUuZGlzcGxheVBhZ2VzID9cclxuICAgICAgICAgICAgKFxyXG4gICAgICAgICAgICAgICAgPFBhZ2VzVGFiIGpzb249e3RoaXMuc3RhdGUub3JpZ2luYWxKc29ufSB1cGRhdGVSZXZpc2VkSnNvbj17dGhpcy51cGRhdGVSZXZpc2VkSnNvbn0vPlxyXG4gICAgICAgICAgICApIDpcclxuICAgICAgICAgICAgKFxyXG4gICAgICAgICAgICAgICAgPEVkaXRvckluc3RydWN0aW9uIC8+XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxMYXlvdXQ+XHJcbiAgICAgICAgICAgICAgICA8SGVhZGVyUGFuZWwgdGl0bGU9XCJBRVggUmVjb3JkZXIgSlNPTiBFZGl0b3JcIiAvPlxyXG4gICAgICAgICAgICAgICAgPENvbnRlbnQgc3R5bGU9e3sgbWFyZ2luOiAnMCAxNnB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IDI0IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17MTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCBsZz17Nn0gc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcxMHB4JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVVcGxvYWQgc2V0VXBsb2FkZWRKc29uPXt0aGlzLnNldFVwbG9hZGVkSnNvbn0gPjwvRmlsZVVwbG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbjogJzUwcHggMTBweCA1MHB4IDBweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIiBpY29uPVwiZG93bmxvYWRcIiBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXt0aGlzLmRvd25sb2FkUmV2aXNlZEpzb259IGJsb2NrIGRpc2FibGVkPXtkb3dubG9hZEJ0bkRpc2FibGV9PkRvd25sb2FkPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIGxnPXsxOH0gc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogJzEwcHgnLCBtaW5IZWlnaHQ6ICc2OHZoJywgYmFja2dyb3VuZDogJyNmYWZhZmEnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGFnZURpc3BsYXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0NvbnRlbnQ+XHJcbiAgICAgICAgICAgIDwvTGF5b3V0PlxyXG5cclxuICAgICAgICApXHJcblxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBKc29uRWRpdG9yOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IENhcmQgfSBmcm9tICdhbnRkJztcclxuXHJcblxyXG5jbGFzcyBNZXRhSW5mb0NhcmQgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIGNvbnN0IHN0eWxlID0gdGhpcy5wcm9wcy52aXNpYmxlID8geyBtYXJnaW5Ub3A6ICc1MHB4JywgZGlzcGxheTogJ2Jsb2NrJyB9IDogeyBkaXNwbGF5OiAnbm9uZScgfTtcclxuICAgICAgICBjb25zdCBtZXRhSW5mbyA9IHRoaXMucHJvcHMubWV0YTtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9e21ldGFJbmZvLmNvbXBhbnlOYW1lICYmIG1ldGFJbmZvLmNvbXBhbnlOYW1lICE9PSBcIlwiID8gbWV0YUluZm8uY29tcGFueU5hbWUgOiBcIlVua293biBjb21wYW55XCJ9ICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3N0eWxlfVxyXG4gICAgICAgICAgICAgICAgaG92ZXJhYmxlPXt0cnVlfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cD5UcmFuc2FjdGlvbiBOYW1lOiB7bWV0YUluZm8udHJhbnNhY3Rpb25OYW1lICE9PSBcIlwiID8gbWV0YUluZm8udHJhbnNhY3Rpb25OYW1lIDogXCJVbmtvd24gdHJhbnNhY3Rpb25cIn08L3A+XHJcbiAgICAgICAgICAgICAgICA8cD5UcmFuc1JlZklkOiB7bWV0YUluZm8udHJhbnNSZWZJZCAhPT0gXCJcIiA/IG1ldGFJbmZvLnRyYW5zUmVmSWQgOiBcIlVua293biB0cmFuc1JlZklkXCJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgPHA+TnVtYmVyIG9mIFBhZ2VzOiB7dGhpcy5wcm9wcy5udW1PZlBhZ2VzfSA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cD5SZWNvcmRlciB2ZXJzaW9uOiB7bWV0YUluZm8ucmVjb3JkZXJWZXJzaW9uPyBtZXRhSW5mby5yZWNvcmRlclZlcnNpb24gOiBcIk9sZCByZWNvcmRlciB2ZXJzaW9uXCJ9PC9wPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWV0YUluZm9DYXJkOyIsIlxyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBUYWJsZSwgSW5wdXQsIEJ1dHRvbiwgUG9wY29uZmlybSwgRm9ybSB9IGZyb20gJ2FudGQnO1xyXG5cclxuY29uc3QgRm9ybUl0ZW0gPSBGb3JtLkl0ZW07XHJcbmNvbnN0IEVkaXRhYmxlQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoKTtcclxuXHJcbmNvbnN0IEVkaXRhYmxlUm93ID0gKHsgZm9ybSwgaW5kZXgsIC4uLnByb3BzIH0pID0+IChcclxuICAgIDxFZGl0YWJsZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2Zvcm19PlxyXG4gICAgICAgIDx0ciB7Li4ucHJvcHN9IC8+XHJcbiAgICA8L0VkaXRhYmxlQ29udGV4dC5Qcm92aWRlcj5cclxuKTtcclxuXHJcbmNvbnN0IEVkaXRhYmxlRm9ybVJvdyA9IEZvcm0uY3JlYXRlKCkoRWRpdGFibGVSb3cpO1xyXG5cclxuY2xhc3MgRWRpdGFibGVDZWxsIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcclxuICAgIHN0YXRlID0ge1xyXG4gICAgICAgIGVkaXRpbmc6IGZhbHNlLFxyXG4gICAgfVxyXG5cclxuICAgIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgICAgIGlmICh0aGlzLnByb3BzLmVkaXRhYmxlKSB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5oYW5kbGVDbGlja091dHNpZGUsIHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcclxuICAgICAgICBpZiAodGhpcy5wcm9wcy5lZGl0YWJsZSkge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuaGFuZGxlQ2xpY2tPdXRzaWRlLCB0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlRWRpdCA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBlZGl0aW5nID0gIXRoaXMuc3RhdGUuZWRpdGluZztcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgZWRpdGluZyB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlZGl0aW5nKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0LmZvY3VzKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVDbGlja091dHNpZGUgPSAoZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgZWRpdGluZyB9ID0gdGhpcy5zdGF0ZTtcclxuICAgICAgICBpZiAoZWRpdGluZyAmJiB0aGlzLmNlbGwgIT09IGUudGFyZ2V0ICYmICF0aGlzLmNlbGwuY29udGFpbnMoZS50YXJnZXQpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzYXZlID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgcmVjb3JkLCBoYW5kbGVTYXZlIH0gPSB0aGlzLnByb3BzO1xyXG4gICAgICAgIHRoaXMuZm9ybS52YWxpZGF0ZUZpZWxkcygoZXJyb3IsIHZhbHVlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnRvZ2dsZUVkaXQoKTtcclxuICAgICAgICAgICAgaGFuZGxlU2F2ZSh7IC4uLnJlY29yZCwgLi4udmFsdWVzIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJlbmRlcigpIHtcclxuICAgICAgICBjb25zdCB7IGVkaXRpbmcgfSA9IHRoaXMuc3RhdGU7XHJcbiAgICAgICAgY29uc3Qge1xyXG4gICAgICAgICAgICBlZGl0YWJsZSxcclxuICAgICAgICAgICAgZGF0YUluZGV4LFxyXG4gICAgICAgICAgICB0aXRsZSxcclxuICAgICAgICAgICAgcmVjb3JkLFxyXG4gICAgICAgICAgICBpbmRleCxcclxuICAgICAgICAgICAgaGFuZGxlU2F2ZSxcclxuICAgICAgICAgICAgLi4ucmVzdFByb3BzXHJcbiAgICAgICAgfSA9IHRoaXMucHJvcHM7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPHRkIHJlZj17bm9kZSA9PiAodGhpcy5jZWxsID0gbm9kZSl9IHsuLi5yZXN0UHJvcHN9PlxyXG4gICAgICAgICAgICAgICAge2VkaXRhYmxlID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxFZGl0YWJsZUNvbnRleHQuQ29uc3VtZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsoZm9ybSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5mb3JtID0gZm9ybTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1JdGVtIHN0eWxlPXt7IG1hcmdpbjogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtLmdldEZpZWxkRGVjb3JhdG9yKGRhdGFJbmRleCwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYCR7dGl0bGV9IGlzIHJlcXVpcmVkLmAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbFZhbHVlOiByZWNvcmRbZGF0YUluZGV4XSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e25vZGUgPT4gKHRoaXMuaW5wdXQgPSBub2RlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25QcmVzc0VudGVyPXt0aGlzLnNhdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJlZGl0YWJsZS1jZWxsLXZhbHVlLXdyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmdSaWdodDogMjQgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLnRvZ2dsZUVkaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3RQcm9wcy5jaGlsZHJlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvRWRpdGFibGVDb250ZXh0LkNvbnN1bWVyPlxyXG4gICAgICAgICAgICAgICAgKSA6IHJlc3RQcm9wcy5jaGlsZHJlbn1cclxuICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICApO1xyXG4gICAgfVxyXG59XHJcblxyXG5jbGFzcyBQYWdlRW50cmllc1RhYmxlRWRpdGFibGUgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJvcHMpIHtcclxuICAgICAgICBzdXBlcihwcm9wcyk7XHJcbiAgICAgICAgdGhpcy5jb2x1bW5zID0gW3tcclxuICAgICAgICAgICAgdGl0bGU6ICdGaWVsZE5hbWUnLFxyXG4gICAgICAgICAgICBkYXRhSW5kZXg6ICduYW1lJyxcclxuICAgICAgICAgICAgZmlsdGVyczogW3tcclxuICAgICAgICAgICAgICAgIHRleHQ6ICdidXNpbmVzcycsXHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ2J1c2luZXNzJyxcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdGV4dDogJ2NvbXBhbnknLFxyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICdjb21wYW55JyxcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdGV4dDogJ293bmVyJyxcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAnb3duZXInLFxyXG4gICAgICAgICAgICB9XSxcclxuICAgICAgICAgICAgb25GaWx0ZXI6ICh2YWx1ZSwgcmVjb3JkKSA9PiByZWNvcmQubmFtZS50b0xvd2VyQ2FzZSgpLmluZGV4T2YodmFsdWUpID09PSAwLFxyXG4gICAgICAgICAgICBzb3J0ZXI6IChhLCBiKSA9PiBhLm5hbWUubGVuZ3RoIC0gYi5uYW1lLmxlbmd0aCxcclxuICAgICAgICAgICAgZWRpdGFibGU6IHRydWUsXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICB0aXRsZTogJ0ZpZWxkIGlkJyxcclxuICAgICAgICAgICAgZGF0YUluZGV4OiAnaWQnLFxyXG4gICAgICAgICAgICBzb3J0ZXI6IChhLCBiKSA9PiBhLmlkLmxlbmd0aCAtIGIuaWQubGVuZ3RoLFxyXG4gICAgICAgICAgICBlZGl0YWJsZTogdHJ1ZSxcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgIHRpdGxlOiAnVmFsdWUnLFxyXG4gICAgICAgICAgICBkYXRhSW5kZXg6ICdvcHRpb25zJyxcclxuICAgICAgICAgICAgZWRpdGFibGU6IHRydWUsXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICB0aXRsZTogJ0RlbGV0ZScsXHJcbiAgICAgICAgICAgIGRhdGFJbmRleDogJ29wZXJhdGlvbicsXHJcbiAgICAgICAgICAgIHJlbmRlcjogKHRleHQsIHJlY29yZCkgPT4geyAgXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUuZGF0YVNvdXJjZS5sZW5ndGggPj0gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtIHRpdGxlPVwiU3VyZSB0byBkZWxldGU/XCIgb25Db25maXJtPXsoKSA9PiB0aGlzLmhhbmRsZURlbGV0ZShyZWNvcmQua2V5KX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGE+RGVsZXRlPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB3aWR0aDogODAsXHJcbiAgICAgICAgICAgIH1dO1xyXG5cclxuICAgICAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICAgICAgICBtb2RlOiB0aGlzLnByb3BzLm1vZGUsXHJcbiAgICAgICAgICAgIGRhdGFTb3VyY2U6IHRoaXMucGFyc2VEYXRhKHRoaXMucHJvcHMuZGF0YVNvdXJjZSksXHJcbiAgICAgICAgICAgIHBhZ2VJbmRleDogdGhpcy5wcm9wcy5wYWdlSW5kZXhcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcGFyc2VEYXRhID0gKGVudHJpZXMpID0+IHtcclxuICAgICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5LCBpZCkgPT4ge1xyXG4gICAgICAgICAgICBlbnRyeS5rZXkgPSBpZDtcclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiBlbnRyaWVzO1xyXG4gICAgfVxyXG5cclxuICAgIGhhbmRsZURlbGV0ZSA9IChrZXkpID0+IHtcclxuICAgICAgICBjb25zdCBkYXRhU291cmNlID0gWy4uLnRoaXMuc3RhdGUuZGF0YVNvdXJjZV07XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGRhdGFTb3VyY2U6IGRhdGFTb3VyY2UuZmlsdGVyKGl0ZW0gPT4gaXRlbS5rZXkgIT09IGtleSkgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaGFuZGxlQWRkID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgZGF0YVNvdXJjZSB9ID0gdGhpcy5zdGF0ZTtcclxuICAgICAgICBjb25zdCBuZXdEYXRhID0ge1xyXG4gICAgICAgICAgICBuYW1lOiAnZGVmYXVsdCcsXHJcbiAgICAgICAgICAgIGlkOiAnZGVmYXVsdCcsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcclxuICAgICAgICAgICAgb3B0aW9uczogJ2RlZmF1bHQnLFxyXG4gICAgICAgICAgICB0YWdOYW1lOiAnSU5QVVQnLFxyXG4gICAgICAgICAgICBpc1JlcXVpcmVkOiBmYWxzZVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGFTb3VyY2U6IFtuZXdEYXRhLC4uLmRhdGFTb3VyY2VdLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGhhbmRsZVNhdmUgPSAocm93KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV3RGF0YSA9IFsuLi50aGlzLnN0YXRlLmRhdGFTb3VyY2VdO1xyXG4gICAgICAgIGNvbnN0IGluZGV4ID0gbmV3RGF0YS5maW5kSW5kZXgoaXRlbSA9PiByb3cua2V5ID09PSBpdGVtLmtleSk7XHJcbiAgICAgICAgY29uc3QgaXRlbSA9IG5ld0RhdGFbaW5kZXhdO1xyXG4gICAgICAgIG5ld0RhdGEuc3BsaWNlKGluZGV4LCAxLCB7XHJcbiAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgIC4uLnJvdyxcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgZGF0YVNvdXJjZTogbmV3RGF0YSB9KTtcclxuICAgICAgICB0aGlzLnByb3BzLnVwZGF0ZVJldmlzZWRKc29uKHRoaXMuc3RhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHJlbmRlcigpIHtcclxuICAgICAgICBjb25zdCB7IGRhdGFTb3VyY2UgfSA9IHRoaXMuc3RhdGU7XHJcbiAgICAgICAgY29uc3QgY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICAgICAgcm93OiBFZGl0YWJsZUZvcm1Sb3csXHJcbiAgICAgICAgICAgICAgICBjZWxsOiBFZGl0YWJsZUNlbGwsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBjb2x1bW5zID0gdGhpcy5jb2x1bW5zLm1hcCgoY29sKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghY29sLmVkaXRhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gY29sO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5jb2wsXHJcbiAgICAgICAgICAgICAgICBvbkNlbGw6IHJlY29yZCA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZCxcclxuICAgICAgICAgICAgICAgICAgICBlZGl0YWJsZTogY29sLmVkaXRhYmxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogY29sLmRhdGFJbmRleCxcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogY29sLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVNhdmU6IHRoaXMuaGFuZGxlU2F2ZSxcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3RoaXMuaGFuZGxlQWRkfSB0eXBlPVwicHJpbWFyeVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRkIGEgbmV3IGVudHJ5XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudHM9e2NvbXBvbmVudHN9XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Q2xhc3NOYW1lPXsoKSA9PiAnZWRpdGFibGUtcm93J31cclxuICAgICAgICAgICAgICAgICAgICBib3JkZXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U9e2RhdGFTb3VyY2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICByb3dLZXk9XCJrZXlcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGFnZUVudHJpZXNUYWJsZUVkaXRhYmxlOyIsIlxyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IEpzb25FZGl0b3IgZnJvbSAnLi9Kc29uRWRpdG9yJztcclxuaW1wb3J0IFJlY29yZGVyVG9vbHMgZnJvbSAnLi9SZWNvcmRlclRvb2xzJztcclxuXHJcbmNsYXNzIFBhZ2VSb3V0ZXIgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG5cclxuICAgIGdldFBhZ2UgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKHRoaXMucHJvcHMucGFnZSA9PT0gXCJlZGl0b3JcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gPEpzb25FZGl0b3IgLz5cclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMucHJvcHMucGFnZSA9PT0gXCJ0b29sc1wiKSB7XHJcbiAgICAgICAgICAgIHJldHVybiA8UmVjb3JkZXJUb29scyAvPlxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiA8SnNvbkVkaXRvciAvPlxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZW5kZXIoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0UGFnZSgpO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYWdlUm91dGVyOyIsIlxyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHsgVGFicywgSWNvbiB9IGZyb20gJ2FudGQnO1xyXG5pbXBvcnQgUGFnZUVudHJpZXNUYWJsZUVkaXRhYmxlIGZyb20gJy4vUGFnZUVudHJpZXNUYWJsZUVkaXRhYmxlJztcclxuXHJcbmNvbnN0IFRhYlBhbmUgPSBUYWJzLlRhYlBhbmU7XHJcblxyXG5jbGFzcyBQYWdlc1RhYiBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcm9wcykge1xyXG4gICAgICAgIHN1cGVyKHByb3BzKTtcclxuICAgICAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICAgICAgICB1cGxvYWRlZEpzb246IHRoaXMucHJvcHMuanNvblxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnVwZGF0ZVJldmlzZWRKc29uID0gdGhpcy51cGRhdGVSZXZpc2VkSnNvbi5iaW5kKHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIGdlbmVyYXRlVGFibGUgPSAocGFnZSwgaW5kZXgsIG1vZGUpID0+IHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8VGFiUGFuZSB0YWI9e3BhZ2UuZG9jTmFtZX0ga2V5PXtpbmRleH0+IFxyXG4gICAgICAgICAgICAgICAgPFBhZ2VFbnRyaWVzVGFibGVFZGl0YWJsZSBcclxuICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlPXtwYWdlLmVudHJpZXN9IFxyXG4gICAgICAgICAgICAgICAgICAgIG1vZGU9e21vZGV9IFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2VJbmRleD17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlUmV2aXNlZEpzb24gPSB7dGhpcy51cGRhdGVSZXZpc2VkSnNvbn1cclxuICAgICAgICAgICAgICAgID4gXHJcbiAgICAgICAgICAgICAgICA8L1BhZ2VFbnRyaWVzVGFibGVFZGl0YWJsZT5cclxuICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG4gICAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVSZXZpc2VkSnNvbiA9IChuZXdTdGF0ZSkgPT4ge1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IG5ld1N0YXRlLnBhZ2VJbmRleDtcclxuICAgICAgICAgICAgbGV0IHRlbXBKc29uID0gdGhpcy5zdGF0ZS51cGxvYWRlZEpzb247XHJcbiAgICAgICAgICAgIGlmKG5ld1N0YXRlLm1vZGUgPT09IFwicHVibGlzaGVyXCIpe1xyXG4gICAgICAgICAgICAgICAgdGVtcEpzb24ucGFnZXNbaW5kZXhdLmVudHJpZXMgPSBuZXdTdGF0ZS5kYXRhU291cmNlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGVtcEpzb24ucGFnZXNfcmVjaXBpZW50W2luZGV4XS5lbnRyaWVzID0gbmV3U3RhdGUuZGF0YVNvdXJjZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5wcm9wcy51cGRhdGVSZXZpc2VkSnNvbih0ZW1wSnNvbik7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdXBsb2FkZWRKc29uOiB0ZW1wSnNvbixcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgcmVuZGVyKCkgeyAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgcGFnZXNMZWZ0VGFic19wdWJsaXNoZXIgPSB0aGlzLnN0YXRlLnVwbG9hZGVkSnNvbi5wYWdlcy5tYXAoKHBhZ2UsIGlkKSA9PiB0aGlzLmdlbmVyYXRlVGFibGUocGFnZSwgaWQsIFwicHVibGlzaGVyXCIpKTtcclxuICAgICAgICBjb25zdCBwYWdlc0xlZnRUYWJzX3JlY2lwaWVudCA9IHRoaXMuc3RhdGUudXBsb2FkZWRKc29uLnBhZ2VzX3JlY2lwaWVudC5tYXAoKHBhZ2UsIGlkKSA9PiB0aGlzLmdlbmVyYXRlVGFibGUocGFnZSwgaWQsIFwicmVjaXBpZW50XCIpKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPFRhYnMgZGVmYXVsdEFjdGl2ZUtleT1cIjFcIj5cclxuICAgICAgICAgICAgICAgIDxUYWJQYW5lIHRhYj17PHNwYW4+PEljb24gdHlwZT1cInNtaWxlXCIgLz5QdWJsaXNoZXIgTW9kZTwvc3Bhbj59IGtleT1cIjFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGFicyBkZWZhdWx0QWN0aXZlS2V5PVwiMFwiIHRhYlBvc2l0aW9uPVwibGVmdFwiID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2VzTGVmdFRhYnNfcHVibGlzaGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgICAgICAgIDwvVGFiUGFuZT5cclxuICAgICAgICAgICAgICAgIDxUYWJQYW5lICB0YWI9ezxzcGFuPjxJY29uIHR5cGU9XCJ1c2VyXCIgLz5SZWNpcGllbnQgTW9kZTwvc3Bhbj59IGtleT1cIjJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGFicyBkZWZhdWx0QWN0aXZlS2V5PVwiMFwiIHRhYlBvc2l0aW9uPVwibGVmdFwiID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2VzTGVmdFRhYnNfcmVjaXBpZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgICAgICAgIDwvVGFiUGFuZT5cclxuICAgICAgICAgICAgPC9UYWJzPlxyXG4gICAgICAgIClcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGFnZXNUYWI7XHJcblxyXG5cclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGF5b3V0LCBSb3csIENvbCB9IGZyb20gJ2FudGQnO1xyXG5pbXBvcnQgSGVhZGVyUGFuZWwgZnJvbSAnLi9IZWFkZXJQYW5lbCc7XHJcblxyXG5jb25zdCB7IENvbnRlbnQgfSA9IExheW91dDtcclxuXHJcbmNsYXNzIFJlY29yZGVyVG9vbHMgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxMYXlvdXQ+XHJcbiAgICAgICAgICAgICAgICA8SGVhZGVyUGFuZWwgdGl0bGU9XCJBRVggUmVjb3JkZXIgSlNPTiBUb29sc1wiPiA8L0hlYWRlclBhbmVsPlxyXG4gICAgICAgICAgICAgICAgPENvbnRlbnQgc3R5bGU9e3sgbWFyZ2luOiAnMCAxNnB4J319PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogMjQsIG1pbkhlaWdodDogODAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um93IGd1dHRlcj17MTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCBsZz17MTJ9IHNwYW49ezI0fSA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5SaWdodDogJzEwcHgnLCBtaW5IZWlnaHQ6IDc1MH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21pbmcgU29vblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIGxnPXsxMn0gc3Bhbj17MjR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogJzEwcHgnLCBtaW5IZWlnaHQ6IDc1MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0NvbnRlbnQ+XHJcbiAgICAgICAgICAgIDwvTGF5b3V0PlxyXG4gICAgICAgIClcclxuICAgICAgICBcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjb3JkZXJUb29sczsiLCJcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IExheW91dCwgTWVudSwgSWNvbiB9IGZyb20gJ2FudGQnO1xyXG5jb25zdCB7IFNpZGVyIH0gPSBMYXlvdXQ7XHJcblxyXG5jbGFzcyBTaWRlclBhbmVsIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcclxuICAgIHN0YXRlID0ge1xyXG4gICAgICAgIGNvbGxhcHNlZDogdHJ1ZSxcclxuICAgIH07XHJcblxyXG4gICAgb25Db2xsYXBzZSA9IChjb2xsYXBzZWQpID0+IHtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgY29sbGFwc2VkIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJlbmRlcigpIHtcclxuXHJcbiAgICAgICAgY29uc3QgTG9nb0RpdiA9IChwcm9wcykgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e2hlaWdodDogJzYwcHgnLCBtYXJnaW5MZWZ0OiBwcm9wcy5jb2xsYXBzZWQ/ICcwJyA6ICcyNSUnfX0gPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiaW1hZ2VzL3NpZGVyLWxvZ28ucG5nXCIgY2xhc3NOYW1lPVwiQXBwLWxvZ29cIiBhbHQ9XCJsb2dvXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PiAgXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxTaWRlclxyXG4gICAgICAgICAgICBjb2xsYXBzaWJsZVxyXG4gICAgICAgICAgICBjb2xsYXBzZWQ9e3RoaXMuc3RhdGUuY29sbGFwc2VkfVxyXG4gICAgICAgICAgICBvbkNvbGxhcHNlPXt0aGlzLm9uQ29sbGFwc2V9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjMjgyYzM0JyB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8TG9nb0RpdiBjb2xsYXBzZWQ9e3RoaXMuc3RhdGUuY29sbGFwc2VkfSAvPlxyXG4gICAgICAgICAgICAgICAgPE1lbnUgXHJcbiAgICAgICAgICAgICAgICB0aGVtZT1cImRhcmtcIiBcclxuICAgICAgICAgICAgICAgIGRlZmF1bHRTZWxlY3RlZEtleXM9e1snZWRpdG9yJ119IFxyXG4gICAgICAgICAgICAgICAgbW9kZT1cImlubGluZVwiIFxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogJyMyODJjMzQnIH19XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLnByb3BzLmNoYW5nZVBhZ2V9XHJcbiAgICAgICAgICAgICAgICA+ICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxNZW51Lkl0ZW0ga2V5PVwiZWRpdG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIHR5cGU9XCJwaWUtY2hhcnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5KU09OIEVkaXRvcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L01lbnUuSXRlbT4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPE1lbnUuSXRlbSBrZXk9XCJ0b29sc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiB0eXBlPVwiZGVza3RvcFwiIC8+ICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZWNvcmRlciBUb29sczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L01lbnUuSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPE1lbnUuSXRlbSBrZXk9XCJ1c2VyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIHR5cGU9XCJ1c2VyXCIgLz4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlVzZXI8L3NwYW4+ICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPC9NZW51Lkl0ZW0+ICAgICAgICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPE1lbnUuSXRlbSBrZXk9XCJzZXR0aW5nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIHR5cGU9XCJmaWxlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2V0dGluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L01lbnUuSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvTWVudT5cclxuICAgICAgICAgICAgPC9TaWRlcj5cclxuICAgICAgICApXHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaWRlclBhbmVsOyIsIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5cbnZhciB0cmFuc2Zvcm07XG52YXIgaW5zZXJ0SW50bztcblxuXG5cbnZhciBvcHRpb25zID0ge1wiaG1yXCI6dHJ1ZX1cblxub3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbm9wdGlvbnMuaW5zZXJ0SW50byA9IHVuZGVmaW5lZDtcblxudmFyIHVwZGF0ZSA9IHJlcXVpcmUoXCIhLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIiwgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuXHRcdGlmKHR5cGVvZiBuZXdDb250ZW50ID09PSAnc3RyaW5nJykgbmV3Q29udGVudCA9IFtbbW9kdWxlLmlkLCBuZXdDb250ZW50LCAnJ11dO1xuXG5cdFx0dmFyIGxvY2FscyA9IChmdW5jdGlvbihhLCBiKSB7XG5cdFx0XHR2YXIga2V5LCBpZHggPSAwO1xuXG5cdFx0XHRmb3Ioa2V5IGluIGEpIHtcblx0XHRcdFx0aWYoIWIgfHwgYVtrZXldICE9PSBiW2tleV0pIHJldHVybiBmYWxzZTtcblx0XHRcdFx0aWR4Kys7XG5cdFx0XHR9XG5cblx0XHRcdGZvcihrZXkgaW4gYikgaWR4LS07XG5cblx0XHRcdHJldHVybiBpZHggPT09IDA7XG5cdFx0fShjb250ZW50LmxvY2FscywgbmV3Q29udGVudC5sb2NhbHMpKTtcblxuXHRcdGlmKCFsb2NhbHMpIHRocm93IG5ldyBFcnJvcignQWJvcnRpbmcgQ1NTIEhNUiBkdWUgdG8gY2hhbmdlZCBjc3MtbW9kdWxlcyBsb2NhbHMuJyk7XG5cblx0XHR1cGRhdGUobmV3Q29udGVudCk7XG5cdH0pO1xuXG5cdG1vZHVsZS5ob3QuZGlzcG9zZShmdW5jdGlvbigpIHsgdXBkYXRlKCk7IH0pO1xufSIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0ICdhbnRkL2Rpc3QvYW50ZC5jc3MnO1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcCc7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuUmVhY3RET00ucmVuZGVyKChcbiAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgIDxBcHAgLz5cbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICksIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpO1xuIiwiY2xhc3MgQ2hyb21lVXRpbCB7XHJcblxyXG4gICAgc3RhdGljIHNlbmRNZXNzYWdlID0gKG1zZywgb2JqKSA9PiB7XHJcbiAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBtc2csXHJcbiAgICAgICAgICAgIG9ialxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IHsgQ2hyb21lVXRpbCB9OyJdLCJzb3VyY2VSb290IjoiIn0=