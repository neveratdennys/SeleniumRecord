let uploadedJson;
let seleniumJson;
let stop = true;
let playback = false;
let autoPublish = false;
let msgBoxOpen = false;
let pauseMode = false;
let demoMode = false;
let curDocInfo = {};

/**
 * Run on installed
 */
chrome.runtime.onInstalled.addListener(function () {
    console.log("Extension Installed");

    chrome.declarativeContent.onPageChanged.removeRules(undefined, function () {
        chrome.declarativeContent.onPageChanged.addRules([{
            conditions: [
                new chrome.declarativeContent.PageStateMatcher({
                    pageUrl: { pathContains: '' },
                })
            ],
            actions: [new chrome.declarativeContent.ShowPageAction()]
        }]);
    });
});

/**
 * handle received message from popup page or content script (init_proxy)
 */

chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {
        if (request.message === "start_clicked_in_popup") {
            startRecording();
        } else if (request.message.includes("playback_Called_from_PopUp")) {
            setDataForPlaybackFromPopUp(request);
        } else if (request.message === "Message_Box_Toggle") {
            msgBoxOpen = request.status;
        } else if (request.message === "reset_Called") {
            console.log("Received message to reset. Reset extension.");
            clearGlobalVariables();
        } else if (request.message === "FROM_RECORD") {
            setDataForRecordingFromPage(request);
        } else if (request.message === "FROM_RECORD_DOWNLOAD" || request.message === "download_clicked_in_popup") {
            AttachmentUtil.checkHasAttachmentAndDownload();
        } else if (request.message === "FROM_RECORD_COMPLETE" || request.message === "stop_clicked_in_popup" || request.message === "FROM_PAGE_CONFIRM_BOX_STOP_DOWNLOAD") {
            stopRecording();
        } else if (request.message === "FROM_PLAYBACK_COMPLETE") {
            completePlayback();
        } else if (String(request.message).includes("FROM_PAGE_ERROR")) {
            console.log(request.message);
        } else if (request.message === "GET_STATUS") {
            sendResponse({ stop: stop, playback: playback, playbackJson: uploadedJson });
        } else if (request.message === "DISGARD_RECORD_OR_PLAYBACK" || request.message === "FROM_PAGE_CONFIRM_BOX_NO") {
            clearGlobalVariables();
            seleniumJson = {};
            uploadedJson = {};
        } else if (request.message === "FROM_PAGE_INIT") {
            analyzePageInitInfo(request, sendResponse);
        } else if (request.message === "FROM_PAGE_CONFIRM_BOX_YES") {
            handleConfirmBoxYes(sendResponse);
        } else if (request.message === "FROM_PAGE_START_PLAYBACK_RECIPIENT"){
            setTimeout(() => {
                startPlaybackInRecipientMode();
            }, 5000);            
        }
    }
);

function analyzePageInitInfo(request, sendResponse) {
    curDocInfo = request.data;
    if (!stop && !playback) {
        if (isRecordingInSameTransaction()) {
            if (isInRecipientMode()) {
                sendResponse({ message: "open_confirm_dialog_recipient" });
            } else {
                sendResponse({ message: "open_confirm_dialog_same_transaction" });
            }
        } else {
            sendResponse({ message: "open_confirm_dialog_diff_transaction" });
        }
    }

    if (playback && stop) {
        if(isPlaybackInSameTransaction()){
            var dataToSend = { json: uploadedJson, pause: pauseMode, demo: demoMode, publish: autoPublish };
            sendResponse({ message: "sendData_playback", data: dataToSend });
        } else {
            console.log("Wrong transaction, playback stopped");
            playback = false;
        }
        
    }
}

function handleConfirmBoxYes(sendResponse) {
    if (!stop && isRecordingInSameTransaction()) {
        console.log("Recording in process, send data to page");
        var dataToSend = { json: seleniumJson };
        sendResponse({ message: "sendData_record", data: dataToSend });
    }
}

function isRecordingInSameTransaction() {
    return curDocInfo && seleniumJson.meta && seleniumJson.meta.companyId === curDocInfo.companyId
        && seleniumJson.meta.transactionName === curDocInfo.transactionName;
}

function isPlaybackInSameTransaction() {
    return curDocInfo && uploadedJson.meta && uploadedJson.meta.companyId === curDocInfo.companyId
        && uploadedJson.meta.transactionName === curDocInfo.transactionName;
}

function isInRecipientMode() {
    return curDocInfo && curDocInfo.status >= 15 && !seleniumJson.pages_recipient.length && seleniumJson.sendPanelInfo;
}

function clearGlobalVariables() {
    playback = false;
    stop = true;
    autopublish = false;
    pauseMode = false;
    demoMode = false;
}

function startRecording() {
    console.log("Received request to start recording.");
    clearGlobalVariables();
    stop = false;
}

function stopRecording() {
    console.log("Received stop recording request");
    AttachmentUtil.checkHasAttachmentAndDownload().then(() => {
        clearGlobalVariables();
        seleniumJson = {};
        sendMessageToProxy("download_completed_in_background");
    });
}

function completePlayback() {
    console.log("Playback complete. Reset extension");
    clearGlobalVariables();
}

function startPlaybackInRecipientMode() {
    if(uploadedJson.sendPanelInfo && uploadedJson.sendPanelInfo.recipientList.length){
        const user = uploadedJson.sendPanelInfo.recipientList[0].email.split("@")[0];
        const APItoken = "77f3ffd6d62e4cb08c4624d9bd2c7b97";
        const link = `https://api.mailinator.com/api/inbox?to=${user}&token=${APItoken}&private_domain=true`;
        
        return fetch(link)
            .then(res => res.json())
            .then(json => json.messages)
            .then(messages => messages[messages.length-1].id)
            .then(id => {
                const link2 = `https://api.mailinator.com/api/email?id=${id}&token=${APItoken}&private_domain=true`;
                return fetch(link2)
                    .then(res => res.json())
                    .then(json => json.data.parts[0])
                    .then(html => new DOMParser().parseFromString(html.body, "text/html"))
                    .then(dom => dom.querySelector('strong a').href)
                    .then(launchLink => chrome.tabs.create({url:launchLink}));
            });
    }
}

//======================Playback for other options============================

function openAEXPageInNewTab(serverURL, messageToSend, username, password, callback) {
    chrome.tabs.create({ url: serverURL }, function (tab) {
        tabId = tab.id;
        setTimeout(() => {
            var dataToSend = {
                id: username,
                pin: password,
                meta: uploadedJson.meta
            }
            chrome.tabs.sendMessage(tab.id, {
                message: messageToSend,
                data: dataToSend
            }, callback());
        }, 3000);
    });
}

function openMV2AndStartTransaction(serverURL, username, password, message1, message2) {
    setTimeout(() => {
        openAEXPageInNewTab(serverURL, message1, username, password, function () {
            setTimeout(() => {
                chrome.tabs.sendMessage(tabId, {
                    message: message2,
                    data: { meta: uploadedJson.meta }
                });
            }, 3000); //wait for page to display after login
        });
    }, 1000);     //ready to open MV2     
}

function sendPlaybackDataToProxy(request) {
    var dataToSend = {
        publish: request.data.publish,
        json: uploadedJson,
        pause: request.data.pause,
        demo: request.data.demo
    }

    sendMessageToProxy(request.message, dataToSend);
}

function sendMessageToProxy(messageToSend, dataToSend) {
    if (!dataToSend) {
        dataToSend = {};
    }

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { message: messageToSend, data: dataToSend });
    });
}

function startPlaybackInSIMQ(request) {
    console.log("Received playback request in SIMQ.");
    openAEXPageInNewTab(request.data.url, request.data.subMessage, request.data.login, request.data.pin, function () { });
}

function startPlaybackInMV2(request) {
    console.log("Received playback request in MV2.");
    var messageThirdLevel = (request.message == "playback_Called_from_PopUp_Ivari") ? "open_ivari_transaction" : "open_MV2_transaction";
    openMV2AndStartTransaction(request.data.url, request.data.login, request.data.pin, request.data.subMessage, messageThirdLevel);

}

function setDataForPlaybackFromPopUp(request) {
    console.log("Received playback request");
    clearGlobalVariables();
    playback = true;
    autoPublish = request.data.publish;
    pauseMode = request.data.pause;
    demoMode = request.data.demo;
    AttachmentUtil.attachmentList = [];
    analyseUploadedFile(request);
}

function analyseUploadedFile(request) {
    var uploadedFile = request.data.file;
    if (uploadedFile.options.type == "application/zip") {
        AttachmentUtil.unzipFileToAttachmentList(uploadedFile).then(
            success => {
                dataReadyAndStartPlayback(request);
                
                if (AttachmentUtil.attachmentList.length > 0) {
                    AttachmentUtil.uploadAttachmentUsingAPI();
                }
            },
            fail => {
                notifyPageAndDisplayErrorMessage(fail);
            });
    } else {
        uploadedJson = uploadedFile.dataURL;
        dataReadyAndStartPlayback(request);
    }
}

function dataReadyAndStartPlayback(request) {

    if (request.message == "playback_Called_from_PopUp_Current_Page" || request.message.includes("SKIP_LOGIN")) {
        sendPlaybackDataToProxy(request);
    } else if (request.message.includes("MV2") || request.message.includes("Ivari")) {
        startPlaybackInMV2(request);
    } else if (request.message.includes("SIMQ")) {
        startPlaybackInSIMQ(request);
    }
}

function notifyPageAndDisplayErrorMessage(errorMessage) {
    if (errorMessage == "noJSON") {
        sendMessageToProxy("playback_error_noJSON");
    } else {
        sendMessageToProxy("playback_error_general");
    }
}

function setDataForRecordingFromPage(request) {
    console.log("Received Data from recording process");
    seleniumJson = request.data.json;
    stop = request.data.status;
}

//use to save record as java file
function parseJson(obj) {
    //var obj = JSON.parse(file);
    let code = "\tpublic SetupResult<AgreementViewerSteps> setUp() {\n " +
        "\t\tCredential credential = getCredential();\n" +
        "\t\tAgreementViewerSteps steps = new AgreementViewerSteps(getDriver(), currentBrowser);\n" +
        "\t\tsteps.loginWithCredentials(applicationUrl, credential, '" + obj.meta.companyName + "');\n" +
        "\t\tsteps.startNewAction('" + obj.meta.transactionName + "');\n" +
        "\t\treturn new SetupResult<>(steps, null, getSubjectText(), credential);\n" +
        "}\n" +
        "@Test\n\tpublic void test() {\n\t\tAgreementViewerSteps steps = setUp().getSteps();";
    var arr = [];
    //arr[0] = code;
    console.log("Generating selenium actions:");
    console.log("Pages Lenght: " + obj.pages.length);
    for (var j = 0; j < obj.pages.length; j++) {
        var fields = obj.pages[j].entries;
        for (var i = 0; i < fields.length; i++) {
            const byLocator = (isEmpty(fields[i].name) ? "id" : "name");
            if (fields[i].isDisabled || fields[i].isAssert) {
                if (fields[i].options !== "PLACE_TEXT_HERE" && !isEmpty(fields[i].options)) {
                    if (fields[i].name !== "No name" && fields[i].tagName === "INPUT" && fields[i].type === "radio") {
                        arr.push(`\t\tassertEquals(steps.isRadioButtonSelected(By.${byLocator}("${fields[i].name}")), ${fields[i].options});`);
                    } else if (fields[i].name !== "No name" && fields[i].tagName === "INPUT" && fields[i].type === "checkbox") {
                        arr.push(`\t\tassertTrue(steps.isCheckboxChecked(By.${byLocator}("${fields[i].name}")));`);
                    } else if (fields[i].name !== "No name" && fields[i].tagName === "INPUT") {
                        arr.push(`\t\tassertEquals(steps.getTextFromElement(By.${byLocator}("${fields[i].name}")), "${fields[i].options}"));`);
                    } else if (fields[i].name !== "No name" && fields[i].tagName === "SELECT") {
                        arr.push(`\t\tassertEquals(steps.getSelectedValueFromSelectField(By.${byLocator}("${fields[i].name}")), "${fields[i].options}"));`);
                    }
                }
            } else {
                if (fields[i].name !== "No name" && fields[i].tagName === "INPUT" && fields[i].isDate) {
                    arr.push(`\t\tsteps.selectDateFromDatePicker(By.${byLocator}("${fields[i].name}"), "ENTER_DATE_HERE");`);
                } else if (fields[i].name !== "No name" && fields[i].tagName === "INPUT" && fields[i].type === "radio") {
                    arr.push(`\t\tsteps.selectRadioButton(By.${byLocator}("${fields[i].name}"), ${fields[i].options});`);
                } else if (fields[i].name !== "No name" && fields[i].tagName === "INPUT" && fields[i].type === "checkbox") {
                    arr.push(`\t\tsteps.clickElement(By.${byLocator}("${fields[i].name}"));`);
                } else if (fields[i].name !== "No name" && fields[i].tagName === "INPUT") {
                    arr.push(`\t\tsteps.enterTextInTextfield(By.${byLocator}("${fields[i].name}"), "${fields[i].options}");`);
                } else if (fields[i].name !== "No name" && fields[i].tagName === "SELECT") {
                    arr.push(`\t\tsteps.selectValueFromSelectField(By.${byLocator}("${fields[i].name}"), "${fields[i].options}");`);
                } else if (fields[i].name !== "No name" && fields[i].tagName === "A") {
                    arr.push(`\t\tsteps.clickElement(By.${byLocator}("${fields[i].name}"));`);
                }
            }
        }
    }


    //arr = arr.sort(function(a, b) { return a.pos < b.pos });
    //arr = arr.reduce(function(a,b){if(a.indexOf(b)<0)a.push(b);return a;},[]);
    arr.push("\n}");
    arr.unshift(code);
    return arr.join("\n");
}

//=======================attachment utilities=====================

class AttachmentUtil { }

AttachmentUtil.attachmentList = [];
AttachmentUtil.running = false;
AttachmentUtil.viewableTypes = [".jpg", ".png", ".gif", ".jpeg"];
AttachmentUtil.documentType = ["pdf", "tiff", "tif", "png", "jpg", "jpeg", "doc", "docx", "gif", "rtf", "ppt", "xls"];

AttachmentUtil.getAttachmentList = function () {
    if (AttachmentUtil.running)
        return new Promise((resolve, reject) => {
            reject("AttachmentUtil is already running");
        });
    if (!curDocInfo.docID)
        return new Promise((resolve, reject) => {
            reject("Invalid URL");
        });

    AttachmentUtil.running = true;
    AttachmentUtil.attachmentList = [];
    const link = `${curDocInfo.serverOrigin}/Html5Controller?cmd=getDocuments&guid=${curDocInfo.docID}`;
    return fetch(link)
        .then(res => res.json())
        .then(array => array.filter(doc => doc.isAttachment == '1'))
        .then(attachments => {
            const promises = attachments.map(attachment => AttachmentUtil.saveAttachmentToList(attachment));
            return Promise.all(promises);
        })
        .then(() => {
            AttachmentUtil.running = false;
            return AttachmentUtil.attachmentList;
        });
}

AttachmentUtil.saveAttachmentToList = function (attachment) {
    return fetch(AttachmentUtil.getAttachmentLink(attachment))
        .then(res => res.blob())
        .then(blob => {
            return {
                file: blob,
                displayName: attachment.displayName,
                fileName: attachment.documentName,
                options: {
                    type: blob.type,
                },
                isRaw: attachment.isRawAttachment == "1"
            };
        })
        .then(fileObject => AttachmentUtil.attachmentList.push(fileObject));
}

AttachmentUtil.isImageAttachment = function (fileName) {
    return AttachmentUtil.viewableTypes.some((type) => fileName.toLowerCase().endsWith(type));
}

AttachmentUtil.isDocumentTypeAttachment = function (fileName) {
    return AttachmentUtil.documentType.some((type) => fileName.toLowerCase().endsWith(type));
}

AttachmentUtil.getAttachmentLink = function (attachment) {
    return AttachmentUtil.isImageAttachment(attachment.documentName) ?
        `${curDocInfo.serverOrigin}/Html5Controller?cmd=getImg&page=1&guid=${attachment.guid}` :
        `${curDocInfo.serverOrigin}/Html5Controller?cmd=getAttachmentPDF&userEmail=${curDocInfo.currentUser}&guid=${attachment.guid}`;
}

AttachmentUtil.checkHasAttachmentAndDownload = function () {
    return AttachmentUtil.getAttachmentList().then((attachmentList) => {
        AttachmentUtil.attachmentList = attachmentList;

        if (attachmentList.length > 0) {
            AttachmentUtil.convertToZipAndDownload();
        } else {
            AttachmentUtil.downloadJsonToComputer();
        }
    }, (reject) => {
        AttachmentUtil.downloadJsonToComputer();
    });
}

AttachmentUtil.convertToZipAndDownload = function () {

    var zip = new JSZip();
    AttachmentUtil.attachmentList.forEach(attachment => {
        var attachmentInfo = {
            fileName: attachment.fileName,
            displayName: attachment.displayName,
            type: attachment.options.type,
            isRaw: attachment.isRaw,
            refId: AttachmentUtil.generateUniqueId()
        }
        seleniumJson.attachmentList.push(attachmentInfo);
        zip.file(attachmentInfo.refId, attachment.file, { base64: true });
    });

    var name = (seleniumJson.meta.transactionName != "") ? seleniumJson.meta.transactionName :
        ((seleniumJson.meta.transactionFolderName != "") ? seleniumJson.meta.transactionFolderName : "selenium");
    name = name.replace(/\//g, "_");

    zip.file(name + ".json", JSON.stringify(seleniumJson, null, 2));

    zip.generateAsync({ type: "blob" })
        .then(function (content) {
            saveAs(content, name + ".zip");
        });
}

AttachmentUtil.download = function (filename, content, type) {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/' + type + ';charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

AttachmentUtil.downloadJsonToComputer = function () {
    console.log("Received message to download");
    console.log("creating json");

    if (seleniumJson.meta) {
        var name = (seleniumJson.meta.transactionName != "") ? seleniumJson.meta.transactionName : ((seleniumJson.meta.transactionFolderName != "") ? seleniumJson.meta.transactionFolderName : "selenium");
        AttachmentUtil.download(name + ".json", JSON.stringify(seleniumJson, null, 2), "json");
    }
}

AttachmentUtil.generateUniqueId = function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

AttachmentUtil.convertfileToJson = function (file) {
    return new Promise((resolve, reject) => {
        var fr = new FileReader();
        fr.onload = function (e) {
            resolve(JSON.parse(e.target.result));
        };
        fr.readAsText(file);
    });
}

AttachmentUtil.getArrayBufferFromDataUrl = function (dataurl) {
    var arr = dataurl.split(','),
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return [u8arr];
}

AttachmentUtil.deserializeFile = function (file) {
    return new File(
        AttachmentUtil.getArrayBufferFromDataUrl(file.dataURL),
        file.name,
        file.options
    );
}

AttachmentUtil.readFileToJson = function (file) {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.onload = (e) => {
            resolve(JSON.parse(e.target.result));
        };
        fileReader.readAsText(file);
    });
}

AttachmentUtil.unzipFileToAttachmentList = function (uploadedFile) {
    uploadedJson = {};
    var zipFile = AttachmentUtil.deserializeFile(uploadedFile);
    return JSZip.loadAsync(zipFile)
        .then(data => {
            var fileArray = [];
            for (var k in data.files) {
                fileArray.push(data.files[k]);
            }

            const promises = [];
            fileArray.forEach(file => {

                if (file.name.split(".")[1] == "json") {
                    const promise = file.async('text').then(filedata => {
                        return uploadedJson = JSON.parse(filedata);
                    });
                    promises.push(promise);
                } else {
                    const promise = file.async('blob').then(fileData => ({
                        type: 'attachment',
                        fileData,
                        name: file.name
                    }));
                    promises.push(promise);
                }
            })

            return Promise.all(promises);
        }).then(dataList => {

            //reject if zip file does not contain JSON file
            if (!uploadedJson.meta) {
                return Promise.reject("noJSON");
            }

            if (dataList && dataList.length > 0) {
                dataList.filter(obj => obj.type === 'attachment').forEach(attachment => {
                    const attachmentInfo = uploadedJson.attachmentList.filter(({ refId }) => refId === attachment.name);

                    if (attachmentInfo.length > 0) {
                        attachmentInfo[0].file = new File(
                            [attachment.fileData],
                            attachmentInfo[0].fileName,
                            attachmentInfo[0].options
                        );
                    }
                    AttachmentUtil.attachmentList.push(attachmentInfo[0]);
                })
            }
        });
}

AttachmentUtil.uploadAttachmentUsingAPI = function () {
    var attachmentList = AttachmentUtil.attachmentList;
    const promiseList = [];
    attachmentList.forEach(attachment => {
        const formData = new FormData();
        formData.append('attachment0', attachment.file);
        const link = `${curDocInfo.serverOrigin}/Html5Controller?cmd=addAttachment&companyId=${uploadedJson.meta.companyId}&guid=${curDocInfo.docID}&userName=${curDocInfo.currentUser}&rawUpload=${attachment.isRaw}&documentType=&documentGroup=&attachmentName=${attachment.displayName}&date=${Date.now()}`;

        const promise = fetch(link, {
            method: 'POST',
            body: formData
        })
            .then(res => res.text())
            .then(text => {
                const resArr = text.split('|,');
                const success = resArr[0].split('=')[1] === 'success';
                if (!success)
                    console.error(`Failed to upload ${attachment.displayName}; Attachment Type: ${attachment.isRaw ? 'File' : 'Document'}.`);
                return {
                    success,
                    name: attachment.displayName,
                    isRaw: attachment.isRaw,
                    response: resArr[1]
                }
            });
        promiseList.push(promise);
    });
    return Promise.all(promiseList)
        .then(resultList => {
            const successNumber = resultList.filter(result => result.success).length;
            console.log(`Attachment Uploaded, ${successNumber} succeeded, ${resultList.length - successNumber} failed, ${resultList.length} in total.`);
            return resultList;
        });
}